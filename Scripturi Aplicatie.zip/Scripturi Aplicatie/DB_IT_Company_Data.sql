INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (1, 'Andreea', 'Popescu', 'andreea.popescu@company.com', '+40740111222', TO_DATE('2016-03-01', 'YYYY-MM-DD'), 'Software Development Manager', 'Software Development', 'Active', 'apopescu', STANDARD_HASH('parola123', 'SHA256'), 'Manager');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (2, 'Irina', 'Radu', 'irina.radu.frontend@company.com', '+40741234501', TO_DATE('2021-03-15', 'YYYY-MM-DD'), 'Frontend Developer', 'Software Development', 'Active', 'iradu.fe', STANDARD_HASH('iradu456', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (3, 'Mihai', 'Toma', 'mihai.toma.frontend@company.com', '+40741234502', TO_DATE('2020-08-22', 'YYYY-MM-DD'), 'Frontend Developer', 'Software Development', 'Active', 'mtoma.fe', STANDARD_HASH('mtoma789', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (4, 'Alina', 'Dobre', 'alina.dobre.frontend@company.com', '+40741234503', TO_DATE('2019-11-30', 'YYYY-MM-DD'), 'UI Developer', 'Software Development', 'Active', 'adobre.ui', STANDARD_HASH('adobre321', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (5, 'George', 'Stan', 'george.stan.frontend@company.com', '+40741234504', TO_DATE('2022-01-10', 'YYYY-MM-DD'), 'Frontend Developer', 'Software Development', 'On Leave', 'gstan.fe', STANDARD_HASH('gstan654', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (6, 'Bianca', 'Ilie', 'bianca.ilie.frontend@company.com', '+40741234505', TO_DATE('2023-06-01', 'YYYY-MM-DD'), 'Frontend Engineer', 'Software Development', 'Active', 'bilie.fe', STANDARD_HASH('bilie987', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (7, 'Andrei', 'Popescu', 'andrei.popescu.backend@company.com', '+40741234506', TO_DATE('2021-04-12', 'YYYY-MM-DD'), 'Backend Developer', 'Software Development', 'Active', 'apopescu.be', STANDARD_HASH('apopescuBE', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (8, 'Ioana', 'Matei', 'ioana.matei.backend@company.com', '+40741234507', TO_DATE('2020-07-20', 'YYYY-MM-DD'), 'Backend Developer', 'Software Development', 'Active', 'imatei.be', STANDARD_HASH('imateiBE', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (9, 'Florin', 'Badea', 'florin.badea.backend@company.com', '+40741234508', TO_DATE('2019-10-05', 'YYYY-MM-DD'), 'Backend Engineer', 'Software Development', 'Active', 'fbadea.be', STANDARD_HASH('fbadeaBE', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (10, 'Roxana', 'Petrescu', 'roxana.petrescu.backend@company.com', '+40741234509', TO_DATE('2022-05-18', 'YYYY-MM-DD'), 'Java Backend Developer', 'Software Development', 'On Leave', 'rpetrescu.be', STANDARD_HASH('rpetrescuBE', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (11, 'Darius', 'Voicu', 'darius.voicu.backend@company.com', '+40741234510', TO_DATE('2023-03-25', 'YYYY-MM-DD'), 'Node.js Developer', 'Software Development', 'Active', 'dvoicu.be', STANDARD_HASH('dvoicuBE', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (12, 'Alexandra', 'Munteanu', 'alexandra.munteanu.fullstack@company.com', '+40741234511', TO_DATE('2020-11-10', 'YYYY-MM-DD'), 'Full-Stack Developer', 'Software Development', 'Active', 'amunteanu.fs', STANDARD_HASH('amunteanuFS', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (13, 'Victor', 'Enache', 'victor.enache.fullstack@company.com', '+40741234512', TO_DATE('2019-06-15', 'YYYY-MM-DD'), 'Full-Stack Engineer', 'Software Development', 'Active', 'venache.fs', STANDARD_HASH('venacheFS', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (14, 'Diana', 'Tudor', 'diana.tudor.fullstack@company.com', '+40741234513', TO_DATE('2021-09-21', 'YYYY-MM-DD'), 'Senior Full-Stack Developer', 'Software Development', 'On Leave', 'dtudor.fs', STANDARD_HASH('dtudorFS', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (15, 'Razvan', 'Lupu', 'razvan.lupu.fullstack@company.com', '+40741234514', TO_DATE('2023-01-05', 'YYYY-MM-DD'), 'Full-Stack Developer', 'Software Development', 'Active', 'rlupu.fs', STANDARD_HASH('rlupuFS', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (16, 'Elena', 'Voinea', 'elena.voinea.fullstack@company.com', '+40741234515', TO_DATE('2022-04-29', 'YYYY-MM-DD'), 'React & Node Full-Stack Developer', 'Software Development', 'Active', 'evoinea.fs', STANDARD_HASH('evoineaFS', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (17, 'Anca', 'Mihalache', 'anca.mihalache.mobile@company.com', '+40741234516', TO_DATE('2021-08-12', 'YYYY-MM-DD'), 'iOS Developer', 'Software Development', 'Active', 'amihalache.mob', STANDARD_HASH('amihalacheMOB', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (18, 'Radu', 'Ionescu', 'radu.ionescu.mobile@company.com', '+40741234517', TO_DATE('2020-02-19', 'YYYY-MM-DD'), 'Android Developer', 'Software Development', 'Active', 'rionescu.mob', STANDARD_HASH('rionescuMOB', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (19, 'Sorina', 'Neagu', 'sorina.neagu.mobile@company.com', '+40741234518', TO_DATE('2022-06-25', 'YYYY-MM-DD'), 'React Native Developer', 'Software Development', 'On Leave', 'sneagu.mob', STANDARD_HASH('sneaguMOB', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (20, 'Paul', 'Dragan', 'paul.dragan.mobile@company.com', '+40741234519', TO_DATE('2023-03-10', 'YYYY-MM-DD'), 'Flutter Developer', 'Software Development', 'Active', 'pdragan.mob', STANDARD_HASH('pdraganMOB', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (21, 'Camelia', 'Zamfir', 'camelia.zamfir.mobile@company.com', '+40741234520', TO_DATE('2021-12-03', 'YYYY-MM-DD'), 'Mobile App Developer', 'Software Development', 'Active', 'czamfir.mob', STANDARD_HASH('czamfirMOB', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (22, 'Lavinia', 'Georgescu', 'lavinia.georgescu.qa@company.com', '+40741234521', TO_DATE('2022-08-17', 'YYYY-MM-DD'), 'QA Engineer', 'QA & Testing', 'Active', 'lgeorgescu.qa', STANDARD_HASH('lgeorgescuQA', 'SHA256'), 'Manager');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (23, 'Mihai', 'Barbu', 'mihai.barbu.manual@company.com', '+40741234522', TO_DATE('2021-03-15', 'YYYY-MM-DD'), 'Manual QA Engineer', 'QA & Testing', 'Active', 'mbarbu.manual', STANDARD_HASH('mbarbuMANUAL', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (24, 'Ilinca', 'Savu', 'ilinca.savu.manual@company.com', '+40741234523', TO_DATE('2020-11-30', 'YYYY-MM-DD'), 'Manual QA Tester', 'QA & Testing', 'Active', 'isavu.manual', STANDARD_HASH('isavuMANUAL', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (25, 'Cosmin', 'Vlad', 'cosmin.vlad.manual@company.com', '+40741234524', TO_DATE('2019-09-09', 'YYYY-MM-DD'), 'Junior Manual Tester', 'QA & Testing', 'Active', 'cvlad.manual', STANDARD_HASH('cvladMANUAL', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (26, 'Simona', 'Radu', 'simona.radu.manual@company.com', '+40741234525', TO_DATE('2022-05-22', 'YYYY-MM-DD'), 'Manual Test Analyst', 'QA & Testing', 'Active', 'sradu.manual', STANDARD_HASH('sraduMANUAL', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (27, 'Tudor', 'Costache', 'tudor.costache.manual@company.com', '+40741234526', TO_DATE('2023-02-10', 'YYYY-MM-DD'), 'Manual QA Specialist', 'QA & Testing', 'Active', 'tcostache.manual', STANDARD_HASH('tcostacheMANUAL', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (28, 'Iulia', 'Mocanu', 'iulia.mocanu.automated@company.com', '+40741234527', TO_DATE('2021-04-18', 'YYYY-MM-DD'), 'Automation QA Engineer', 'QA & Testing', 'Active', 'imocanu.auto', STANDARD_HASH('imocanuAUTO', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (29, 'Andrei', 'Baciu', 'andrei.baciu.automated@company.com', '+40741234528', TO_DATE('2019-10-02', 'YYYY-MM-DD'), 'SDET (Software Developer in Test)', 'QA & Testing', 'Active', 'abaciu.auto', STANDARD_HASH('abaciuAUTO', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (30, 'Elisa', 'Popa', 'elisa.popa.automated@company.com', '+40741234529', TO_DATE('2022-07-07', 'YYYY-MM-DD'), 'Test Automation Engineer', 'QA & Testing', 'Active', 'epopa.auto', STANDARD_HASH('epopaAUTO', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (31, 'Marius', 'Toma', 'marius.toma.automated@company.com', '+40741234530', TO_DATE('2020-12-15', 'YYYY-MM-DD'), 'QA Automation Specialist', 'QA & Testing', 'Active', 'mtoma.auto', STANDARD_HASH('mtomaAUTO', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (32, 'Bianca', 'Cristea', 'bianca.cristea.automated@company.com', '+40741234531', TO_DATE('2023-03-11', 'YYYY-MM-DD'), 'Senior Automation QA Engineer', 'QA & Testing', 'Active', 'bcristea.auto', STANDARD_HASH('bcristeaAUTO', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (33, 'Sebastian', 'Matei', 'sebastian.matei.performance@company.com', '+40741234532', TO_DATE('2021-06-20', 'YYYY-MM-DD'), 'Performance Tester', 'QA & Testing', 'Active', 'smatei.perf', STANDARD_HASH('smateiPERF', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (34, 'Oana', 'Petrescu', 'oana.petrescu.performance@company.com', '+40741234533', TO_DATE('2020-05-14', 'YYYY-MM-DD'), 'Load Testing Engineer', 'QA & Testing', 'Active', 'opetrescu.perf', STANDARD_HASH('opetrescuPERF', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (35, 'Vlad', 'Iliescu', 'vlad.iliescu.performance@company.com', '+40741234534', TO_DATE('2022-01-09', 'YYYY-MM-DD'), 'Stress Testing Engineer', 'QA & Testing', 'Active', 'viliescu.perf', STANDARD_HASH('viliescuPERF', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (36, 'Teodora', 'Marinescu', 'teodora.marinescu.performance@company.com', '+40741234535', TO_DATE('2019-09-30', 'YYYY-MM-DD'), 'Performance QA Analyst', 'QA & Testing', 'Active', 'tmarinescu.perf', STANDARD_HASH('tmarinescuPERF', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (37, 'Ciprian', 'Voicu', 'ciprian.voicu.performance@company.com', '+40741234536', TO_DATE('2023-04-05', 'YYYY-MM-DD'), 'Senior Performance Tester', 'QA & Testing', 'Active', 'cvoicu.perf', STANDARD_HASH('cvoicuPERF', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (38, 'Ana', 'Nedelcu', 'ana.nedelcu.security@company.com', '+40741234537', TO_DATE('2021-10-01', 'YYYY-MM-DD'), 'Security QA Engineer', 'QA & Testing', 'Active', 'anedelcu.sec', STANDARD_HASH('anedelcuSEC', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (39, 'Marius', 'Pavel', 'marius.pavel.security@company.com', '+40741234538', TO_DATE('2020-03-17', 'YYYY-MM-DD'), 'Penetration Tester', 'QA & Testing', 'Active', 'mpavel.sec', STANDARD_HASH('mpavelSEC', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (40, 'Ioana', 'Dragu', 'ioana.dragu.security@company.com', '+40741234539', TO_DATE('2022-08-21', 'YYYY-MM-DD'), 'Application Security Tester', 'QA & Testing', 'Active', 'idragu.sec', STANDARD_HASH('idraguSEC', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (41, 'Dorin', 'Marcu', 'dorin.marcu.security@company.com', '+40741234540', TO_DATE('2019-12-05', 'YYYY-MM-DD'), 'Vulnerability Analyst', 'QA & Testing', 'Active', 'dmarcu.sec', STANDARD_HASH('dmarcuSEC', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (42, 'Roxana', 'Petcu', 'roxana.petcu.security@company.com', '+40741234541', TO_DATE('2023-06-10', 'YYYY-MM-DD'), 'Security Test Analyst', 'QA & Testing', 'Active', 'rpetcu.sec', STANDARD_HASH('rpetcuSEC', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (43, 'Raluca', 'Enache', 'raluca.enache.mobile@company.com', '+40741234542', TO_DATE('2022-11-04', 'YYYY-MM-DD'), 'Mobile QA Engineer', 'QA & Testing', 'Active', 'renache.mobile', STANDARD_HASH('renacheMOBILE', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (44, 'Ionuț', 'Dima', 'ionut.dima.mobile@company.com', '+40741234543', TO_DATE('2021-09-15', 'YYYY-MM-DD'), 'iOS QA Tester', 'QA & Testing', 'Active', 'idima.mobile', STANDARD_HASH('idimaMOBILE', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (45, 'Cristina', 'Tudor', 'cristina.tudor.mobile@company.com', '+40741234544', TO_DATE('2020-04-09', 'YYYY-MM-DD'), 'Android QA Tester', 'QA & Testing', 'Active', 'ctudor.mobile', STANDARD_HASH('ctudorMOBILE', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (46, 'Bogdan', 'Voinea', 'bogdan.voinea.mobile@company.com', '+40741234545', TO_DATE('2023-01-23', 'YYYY-MM-DD'), 'Mobile App Test Engineer', 'QA & Testing', 'Active', 'bvoinea.mobile', STANDARD_HASH('bvoineaMOBILE', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (47, 'Simona', 'Lupu', 'simona.lupu.mobile@company.com', '+40741234546', TO_DATE('2021-06-30', 'YYYY-MM-DD'), 'Senior Mobile QA Specialist', 'QA & Testing', 'Active', 'slupu.mobile', STANDARD_HASH('slupuMOBILE', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (48, 'Mirela', 'Ciobanu', 'mirela.ciobanu.uiux@company.com', '+40741234547', TO_DATE('2022-02-11', 'YYYY-MM-DD'), 'UI Tester', 'QA & Testing', 'Active', 'mciobanu.uiux', STANDARD_HASH('mciobanuUIUX', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (49, 'Claudiu', 'Nemeș', 'claudiu.nemes.uiux@company.com', '+40741234548', TO_DATE('2020-10-06', 'YYYY-MM-DD'), 'UX Tester', 'QA & Testing', 'Active', 'cnemes.uiux', STANDARD_HASH('cnemesUIUX', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (50, 'Silvia', 'Georgescu', 'silvia.georgescu.uiux@company.com', '+40741234549', TO_DATE('2021-08-18', 'YYYY-MM-DD'), 'UI/UX QA Specialist', 'QA & Testing', 'Active', 'sgeorgescu.uiux', STANDARD_HASH('sgeorgescuUIUX', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (51, 'Paul', 'Barbu', 'paul.barbu.uiux@company.com', '+40741234550', TO_DATE('2023-04-03', 'YYYY-MM-DD'), 'UI/UX Test Analyst', 'QA & Testing', 'Active', 'pbarbu.uiux', STANDARD_HASH('pbarbuUIUX', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (52, 'Andreea', 'Manole', 'andreea.manole.uiux@company.com', '+40741234551', TO_DATE('2019-12-27', 'YYYY-MM-DD'), 'UI/UX Test Engineer', 'QA & Testing', 'Active', 'amanole.uiux', STANDARD_HASH('amanoleUIUX', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (53, 'Elena', 'Popa', 'elena.popa.agile@company.com', '+40741234552', TO_DATE('2020-09-01', 'YYYY-MM-DD'), 'Scrum Master', 'Project Management', 'Active', 'epopa.agile', STANDARD_HASH('epopaAGILE', 'SHA256'), 'Manager');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (54, 'Sorin', 'Matei', 'sorin.matei.agile@company.com', '+40741234553', TO_DATE('2019-06-15', 'YYYY-MM-DD'), 'Agile Project Manager', 'Project Management', 'Active', 'smatei.agile', STANDARD_HASH('smateiAGILE', 'SHA256'), 'Manager');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (55, 'Lavinia', 'Dobre', 'lavinia.dobre.agile@company.com', '+40741234554', TO_DATE('2021-02-20', 'YYYY-MM-DD'), 'Scrum Master', 'Project Management', 'Active', 'ldobre.agile', STANDARD_HASH('ldobreAGILE', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (56, 'Vlad', 'Ionescu', 'vlad.ionescu.agile@company.com', '+40741234555', TO_DATE('2022-07-11', 'YYYY-MM-DD'), 'Agile Coach', 'Project Management', 'Active', 'vionescu.agile', STANDARD_HASH('vionescuAGILE', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (57, 'Camelia', 'Radu', 'camelia.radu.agile@company.com', '+40741234556', TO_DATE('2023-03-30', 'YYYY-MM-DD'), 'Agile Delivery Manager', 'Project Management', 'Active', 'cradu.agile', STANDARD_HASH('craduAGILE', 'SHA256'), 'Manager');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (59, 'Dan', 'Lazăr', 'dan.lazar.waterfall@company.com', '+40741234557', TO_DATE('2018-05-12', 'YYYY-MM-DD'), 'Project Manager', 'Project Management', 'Active', 'dlazar.waterfall', STANDARD_HASH('dlazarWATERFALL', 'SHA256'), 'Manager');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (60, 'Monica', 'Neagu', 'monica.neagu.waterfall@company.com', '+40741234558', TO_DATE('2019-10-07', 'YYYY-MM-DD'), 'Senior Project Manager', 'Project Management', 'Active', 'mneagu.waterfall', STANDARD_HASH('mneaguWATERFALL', 'SHA256'), 'Manager');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (61, 'Gabriel', 'Tănase', 'gabriel.tanase.waterfall@company.com', '+40741234559', TO_DATE('2020-03-15', 'YYYY-MM-DD'), 'Technical Project Manager', 'Project Management', 'Active', 'gtanase.waterfall', STANDARD_HASH('gtanaseWATERFALL', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (62, 'Irina', 'Costache', 'irina.costache.waterfall@company.com', '+40741234560', TO_DATE('2021-04-22', 'YYYY-MM-DD'), 'IT Project Manager', 'Project Management', 'Active', 'icostache.waterfall', STANDARD_HASH('icostacheWATERFALL', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (63, 'Rareș', 'Preda', 'rares.preda.waterfall@company.com', '+40741234561', TO_DATE('2019-11-30', 'YYYY-MM-DD'), 'Infrastructure Project Manager', 'Project Management', 'Active', 'rpreda.waterfall', STANDARD_HASH('rpredaWATERFALL', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (69, 'Alexandra', 'Mureșan', 'alexandra.muresan.hybrid@company.com', '+40741234567', TO_DATE('2021-08-17', 'YYYY-MM-DD'), 'Hybrid Project Manager', 'Project Management', 'Active', 'amuresan.hybrid', STANDARD_HASH('amuresanHYBRID', 'SHA256'), 'Manager');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (70, 'Radu', 'Enache', 'radu.enache.hybrid@company.com', '+40741234568', TO_DATE('2020-11-04', 'YYYY-MM-DD'), 'Project Delivery Lead', 'Project Management', 'Active', 'renache.hybrid', STANDARD_HASH('renacheHYBRID', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (71, 'Ioana', 'Tudor', 'ioana.tudor.hybrid@company.com', '+40741234569', TO_DATE('2022-04-09', 'YYYY-MM-DD'), 'Project Supervisor', 'Project Management', 'Active', 'itudor.hybrid', STANDARD_HASH('itudorHYBRID', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (72, 'Vlad', 'Popescu', 'vlad.popescu.hybrid@company.com', '+40741234570', TO_DATE('2019-02-22', 'YYYY-MM-DD'), 'Senior Hybrid PM', 'Project Management', 'Active', 'vpopescu.hybrid', STANDARD_HASH('vpopescuHYBRID', 'SHA256'), 'Manager');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (73, 'Cristina', 'Moise', 'cristina.moise.hybrid@company.com', '+40741234571', TO_DATE('2023-06-01', 'YYYY-MM-DD'), 'PM Consultant', 'Project Management', 'Active', 'cmoise.hybrid', STANDARD_HASH('cmoiseHYBRID', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (74, 'Andreea', 'Matei', 'andreea.matei.program@company.com', '+40741234572', TO_DATE('2020-10-18', 'YYYY-MM-DD'), 'Program Manager', 'Project Management', 'Active', 'amatei.program', STANDARD_HASH('amateiPROGRAM', 'SHA256'), 'Manager');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (75, 'Sorin', 'Dumitrescu', 'sorin.dumitrescu.program@company.com', '+40741234573', TO_DATE('2019-07-01', 'YYYY-MM-DD'), 'Senior Program Manager', 'Project Management', 'Active', 'sdumitrescu.program', STANDARD_HASH('sdumitrescuPROGRAM', 'SHA256'), 'Manager');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (76, 'Elena', 'Stoica', 'elena.stoica.program@company.com', '+40741234574', TO_DATE('2021-03-12', 'YYYY-MM-DD'), 'Program Director', 'Project Management', 'Active', 'estoica.program', STANDARD_HASH('estoicaPROGRAM', 'SHA256'), 'Manager');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (77, 'Dragoș', 'Ionescu', 'dragos.ionescu.program@company.com', '+40741234575', TO_DATE('2022-08-23', 'YYYY-MM-DD'), 'Associate Program Manager', 'Project Management', 'Active', 'dionescu.program', STANDARD_HASH('dionescuPROGRAM', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (78, 'Lavinia', 'Georgescu', 'lavinia.georgescu.program@company.com', '+40741234576', TO_DATE('2023-01-05', 'YYYY-MM-DD'), 'Technical Program Manager', 'Project Management', 'Active', 'lgeorgescu.program', STANDARD_HASH('lgeorgescuPROGRAM', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (79, 'Raluca', 'Vasilescu', 'raluca.vasilescu.pmo@company.com', '+40741234577', TO_DATE('2020-02-14', 'YYYY-MM-DD'), 'PMO Coordinator', 'Project Management', 'Active', 'rvasilescu.pmo', STANDARD_HASH('rvasilescuPMO', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (80, 'Marius', 'Petcu', 'marius.petcu.pmo@company.com', '+40741234578', TO_DATE('2019-06-30', 'YYYY-MM-DD'), 'Project Coordinator', 'Project Management', 'Active', 'mpetcu.pmo', STANDARD_HASH('mpetcuPMO', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (81, 'Simona', 'Drăghici', 'simona.draghici.pmo@company.com', '+40741234579', TO_DATE('2021-11-11', 'YYYY-MM-DD'), 'PMO Analyst', 'Project Management', 'Active', 'sdraghici.pmo', STANDARD_HASH('sdraghiciPMO', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (82, 'Cosmin', 'Muntean', 'cosmin.muntean.pmo@company.com', '+40741234580', TO_DATE('2022-05-05', 'YYYY-MM-DD'), 'PMO Specialist', 'Project Management', 'Active', 'cmuntean.pmo', STANDARD_HASH('cmunteanPMO', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (83, 'Andreea', 'Nechita', 'andreea.nechita.pmo@company.com', '+40741234581', TO_DATE('2023-04-20', 'YYYY-MM-DD'), 'Project Management Officer', 'Project Management', 'Active', 'anechita.pmo', STANDARD_HASH('anechitaPMO', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (84, 'Mihai', 'Ionescu', 'mihai.ionescu.itsupport@company.com', '+40741234582', TO_DATE('2024-01-15', 'YYYY-MM-DD'), 'IT Support Specialist', 'IT Support / Helpdesk', 'Active', 'mionescu.it', STANDARD_HASH('mionescuIT', 'SHA256'), 'Manager');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (85, 'Daniel', 'Popa', 'daniel.popa.l1@company.com', '+40741234583', TO_DATE('2023-07-10', 'YYYY-MM-DD'), 'L1 Support Technician', 'IT Support / Helpdesk', 'Active', 'dpopa.l1', STANDARD_HASH('dpopaL1', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (86, 'Ioana', 'Radu', 'ioana.radu.l1@company.com', '+40741234584', TO_DATE('2022-05-20', 'YYYY-MM-DD'), 'L1 Support Specialist', 'IT Support / Helpdesk', 'Active', 'iradu.l1', STANDARD_HASH('raduL1', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (87, 'Alex', 'Marinescu', 'alex.marinescu.l1@company.com', '+40741234585', TO_DATE('2021-03-15', 'YYYY-MM-DD'), 'L1 Helpdesk Technician', 'IT Support / Helpdesk', 'Active', 'amarinescu.l1', STANDARD_HASH('amarinescuL1', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (88, 'Mara', 'Ionescu', 'mara.ionescu.l1@company.com', '+40741234586', TO_DATE('2023-01-12', 'YYYY-MM-DD'), 'Frontline Support Engineer', 'IT Support / Helpdesk', 'Active', 'mionescu.l1', STANDARD_HASH('mionescuL1', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (89, 'George', 'Toma', 'george.toma.l1@company.com', '+40741234587', TO_DATE('2022-11-01', 'YYYY-MM-DD'), 'Level 1 Support Analyst', 'IT Support / Helpdesk', 'Active', 'gtoma.l1', STANDARD_HASH('gtomaL1', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (90, 'Cătălin', 'Stan', 'catalin.stan.l2@company.com', '+40741234588', TO_DATE('2021-09-08', 'YYYY-MM-DD'), 'L2 Technical Support Engineer', 'IT Support / Helpdesk', 'Active', 'cstan.l2', STANDARD_HASH('cstanL2', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (91, 'Oana', 'Mitrea', 'oana.mitrea.l2@company.com', '+40741234589', TO_DATE('2020-04-25', 'YYYY-MM-DD'), 'Technical Support Specialist', 'IT Support / Helpdesk', 'Active', 'omitrea.l2', STANDARD_HASH('omitreaL2', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (92, 'Darius', 'Popescu', 'darius.popescu.l2@company.com', '+40741234590', TO_DATE('2019-12-03', 'YYYY-MM-DD'), 'L2 Support Analyst', 'IT Support / Helpdesk', 'Active', 'dpopescu.l2', STANDARD_HASH('dpopescuL2', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (93, 'Alina', 'Dragu', 'alina.dragu.l2@company.com', '+40741234591', TO_DATE('2022-06-18', 'YYYY-MM-DD'), 'IT Support Engineer L2', 'IT Support / Helpdesk', 'Active', 'adragu.l2', STANDARD_HASH('adraguL2', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (94, 'Vlad', 'Enache', 'vlad.enache.l2@company.com', '+40741234592', TO_DATE('2023-08-09', 'YYYY-MM-DD'), 'Second Level Support Engineer', 'IT Support / Helpdesk', 'Active', 'venache.l2', STANDARD_HASH('venacheL2', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (95, 'Teodor', 'Mihăilescu', 'teodor.mihailescu.l3@company.com', '+40741234593', TO_DATE('2018-03-12', 'YYYY-MM-DD'), 'L3 Support Engineer', 'IT Support / Helpdesk', 'Active', 'tmihailescu.l3', STANDARD_HASH('tmihailescuL3', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (96, 'Irina', 'Voinea', 'irina.voinea.l3@company.com', '+40741234594', TO_DATE('2020-10-01', 'YYYY-MM-DD'), 'Expert Support Analyst', 'IT Support / Helpdesk', 'Active', 'ivoinea.l3', STANDARD_HASH('ivoineaL3', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (97, 'Mihnea', 'Gheorghe', 'mihnea.gheorghe.l3@company.com', '+40741234595', TO_DATE('2019-01-27', 'YYYY-MM-DD'), 'L3 Infrastructure Specialist', 'IT Support / Helpdesk', 'Active', 'mgheorghe.l3', STANDARD_HASH('mgheorgheL3', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (98, 'Corina', 'Zaharia', 'corina.zaharia.l3@company.com', '+40741234596', TO_DATE('2021-07-14', 'YYYY-MM-DD'), 'Senior Support Engineer L3', 'IT Support / Helpdesk', 'Active', 'czaharia.l3', STANDARD_HASH('czahariaL3', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (99, 'Florin', 'Tănase', 'florin.tanase.l3@company.com', '+40741234597', TO_DATE('2022-02-05', 'YYYY-MM-DD'), 'L3 Technical Expert', 'IT Support / Helpdesk', 'Active', 'ftanase.l3', STANDARD_HASH('ftanaseL3', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (100, 'Raluca', 'Ilie', 'raluca.ilie.incident@company.com', '+40741234598', TO_DATE('2020-06-20', 'YYYY-MM-DD'), 'Incident Manager', 'IT Support / Helpdesk', 'Active', 'rilie.incident', STANDARD_HASH('rilieINCIDENT', 'SHA256'), 'Manager');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (101, 'Andrei', 'Neagu', 'andrei.neagu.incident@company.com', '+40741234599', TO_DATE('2019-08-11', 'YYYY-MM-DD'), 'Incident Response Specialist', 'IT Support / Helpdesk', 'Active', 'aneagu.incident', STANDARD_HASH('aneaguINCIDENT', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (102, 'Bianca', 'Matei', 'bianca.matei.incident@company.com', '+40741234600', TO_DATE('2021-09-30', 'YYYY-MM-DD'), 'IT Incident Coordinator', 'IT Support / Helpdesk', 'Active', 'bmatei.incident', STANDARD_HASH('bmateiINCIDENT', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (103, 'Sorin', 'Petrescu', 'sorin.petrescu.incident@company.com', '+40741234601', TO_DATE('2022-03-04', 'YYYY-MM-DD'), 'Major Incident Specialist', 'IT Support / Helpdesk', 'Active', 'spetrescu.incident', STANDARD_HASH('spetrescuINCIDENT', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (104, 'Elena', 'Cojocaru', 'elena.cojocaru.incident@company.com', '+40741234602', TO_DATE('2023-12-12', 'YYYY-MM-DD'), 'Incident Process Analyst', 'IT Support / Helpdesk', 'Active', 'ecojocaru.incident', STANDARD_HASH('ecojocaruINCIDENT', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (105, 'Roxana', 'Popa', 'roxana.popa.srm@company.com', '+40741234603', TO_DATE('2020-10-10', 'YYYY-MM-DD'), 'Service Request Coordinator', 'IT Support / Helpdesk', 'Active', 'rpopa.srm', STANDARD_HASH('rpopaSRM', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (106, 'Ion', 'Ciobanu', 'ion.ciobanu.srm@company.com', '+40741234604', TO_DATE('2021-03-15', 'YYYY-MM-DD'), 'Service Desk Analyst', 'IT Support / Helpdesk', 'Active', 'iciobanu.srm', STANDARD_HASH('iciobanuSRM', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (107, 'Georgiana', 'Tudor', 'georgiana.tudor.srm@company.com', '+40741234605', TO_DATE('2019-11-23', 'YYYY-MM-DD'), 'Service Request Specialist', 'IT Support / Helpdesk', 'Active', 'gtudor.srm', STANDARD_HASH('gtudorSRM', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (108, 'Cristian', 'Andone', 'cristian.andone.srm@company.com', '+40741234606', TO_DATE('2018-07-19', 'YYYY-MM-DD'), 'Request Fulfillment Analyst', 'IT Support / Helpdesk', 'Active', 'candone.srm', STANDARD_HASH('candoneSRM', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (109, 'Lavinia', 'Mureșan', 'lavinia.muresan.srm@company.com', '+40741234607', TO_DATE('2022-01-08', 'YYYY-MM-DD'), 'IT Service Request Officer', 'IT Support / Helpdesk', 'Active', 'lmuresan.srm', STANDARD_HASH('lmuresanSRM', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (110, 'Andreea', 'Barbu', 'andreea.barbu.asset@company.com', '+40741234608', TO_DATE('2021-06-14', 'YYYY-MM-DD'), 'IT Asset Coordinator', 'IT Asset Management', 'Active', 'abarbu.asset', STANDARD_HASH('abarbuASSET', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (111, 'Daniel', 'Mocanu', 'daniel.mocanu.asset@company.com', '+40741234609', TO_DATE('2020-12-01', 'YYYY-MM-DD'), 'IT Asset Manager', 'IT Asset Management', 'Active', 'dmocanu.asset', STANDARD_HASH('dmocanuASSET', 'SHA256'), 'Manager');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (112, 'Claudia', 'Petrică', 'claudia.petrica.asset@company.com', '+40741234610', TO_DATE('2022-04-20', 'YYYY-MM-DD'), 'IT Asset Analyst', 'IT Asset Management', 'Active', 'cpetrica.asset', STANDARD_HASH('cpetricaASSET', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (113, 'George', 'Marinescu', 'george.marinescu.asset@company.com', '+40741234611', TO_DATE('2019-09-07', 'YYYY-MM-DD'), 'Asset Lifecycle Specialist', 'IT Asset Management', 'Active', 'gmarinescu.asset', STANDARD_HASH('gmarinescuASSET', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (114, 'Ioana', 'Badea', 'ioana.badea.asset@company.com', '+40741234612', TO_DATE('2023-03-11', 'YYYY-MM-DD'), 'IT Inventory Administrator', 'IT Asset Management', 'Active', 'ibadea.asset', STANDARD_HASH('ibadeaASSET', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number,
Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES ( 115, 'Mihai', 'Stoica', 'mihai.stoica.infra@company.com', '+40741234613', TO_DATE('2021-08-19', 'YYYY-MM-DD'), 'System Administrator', 'Infrastructure / SysAdmin / Network', 'Active', 'mstoica.infra', STANDARD_HASH('mstoicaINFRA', 'SHA256'), 'Manager');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (116, 'Irina', 'Vlad', 'irina.vlad.sysadmin@company.com', '+40741234614', TO_DATE('2020-02-03', 'YYYY-MM-DD'), 'Linux System Administrator', 'Infrastructure / SysAdmin / Network', 'Active', 'ivlad.sysadmin', STANDARD_HASH('ivladSYSADMIN', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (117, 'Sorin', 'Georgescu', 'sorin.georgescu.sysadmin@company.com', '+40741234615', TO_DATE('2019-07-10', 'YYYY-MM-DD'), 'Windows System Administrator', 'Infrastructure / SysAdmin / Network', 'Active', 'sgeorgescu.sysadmin', STANDARD_HASH('sgeorgescuADMIN', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (118, 'Camelia', 'Dobre', 'camelia.dobre.sysadmin@company.com', '+40741234616', TO_DATE('2021-12-01', 'YYYY-MM-DD'), 'IT System Administrator', 'Infrastructure / SysAdmin / Network', 'Active', 'cdobre.sysadmin', STANDARD_HASH('cdobreADMIN', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (119, 'Vlad', 'Ionescu', 'vlad.ionescu.sysadmin@company.com', '+40741234617', TO_DATE('2022-09-18', 'YYYY-MM-DD'), 'Junior System Administrator', 'Infrastructure / SysAdmin / Network', 'Active', 'vionescu.sysadmin', STANDARD_HASH('vionescuADMIN', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (120, 'Adela', 'Marcu', 'adela.marcu.sysadmin@company.com', '+40741234618', TO_DATE('2018-04-22', 'YYYY-MM-DD'), 'Senior System Administrator', 'Infrastructure / SysAdmin / Network', 'Active', 'amarcu.sysadmin', STANDARD_HASH('amarcuADMIN', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (121, 'Florin', 'Mitrea', 'florin.mitrea.network@company.com', '+40741234619', TO_DATE('2019-06-11', 'YYYY-MM-DD'), 'Network Engineer', 'Infrastructure / SysAdmin / Network', 'Active', 'fmitrea.network', STANDARD_HASH('fmitreaNETWORK', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (122, 'Anca', 'Voicu', 'anca.voicu.network@company.com', '+40741234620', TO_DATE('2020-01-23', 'YYYY-MM-DD'), 'Junior Network Engineer', 'Infrastructure / SysAdmin / Network', 'Active', 'avoicu.network', STANDARD_HASH('avoicuNETWORK', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (123, 'Iulian', 'Enache', 'iulian.enache.network@company.com', '+40741234621', TO_DATE('2018-09-30', 'YYYY-MM-DD'), 'Senior Network Engineer', 'Infrastructure / SysAdmin / Network', 'Active', 'ienache.network', STANDARD_HASH('ienacheNETWORK', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (124, 'Simona', 'Preda', 'simona.preda.network@company.com', '+40741234622', TO_DATE('2022-03-12', 'YYYY-MM-DD'), 'Network Security Engineer', 'Infrastructure / SysAdmin / Network', 'Active', 'spreda.network', STANDARD_HASH('spredaNETWORK', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (125, 'Cristian', 'Ilie', 'cristian.ilie.network@company.com', '+40741234623', TO_DATE('2021-07-05', 'YYYY-MM-DD'), 'Network Infrastructure Engineer', 'Infrastructure / SysAdmin / Network', 'Active', 'cilie.network', STANDARD_HASH('cilieNETWORK', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (126, 'Raluca', 'Teodorescu', 'raluca.teodorescu.cloud@company.com', '+40741234624', TO_DATE('2020-05-10', 'YYYY-MM-DD'), 'Cloud Infrastructure Engineer', 'Infrastructure / SysAdmin / Network', 'Active', 'rteodorescu.cloud', STANDARD_HASH('rteodoresculoudCLOUD', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (127, 'Alexandru', 'Neagu', 'alexandru.neagu.cloud@company.com', '+40741234625', TO_DATE('2021-11-22', 'YYYY-MM-DD'), 'Cloud Solutions Architect', 'Infrastructure / SysAdmin / Network', 'Active', 'aneagu.cloud', STANDARD_HASH('aneaguCLOUD', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (128, 'Daniela', 'Grigorescu', 'daniela.grigorescu.cloud@company.com', '+40741234626', TO_DATE('2019-01-15', 'YYYY-MM-DD'), 'Cloud Administrator', 'Infrastructure / SysAdmin / Network', 'Active', 'dgrigorescu.cloud', STANDARD_HASH('dgrigorescuCLOUD', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (129, 'Bogdan', 'Pop', 'bogdan.pop.cloud@company.com', '+40741234627', TO_DATE('2022-08-08', 'YYYY-MM-DD'), 'DevOps Cloud Engineer', 'Infrastructure / SysAdmin / Network', 'Active', 'bpop.cloud', STANDARD_HASH('bpopCLOUD', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (130, 'Diana', 'Matei', 'diana.matei.cloud@company.com', '+40741234628', TO_DATE('2023-03-17', 'YYYY-MM-DD'), 'AWS Cloud Specialist', 'Infrastructure / SysAdmin / Network', 'Active', 'dmatei.cloud', STANDARD_HASH('dmateiCLOUD', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (131, 'Marius', 'Lupu', 'marius.lupu.virtual@company.com', '+40741234629', TO_DATE('2020-10-05', 'YYYY-MM-DD'), 'Virtualization Engineer', 'Infrastructure / SysAdmin / Network', 'Active', 'mlupu.virtual', STANDARD_HASH('mlupuVIRTUAL', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (132, 'Roxana', 'Ciobanu', 'roxana.ciobanu.storage@company.com', '+40741234630', TO_DATE('2021-05-19', 'YYYY-MM-DD'), 'Storage Administrator', 'Infrastructure / SysAdmin / Network', 'Active', 'rciobanu.storage', STANDARD_HASH('rciobanuSTORAGE', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (133, 'George', 'Petrescu', 'george.petrescu.vmware@company.com', '+40741234631', TO_DATE('2019-12-03', 'YYYY-MM-DD'), 'VMware Specialist', 'Infrastructure / SysAdmin / Network', 'Active', 'gpetrescu.vmware', STANDARD_HASH('gpetrescuVMWARE', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (134, 'Ioana', 'Fratila', 'ioana.fratila.storage@company.com', '+40741234632', TO_DATE('2022-06-27', 'YYYY-MM-DD'), 'SAN Storage Engineer', 'Infrastructure / SysAdmin / Network', 'Active', 'ifratila.storage', STANDARD_HASH('ifratilaSTORAGE', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (135, 'Sebastian', 'Maxim', 'sebastian.maxim.virtual@company.com', '+40741234633', TO_DATE('2018-11-14', 'YYYY-MM-DD'), 'Virtual Infrastructure Engineer', 'Infrastructure / SysAdmin / Network', 'Active', 'smaxim.virtual', STANDARD_HASH('smaximVIRTUAL', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (136, 'Emil', 'Dumitrescu', 'emil.dumitrescu.datacenter@company.com', '+40741234634', TO_DATE('2017-08-21', 'YYYY-MM-DD'), 'Data Center Technician', 'Infrastructure / SysAdmin / Network', 'Active', 'edumitrescu.dc', STANDARD_HASH('edumitrescuDC', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (137, 'Simona', 'Barbu', 'simona.barbu.datacenter@company.com', '+40741234635', TO_DATE('2019-04-15', 'YYYY-MM-DD'), 'Data Center Operations Specialist', 'Infrastructure / SysAdmin / Network', 'Active', 'sbarbu.dc', STANDARD_HASH('sbarbuDC', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (138, 'Radu', 'Stancu', 'radu.stancu.datacenter@company.com', '+40741234636', TO_DATE('2021-01-30', 'YYYY-MM-DD'), 'Data Center Manager', 'Infrastructure / SysAdmin / Network', 'Active', 'rstancu.dc', STANDARD_HASH('rstancuDC', 'SHA256'), 'Manager');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (139, 'Oana', 'Nechita', 'oana.nechita.datacenter@company.com', '+40741234637', TO_DATE('2022-10-12', 'YYYY-MM-DD'), 'Data Center Engineer', 'Infrastructure / SysAdmin / Network', 'Active', 'onechita.dc', STANDARD_HASH('onechitaDC', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (140, 'Vasile', 'Marinescu', 'vasile.marinescu.datacenter@company.com', '+40741234638', TO_DATE('2018-05-08', 'YYYY-MM-DD'), 'Data Center Technician', 'Infrastructure / SysAdmin / Network', 'Active', 'vmarinescu.dc', STANDARD_HASH('vmarinescuDC', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (141, 'Andrei', 'Popescu', 'andrei.popescu.infrasec@company.com', '+40741234639', TO_DATE('2020-09-10', 'YYYY-MM-DD'), 'Infrastructure Security Engineer', 'Infrastructure / SysAdmin / Network', 'Active', 'apopescu.infrasec', STANDARD_HASH('apopescuINFRASEC', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (142, 'Elena', 'Manea', 'elena.manea.infrasec@company.com', '+40741234640', TO_DATE('2019-11-15', 'YYYY-MM-DD'), 'Security Analyst', 'Infrastructure / SysAdmin / Network', 'Active', 'emanea.infrasec', STANDARD_HASH('emaneaINFRASEC', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (143, 'Mihai', 'Dragan', 'mihai.dragan.infrasec@company.com', '+40741234641', TO_DATE('2021-04-20', 'YYYY-MM-DD'), 'Infrastructure Security Specialist', 'Infrastructure / SysAdmin / Network', 'Active', 'mdragan.infrasec', STANDARD_HASH('mdraganINFRASEC', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (144, 'Anca', 'Rusu', 'anca.rusu.infrasec@company.com', '+40741234642', TO_DATE('2018-07-18', 'YYYY-MM-DD'), 'Network Security Engineer', 'Infrastructure / SysAdmin / Network', 'Active', 'arusu.infrasec', STANDARD_HASH('arusuINFRASEC', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (145, 'Victor', 'Stroe', 'victor.stroe.infrasec@company.com', '+40741234643', TO_DATE('2022-02-11', 'YYYY-MM-DD'), 'Infrastructure Security Manager', 'Infrastructure / SysAdmin / Network', 'Active', 'vstroe.infrasec', STANDARD_HASH('vstroeINFRASEC', 'SHA256'), 'Manager');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (146, 'Andreea', 'Popa', 'andreea.popa@company.com', '+40751234567', TO_DATE('2024-01-15', 'YYYY-MM-DD'), 'UI/UX Designer', 'UI/UX Design', 'Active', 'apopa', STANDARD_HASH('apopaUIUX', 'SHA256'), 'Manager');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (147, 'Cristian', 'Iliescu', 'cristian.iliescu.uxresearch@company.com', '+40751234568', TO_DATE('2023-06-20', 'YYYY-MM-DD'), 'UX Researcher', 'UI/UX Design', 'Active', 'ciliescu.ux', STANDARD_HASH('ciliescuUX', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (148, 'Raluca', 'Sandu', 'raluca.sandu.uxresearch@company.com', '+40751234569', TO_DATE('2022-08-15', 'YYYY-MM-DD'), 'UX Research Analyst', 'UI/UX Design', 'Active', 'rsandu.ux', STANDARD_HASH('rsanduUX', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (149, 'Mihnea', 'Popescu', 'mihnea.popescu.uxresearch@company.com', '+40751234570', TO_DATE('2021-11-10', 'YYYY-MM-DD'), 'Senior UX Researcher', 'UI/UX Design', 'Active', 'mpopescu.ux', STANDARD_HASH('mpopescuUX', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (150, 'Anca', 'Marinescu', 'anca.marinescu.uxresearch@company.com', '+40751234571', TO_DATE('2020-12-05', 'YYYY-MM-DD'), 'UX Research Specialist', 'UI/UX Design', 'Active', 'amarinescu.ux', STANDARD_HASH('amarinescuUX', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (151, 'Denis', 'Vasilescu', 'denis.vasilescu.uxresearch@company.com', '+40751234572', TO_DATE('2023-03-01', 'YYYY-MM-DD'), 'Junior UX Researcher', 'UI/UX Design', 'Active', 'dvasilescu.ux', STANDARD_HASH('dvasilescuUX', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (152, 'Gabriel', 'Toma', 'gabriel.toma.uir@company.com', '+40752345678', TO_DATE('2022-05-10', 'YYYY-MM-DD'), 'UI Researcher', 'UI/UX Design', 'Active', 'gtoma.uir', STANDARD_HASH('gtomaUIR', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (153, 'Irina', 'Lazar', 'irina.lazar.uir@company.com', '+40752345679', TO_DATE('2021-07-21', 'YYYY-MM-DD'), 'UI Research Analyst', 'UI/UX Design', 'Active', 'ilazar.uir', STANDARD_HASH('ilazarUIR', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (154, 'Paul', 'Enescu', 'paul.enescu.uir@company.com', '+40752345680', TO_DATE('2023-02-15', 'YYYY-MM-DD'), 'Senior UI Researcher', 'UI/UX Design', 'Active', 'penescu.uir', STANDARD_HASH('penescuUIR', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (155, 'Maria', 'Dragomir', 'maria.dragomir.uir@company.com', '+40752345681', TO_DATE('2020-11-30', 'YYYY-MM-DD'), 'UI Research Specialist', 'UI/UX Design', 'Active', 'mdragomir.uir', STANDARD_HASH('mdragomirUIR', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (156, 'Sorin', 'Petrescu', 'sorin.petrescu.uir@company.com', '+40752345682', TO_DATE('2019-09-18', 'YYYY-MM-DD'), 'Junior UI Researcher', 'UI/UX Design', 'Active', 'spetrescu.uir', STANDARD_HASH('spetrescuUIR', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (157, 'Iulia', 'Stoica', 'iulia.stoica.interaction@company.com', '+40753456789', TO_DATE('2021-03-12', 'YYYY-MM-DD'), 'Interaction Designer', 'UI/UX Design', 'Active', 'istoica.interaction', STANDARD_HASH('istoicaINTERACTION', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (158, 'Radu', 'Mihailescu', 'radu.mihailescu.interaction@company.com', '+40753456790', TO_DATE('2022-06-25', 'YYYY-MM-DD'), 'Senior Interaction Designer', 'UI/UX Design', 'Active', 'rmihailescu.interaction', STANDARD_HASH('rmihailescuINTERACTION', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (159, 'Denisa', 'Ionescu', 'denisa.ionescu.interaction@company.com', '+40753456791', TO_DATE('2023-01-08', 'YYYY-MM-DD'), 'Interaction Design Specialist', 'UI/UX Design', 'Active', 'dionescu.interaction', STANDARD_HASH('dionescuINTERACTION', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (160, 'Vlad', 'Georgescu', 'vlad.georgescu.interaction@company.com', '+40753456792', TO_DATE('2019-12-17', 'YYYY-MM-DD'), 'Interaction Designer', 'UI/UX Design', 'Active', 'vgeorgescu.interaction', STANDARD_HASH('vgeorgescuINTERACTION', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (161, 'Elena', 'Pop', 'elena.pop.interaction@company.com', '+40753456793', TO_DATE('2020-08-22', 'YYYY-MM-DD'), 'Junior Interaction Designer', 'UI/UX Design', 'Active', 'epop.interaction', STANDARD_HASH('epopINTERACTION', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (162, 'Mara', 'Iliescu', 'mara.iliescu.prototyping@company.com', '+40754567890', TO_DATE('2021-04-05', 'YYYY-MM-DD'), 'Prototyping Specialist', 'UI/UX Design', 'Active', 'miliescu.proto', STANDARD_HASH('miliescuPROTO', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (163, 'Sebastian', 'Marin', 'sebastian.marin.prototyping@company.com', '+40754567891', TO_DATE('2022-09-15', 'YYYY-MM-DD'), 'Prototyping Engineer', 'UI/UX Design', 'Active', 'smarin.proto', STANDARD_HASH('smarinPROTO', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (164, 'Alina', 'Georgescu', 'alina.georgescu.prototyping@company.com', '+40754567892', TO_DATE('2023-03-30', 'YYYY-MM-DD'), 'Junior Prototyping Designer', 'UI/UX Design', 'Active', 'ageorgescu.proto', STANDARD_HASH('ageorgescuPROTO', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (165, 'Mihai', 'Dumitrescu', 'mihai.dumitrescu.prototyping@company.com', '+40754567893', TO_DATE('2020-07-19', 'YYYY-MM-DD'), 'Prototyping Lead', 'UI/UX Design', 'Active', 'mdumitrescu.proto', STANDARD_HASH('mdumitrescuPROTO', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (166, 'Diana', 'Popescu', 'diana.popescu.prototyping@company.com', '+40754567894', TO_DATE('2019-11-25', 'YYYY-MM-DD'), 'Prototyping Analyst', 'UI/UX Design', 'Active', 'dpopescu.proto', STANDARD_HASH('dpopescuPROTO', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (167, 'Alexandru', 'Popa', 'alexandru.popa.infoarch@company.com', '+40755678901', TO_DATE('2021-10-12', 'YYYY-MM-DD'), 'Information Architect', 'UI/UX Design', 'Active', 'apopa.infoarch', STANDARD_HASH('apopaINFOARCH', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (168, 'Bianca', 'Stan', 'bianca.stan.infoarch@company.com', '+40755678902', TO_DATE('2022-01-15', 'YYYY-MM-DD'), 'Senior Information Architect', 'UI/UX Design', 'Active', 'bstan.infoarch', STANDARD_HASH('bstanINFOARCH', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (169, 'Claudiu', 'Matei', 'claudiu.matei.infoarch@company.com', '+40755678903', TO_DATE('2020-05-20', 'YYYY-MM-DD'), 'Information Architecture Specialist', 'UI/UX Design', 'Active', 'cmatei.infoarch', STANDARD_HASH('cmateiINFOARCH', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (170, 'Daniela', 'Enescu', 'daniela.enescu.infoarch@company.com', '+40755678904', TO_DATE('2019-11-10', 'YYYY-MM-DD'), 'Junior Information Architect', 'UI/UX Design', 'Active', 'denescu.infoarch', STANDARD_HASH('denescuINFOARCH', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (171, 'Emil', 'Dumitru', 'emil.dumitru.infoarch@company.com', '+40755678905', TO_DATE('2023-04-01', 'YYYY-MM-DD'), 'Information Architecture Analyst', 'UI/UX Design', 'Active', 'edumitru.infoarch', STANDARD_HASH('edumitruINFOARCH', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (172, 'Roxana', 'Ionescu', 'roxana.ionescu.accessibility@company.com', '+40756789012', TO_DATE('2022-03-14', 'YYYY-MM-DD'), 'Accessibility Designer', 'UI/UX Design', 'Active', 'rionescu.access', STANDARD_HASH('rionescuACCESS', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (173, 'Florian', 'Petrescu', 'florian.petrescu.accessibility@company.com', '+40756789013', TO_DATE('2021-06-28', 'YYYY-MM-DD'), 'Senior Accessibility Designer', 'UI/UX Design', 'Active', 'fpetrescu.access', STANDARD_HASH('fpetrescuACCESS', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (174, 'Adela', 'Marin', 'adela.marin.accessibility@company.com', '+40756789014', TO_DATE('2023-01-05', 'YYYY-MM-DD'), 'Accessibility Analyst', 'UI/UX Design', 'Active', 'amarin.access', STANDARD_HASH('amarinACCESS', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (175, 'Cezar', 'Dumitrescu', 'cezar.dumitrescu.accessibility@company.com', '+40756789015', TO_DATE('2019-09-22', 'YYYY-MM-DD'), 'Junior Accessibility Designer', 'UI/UX Design', 'Active', 'cdumitrescu.access', STANDARD_HASH('cdumitrescuACCESS', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (176, 'Mihnea', 'Popa', 'mihnea.popa.accessibility@company.com', '+40756789016', TO_DATE('2020-12-11', 'YYYY-MM-DD'), 'Accessibility Specialist', 'UI/UX Design', 'Active', 'mpopa.access', STANDARD_HASH('mpopaACCESS', 'SHA256'), 'User');


INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (177, 'Ioana', 'Preda', 'ioana.preda.rd@company.com', '+40757890123', TO_DATE('2023-08-01', 'YYYY-MM-DD'), 'R&D Specialist', 'Research & Development (R&D)', 'Active', 'ipreda.rd', STANDARD_HASH('ipredaRD', 'SHA256'), 'Manager');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (178, 'Andrei', 'Voinea', 'andrei.voinea.scires@company.com', '+40758900111', TO_DATE('2021-05-10', 'YYYY-MM-DD'), 'Scientific Researcher', 'Research & Development (R&D)', 'Active', 'avoinea.scires', STANDARD_HASH('avoineaSCIRES', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (179, 'Camelia', 'Munteanu', 'camelia.munteanu.scires@company.com', '+40758900112', TO_DATE('2020-08-23', 'YYYY-MM-DD'), 'Senior Scientific Researcher', 'Research & Development (R&D)', 'Active', 'cmunteanu.scires', STANDARD_HASH('cmunteanuSCIRES', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (180, 'Ovidiu', 'Dragomir', 'ovidiu.dragomir.scires@company.com', '+40758900113', TO_DATE('2022-01-17', 'YYYY-MM-DD'), 'Scientific Analyst', 'Research & Development (R&D)', 'Active', 'odragomir.scires', STANDARD_HASH('odragomirSCIRES', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (181, 'Sorina', 'Badea', 'sorina.badea.scires@company.com', '+40758900114', TO_DATE('2019-04-12', 'YYYY-MM-DD'), 'Junior Scientific Researcher', 'Research & Development (R&D)', 'Active', 'sbadea.scires', STANDARD_HASH('sbadeaSCIRES', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (182, 'Gabriel', 'Cristea', 'gabriel.cristea.scires@company.com', '+40758900115', TO_DATE('2023-03-09', 'YYYY-MM-DD'), 'Scientific Project Coordinator', 'Research & Development (R&D)', 'Active', 'gcristea.scires', STANDARD_HASH('gcristeaSCIRES', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (183, 'Teodora', 'Popescu', 'teodora.popescu.innov@company.com', '+40758900116', TO_DATE('2021-11-03', 'YYYY-MM-DD'), 'Innovation Strategist', 'Research & Development (R&D)', 'Active', 'tpopescu.innov', STANDARD_HASH('tpopescuINNOV', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (184, 'Iulian', 'Voicu', 'iulian.voicu.innov@company.com', '+40758900117', TO_DATE('2020-06-14', 'YYYY-MM-DD'), 'Tech Innovation Analyst', 'Research & Development (R&D)', 'Active', 'ivoicu.innov', STANDARD_HASH('ivoicuINNOV', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (185, 'Elena', 'Neagu', 'elena.neagu.innov@company.com', '+40758900118', TO_DATE('2022-09-20', 'YYYY-MM-DD'), 'Technology Innovation Consultant', 'Research & Development (R&D)', 'Active', 'eneagu.innov', STANDARD_HASH('eneaguINNOV', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (186, 'Alexandru', 'Grigore', 'alexandru.grigore.innov@company.com', '+40758900119', TO_DATE('2023-05-08', 'YYYY-MM-DD'), 'Innovation Technologist', 'Research & Development (R&D)', 'Active', 'agrigore.innov', STANDARD_HASH('agrigoreINNOV', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (187, 'Corina', 'Matei', 'corina.matei.innov@company.com', '+40758900120', TO_DATE('2019-01-31', 'YYYY-MM-DD'), 'Innovation Manager', 'Research & Development (R&D)', 'Active', 'cmatei.innov', STANDARD_HASH('cmateiINNOV', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (188, 'Marius', 'Călin', 'marius.calin.hwdev@company.com', '+40758900121', TO_DATE('2021-04-12', 'YYYY-MM-DD'), 'Hardware Engineer', 'Research & Development (R&D)', 'Active', 'mcalin.hwdev', STANDARD_HASH('mcalinHWDEV', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (189, 'Raluca', 'Voiculescu', 'raluca.voiculescu.hwdev@company.com', '+40758900122', TO_DATE('2020-12-01', 'YYYY-MM-DD'), 'Embedded Systems Developer', 'Research & Development (R&D)', 'Active', 'rvoiculescu.hwdev', STANDARD_HASH('rvoiculescuHWDEV', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (190, 'George', 'Stan', 'george.stan.hwdev@company.com', '+40758900123', TO_DATE('2022-07-19', 'YYYY-MM-DD'), 'Electronics Design Engineer', 'Research & Development (R&D)', 'Active', 'gstan.hwdev', STANDARD_HASH('gstanHWDEV', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (191, 'Anca', 'Georgescu', 'anca.georgescu.hwdev@company.com', '+40758900124', TO_DATE('2023-03-25', 'YYYY-MM-DD'), 'PCB Layout Designer', 'Research & Development (R&D)', 'Active', 'ageorgescu.hwdev', STANDARD_HASH('ageorgescuHWDEV', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (192, 'Cristian', 'Enache', 'cristian.enache.hwdev@company.com', '+40758900125', TO_DATE('2018-10-09', 'YYYY-MM-DD'), 'Hardware Development Lead', 'Research & Development (R&D)', 'Active', 'cenache.hwdev', STANDARD_HASH('cenacheHWDEV', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (193, 'Irina', 'Barbu', 'irina.barbu.mresearch@company.com', '+40758900126', TO_DATE('2022-08-05', 'YYYY-MM-DD'), 'Market Research Analyst', 'Research & Development (R&D)', 'Active', 'ibarbu.mresearch', STANDARD_HASH('ibarbuMRESEARCH', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (194, 'Cosmin', 'Mihăilă', 'cosmin.mihaiala.mresearch@company.com', '+40758900127', TO_DATE('2021-02-18', 'YYYY-MM-DD'), 'Market Data Specialist', 'Research & Development (R&D)', 'Active', 'cmihaiala.mresearch', STANDARD_HASH('cmihaialaMRESEARCH', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (195, 'Diana', 'Preda', 'diana.preda.mresearch@company.com', '+40758900128', TO_DATE('2020-05-23', 'YYYY-MM-DD'), 'Consumer Insight Specialist', 'Research & Development (R&D)', 'Active', 'dpreda.mresearch', STANDARD_HASH('dpredaRESEARCH', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (196, 'Octavian', 'Tudor', 'octavian.tudor.mresearch@company.com', '+40758900129', TO_DATE('2019-12-09', 'YYYY-MM-DD'), 'Competitive Intelligence Analyst', 'Research & Development (R&D)', 'Active', 'otudor.mresearch', STANDARD_HASH('otudorMRESEARCH', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (197, 'Monica', 'Savu', 'monica.savu.mresearch@company.com', '+40758900130', TO_DATE('2023-06-01', 'YYYY-MM-DD'), 'Market Trends Analyst', 'Research & Development (R&D)', 'Active', 'msavu.mresearch', STANDARD_HASH('msavuMRESEARCH', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (198, 'Alexandru', 'Grigorescu', 'alexandru.grigorescu.exp@company.com', '+40758900131', TO_DATE('2023-01-15', 'YYYY-MM-DD'), 'Experimental Project Engineer', 'Research & Development (R&D)', 'Active', 'agrigorescu.exp', STANDARD_HASH('agrigorescuEXP', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (199, 'Bianca', 'Iordache', 'bianca.iordache.exp@company.com', '+40758900132', TO_DATE('2022-09-08', 'YYYY-MM-DD'), 'R&D Experimentalist', 'Research & Development (R&D)', 'Active', 'biordache.exp', STANDARD_HASH('biordacheEXP', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (200, 'Sorin', 'Matei', 'sorin.matei.exp@company.com', '+40758900133', TO_DATE('2021-06-20', 'YYYY-MM-DD'), 'Experimental Researcher', 'Research & Development (R&D)', 'Active', 'smatei.exp', STANDARD_HASH('smateiEXP', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (201, 'Teodora', 'Dumitrescu', 'teodora.dumitrescu.exp@company.com', '+40758900134', TO_DATE('2020-11-04', 'YYYY-MM-DD'), 'Prototype Testing Engineer', 'Research & Development (R&D)', 'Active', 'tdumitrescu.exp', STANDARD_HASH('tdumitrescuEXP', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (202, 'Lucian', 'Neagu', 'lucian.neagu.exp@company.com', '+40758900135', TO_DATE('2019-03-30', 'YYYY-MM-DD'), 'Innovation Project Developer', 'Research & Development (R&D)', 'Active', 'lneagu.exp', STANDARD_HASH('lneaguEXP', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (203, 'Andreea', 'Popa', 'andreea.popa.validation@company.com', '+40758900136', TO_DATE('2021-10-12', 'YYYY-MM-DD'), 'Validation Engineer', 'Research & Development (R&D)', 'Active', 'apopa.validation', STANDARD_HASH('apopaVALIDATION', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (204, 'Mihai', 'Vlad', 'mihai.vlad.testing@company.com', '+40758900137', TO_DATE('2020-04-08', 'YYYY-MM-DD'), 'Testing Specialist', 'Research & Development (R&D)', 'Active', 'mvlad.testing', STANDARD_HASH('mvladTESTING', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (205, 'Ioana', 'Cristea', 'ioana.cristea.validation@company.com', '+40758900138', TO_DATE('2022-06-18', 'YYYY-MM-DD'), 'Test Validation Analyst', 'Research & Development (R&D)', 'Active', 'icristea.validation', STANDARD_HASH('icristeaVALIDATION', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (206, 'Radu', 'Petrescu', 'radu.petrescu.testing@company.com', '+40758900139', TO_DATE('2019-12-01', 'YYYY-MM-DD'), 'Systems Tester', 'Research & Development (R&D)', 'Active', 'rpetrescu.testing', STANDARD_HASH('rpetrescuTESTING', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (207, 'Elena', 'Drăghici', 'elena.draghici.validation@company.com', '+40758900140', TO_DATE('2023-03-22', 'YYYY-MM-DD'), 'R&D Validation Coordinator', 'Research & Development (R&D)', 'Active', 'edraghici.validation', STANDARD_HASH('edraghiciVALIDATION', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (208, 'Irina', 'Voinea', 'irina.voinea@company.com', '+40758900141', TO_DATE('2022-08-10', 'YYYY-MM-DD'), 'Product Manager', 'Product Management', 'Active', 'ivoinea', STANDARD_HASH('ivoineaPMAN', 'SHA256'), 'Manager');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (209, 'Andrei', 'Costache', 'andrei.costache.strategy@company.com', '+40758900142', TO_DATE('2021-05-12', 'YYYY-MM-DD'), 'Product Strategy Analyst', 'Product Management', 'Active', 'acostache.strategy', STANDARD_HASH('acostacheSTRATEGY', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (210, 'Delia', 'Popescu', 'delia.popescu.planning@company.com', '+40758900143', TO_DATE('2020-11-09', 'YYYY-MM-DD'), 'Strategic Product Planner', 'Product Management', 'Active', 'dpopescu.planning', STANDARD_HASH('dpopescuPLANNING', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (211, 'Roxana', 'Mihailescu', 'roxana.mihailescu.strategy@company.com', '+40758900144', TO_DATE('2019-07-30', 'YYYY-MM-DD'), 'Product Strategy Consultant', 'Product Management', 'Active', 'rmihailescu.strategy', STANDARD_HASH('rmihailescuSTRATEGY', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (212, 'Vlad', 'Neacsu', 'vlad.neacsu.planning@company.com', '+40758900145', TO_DATE('2022-04-01', 'YYYY-MM-DD'), 'Senior Product Planner', 'Product Management', 'Active', 'vneacsu.planning', STANDARD_HASH('vneacsuPLANNING', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (213, 'Simona', 'Voicu', 'simona.voicu.strategy@company.com', '+40758900146', TO_DATE('2023-01-18', 'YYYY-MM-DD'), 'Product Strategy Manager', 'Product Management', 'Active', 'svoicu.strategy', STANDARD_HASH('svoicuSTRATEGY', 'SHA256'), 'Manager');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (214, 'Marius', 'Badea', 'marius.badea.owner@company.com', '+40758900147', TO_DATE('2021-02-20', 'YYYY-MM-DD'), 'Product Owner', 'Product Management', 'Active', 'mbadea.owner', STANDARD_HASH('mbadeaOWNER', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (215, 'Raluca', 'Georgescu', 'raluca.georgescu.po@company.com', '+40758900148', TO_DATE('2022-06-11', 'YYYY-MM-DD'), 'Senior Product Owner', 'Product Management', 'Active', 'rgeorgescu.po', STANDARD_HASH('rgeorgescuPO', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (216, 'Ionut', 'Preda', 'ionut.preda.ownership@company.com', '+40758900149', TO_DATE('2020-09-04', 'YYYY-MM-DD'), 'Technical Product Owner', 'Product Management', 'Active', 'ipreda.ownership', STANDARD_HASH('ipredaOWNERSHIP', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (217, 'Cristina', 'Matei', 'cristina.matei.owner@company.com', '+40758900150', TO_DATE('2019-12-14', 'YYYY-MM-DD'), 'Product Owner', 'Product Management', 'Active', 'cmatei.owner', STANDARD_HASH('cmateiOWNER', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (218, 'Tudor', 'Ionescu', 'tudor.ionescu.po@company.com', '+40758900151', TO_DATE('2023-03-05', 'YYYY-MM-DD'), 'Junior Product Owner', 'Product Management', 'Active', 'tionescu.po', STANDARD_HASH('tionescuPO', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (219, 'Sebastian', 'Munteanu', 'sebastian.munteanu.techpm@company.com', '+40758900152', TO_DATE('2020-08-15', 'YYYY-MM-DD'), 'Technical Product Manager', 'Product Management', 'Active', 'smunteanu.techpm', STANDARD_HASH('smunteanuTECHPM', 'SHA256'), 'Manager');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (220, 'Gabriela', 'Stan', 'gabriela.stan.techpm@company.com', '+40758900153', TO_DATE('2021-03-23', 'YYYY-MM-DD'), 'Technical Product Manager', 'Product Management', 'Active', 'gstan.techpm', STANDARD_HASH('gstanTECHPM', 'SHA256'), 'Manager');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (221, 'Florin', 'Pop', 'florin.pop.techpm@company.com', '+40758900154', TO_DATE('2019-12-01', 'YYYY-MM-DD'), 'Technical Product Manager', 'Product Management', 'Active', 'fpop.techpm', STANDARD_HASH('fpopTECHPM', 'SHA256'), 'Manager');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (222, 'Adriana', 'Neagu', 'adriana.neagu.techpm@company.com', '+40758900155', TO_DATE('2022-01-10', 'YYYY-MM-DD'), 'Technical Product Manager', 'Product Management', 'Active', 'aneagu.techpm', STANDARD_HASH('aneaguTECHPM', 'SHA256'), 'Manager');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (223, 'Daniel', 'Marin', 'daniel.marin.techpm@company.com', '+40758900156', TO_DATE('2023-04-18', 'YYYY-MM-DD'), 'Technical Product Manager', 'Product Management', 'Active', 'dmarin.techpm', STANDARD_HASH('dmarinTECHPM', 'SHA256'), 'Manager');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (224, 'Elena', 'Popa', 'elena.popa.growth@company.com', '+40758900157', TO_DATE('2021-07-14', 'YYYY-MM-DD'), 'Growth Product Manager', 'Product Management', 'Active', 'epopa.growth', STANDARD_HASH('epopaGROWTH', 'SHA256'), 'Manager');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (225, 'Mihai', 'Dragomir', 'mihai.dragomir.growth@company.com', '+40758900158', TO_DATE('2020-09-25', 'YYYY-MM-DD'), 'Growth Product Specialist', 'Product Management', 'Active', 'mdragomir.growth', STANDARD_HASH('mdragomirGROWTH', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (226, 'Ioana', 'Toma', 'ioana.toma.growth@company.com', '+40758900159', TO_DATE('2019-11-18', 'YYYY-MM-DD'), 'Growth Product Analyst', 'Product Management', 'Active', 'itoma.growth', STANDARD_HASH('itomaGROWTH', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (227, 'Alexandru', 'Serban', 'alexandru.serban.growth@company.com', '+40758900160', TO_DATE('2022-03-30', 'YYYY-MM-DD'), 'Growth Product Owner', 'Product Management', 'Active', 'aserban.growth', STANDARD_HASH('aserbanGROWTH', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (228, 'Cristina', 'Neagu', 'cristina.neagu.growth@company.com', '+40758900161', TO_DATE('2023-05-12', 'YYYY-MM-DD'), 'Growth Product Analyst', 'Product Management', 'Active', 'cneagu.growth', STANDARD_HASH('cneaguGROWTH', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (229, 'Andrei', 'Ionescu', 'andrei.ionescu.platform@company.com', '+40758900162', TO_DATE('2021-04-19', 'YYYY-MM-DD'), 'Platform Product Manager', 'Product Management', 'Active', 'aionescu.platform', STANDARD_HASH('aionescuPLATFORM', 'SHA256'), 'Manager');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (230, 'Maria', 'Petrescu', 'maria.petrescu.platform@company.com', '+40758900163', TO_DATE('2020-08-27', 'YYYY-MM-DD'), 'Platform Product Specialist', 'Product Management', 'Active', 'mpetrescu.platform', STANDARD_HASH('mpetrescuPLATFORM', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (231, 'Bogdan', 'Stanescu', 'bogdan.stanescu.platform@company.com', '+40758900164', TO_DATE('2019-12-10', 'YYYY-MM-DD'), 'Platform Product Manager', 'Product Management', 'Active', 'bstanescu.platform', STANDARD_HASH('bstanescuPLATFORM', 'SHA256'), 'Manager');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (232, 'Elisa', 'Dumitrescu', 'elisa.dumitrescu.platform@company.com', '+40758900165', TO_DATE('2022-05-06', 'YYYY-MM-DD'), 'Platform Product Owner', 'Product Management', 'Active', 'edumitrescu.platform', STANDARD_HASH('edumitrescuPLATFORM', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (233, 'Radu', 'Iancu', 'radu.iancu.platform@company.com', '+40758900166', TO_DATE('2023-03-02', 'YYYY-MM-DD'), 'Platform Product Analyst', 'Product Management', 'Active', 'riancu.platform', STANDARD_HASH('riancuPLATFORM', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (234, 'Simona', 'Ionescu', 'simona.ionescu.custexp@company.com', '+40758900167', TO_DATE('2022-06-15', 'YYYY-MM-DD'), 'Customer Experience Manager', 'Product Management', 'Active', 'sionescu.custexp', STANDARD_HASH('sionescuCUSTEXP', 'SHA256'), 'Manager');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (235, 'Bogdan', 'Marinescu', 'bogdan.marinescu.custexp@company.com', '+40758900168', TO_DATE('2021-09-20', 'YYYY-MM-DD'), 'Customer Feedback Specialist', 'Product Management', 'Active', 'bmarinescu.custexp', STANDARD_HASH('bmarinescuCUSTEXP', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (236, 'Adriana', 'Popescu', 'adriana.popescu.custexp@company.com', '+40758900169', TO_DATE('2020-12-05', 'YYYY-MM-DD'), 'Customer Experience Analyst', 'Product Management', 'Active', 'apopescu.custexp', STANDARD_HASH('apopescuCUSTEXP', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (237, 'Cristian', 'Neagu', 'cristian.neagu.custexp@company.com', '+40758900170', TO_DATE('2023-01-18', 'YYYY-MM-DD'), 'Customer Feedback Coordinator', 'Product Management', 'Active', 'cneagu.custexp', STANDARD_HASH('cneaguCUSTEXP', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (238, 'Daniela', 'Iancu', 'daniela.iancu.custexp@company.com', '+40758900171', TO_DATE('2023-04-01', 'YYYY-MM-DD'), 'Customer Experience Analyst', 'Product Management', 'Active', 'diancu.custexp', STANDARD_HASH('diancuCUSTEXP', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (239, 'Andreea', 'Popescu', 'andreea.popescu@company.com', '+40758900200', TO_DATE('2022-11-15', 'YYYY-MM-DD'), 'Data Analyst', 'Data / BI / Analytics', 'Active', 'apopescu', STANDARD_HASH('apopescuDATA', 'SHA256'), 'Manager');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (240, 'Roxana', 'Dumitrescu', 'roxana.dumitrescu@company.com', '+40758900201', TO_DATE('2021-08-10', 'YYYY-MM-DD'), 'Data Engineer', 'Data / BI / Analytics', 'Active', 'rdumitrescu', STANDARD_HASH('rdumitrescuDATA', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (241, 'Vlad', 'Marin', 'vlad.marin@company.com', '+40758900202', TO_DATE('2020-06-22', 'YYYY-MM-DD'), 'Senior Data Engineer', 'Data / BI / Analytics', 'Active', 'vmarin', STANDARD_HASH('vmarinDATA', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (242, 'Mihnea', 'Stoica', 'mihnea.stoica@company.com', '+40758900203', TO_DATE('2019-11-05', 'YYYY-MM-DD'), 'Data Engineer', 'Data / BI / Analytics', 'Active', 'mstoica', STANDARD_HASH('mstoicaDATA', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (243, 'Elena', 'Grigorescu', 'elena.grigorescu@company.com', '+40758900204', TO_DATE('2022-01-30', 'YYYY-MM-DD'), 'Data Engineer', 'Data / BI / Analytics', 'Active', 'egrigorescu', STANDARD_HASH('egrigorescu', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (244, 'Andrei', 'Niculae', 'andrei.niculae@company.com', '+40758900205', TO_DATE('2023-04-10', 'YYYY-MM-DD'), 'Junior Data Engineer', 'Data / BI / Analytics', 'Active', 'aniculae', STANDARD_HASH('aniculaeDATA', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (245, 'Gabriel', 'Tudor', 'gabriel.tudor.bi@company.com', '+40758900206', TO_DATE('2020-09-14', 'YYYY-MM-DD'), 'BI Developer', 'Data / BI / Analytics', 'Active', 'gtudor', STANDARD_HASH('gtudorDATA', 'SHA256'), 'Team Leaderr');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (246, 'Irina', 'Marinescu', 'irina.marinescu.bi@company.com', '+40758900207', TO_DATE('2021-11-23', 'YYYY-MM-DD'), 'Senior BI Developer', 'Data / BI / Analytics', 'Active', 'imarinescu', STANDARD_HASH('imarinescuDATA', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (247, 'Mihai', 'Costin', 'mihai.costin.bi@company.com', '+40758900208', TO_DATE('2019-05-19', 'YYYY-MM-DD'), 'BI Developer', 'Data / BI / Analytics', 'Active', 'mcostin', STANDARD_HASH('mcostinDATA', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (248, 'Larisa', 'Popa', 'larisa.popa.bi@company.com', '+40758900209', TO_DATE('2022-03-12', 'YYYY-MM-DD'), 'BI Analyst', 'Data / BI / Analytics', 'Active', 'lpopa', STANDARD_HASH('lpopaDATA', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (249, 'Andreea', 'Mihai', 'andreea.mihai.bi@company.com', '+40758900210', TO_DATE('2023-06-01', 'YYYY-MM-DD'), 'Junior BI Developer', 'Data / BI / Analytics', 'Active', 'amihai', STANDARD_HASH('amihaiDATA', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (250, 'Alina', 'Radu', 'alina.radu.analysis@company.com', '+40758900211', TO_DATE('2021-07-15', 'YYYY-MM-DD'), 'Business Analyst', 'Data / BI / Analytics', 'Active', 'aradu', STANDARD_HASH('araduDATA', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (251, 'Bogdan', 'Munteanu', 'bogdan.munteanu.analysis@company.com', '+40758900212', TO_DATE('2020-11-20', 'YYYY-MM-DD'), 'Data Analyst', 'Data / BI / Analytics', 'Active', 'bmunteanu', STANDARD_HASH('bmunteanuDATA', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (252, 'Cristina', 'Ionescu', 'cristina.ionescu.analysis@company.com', '+40758900213', TO_DATE('2019-05-05', 'YYYY-MM-DD'), 'Senior Business Analyst', 'Data / BI / Analytics', 'Active', 'cionescu', STANDARD_HASH('cionescuDATA', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (253, 'Mihai', 'Popescu', 'mihai.popescu.analysis@company.com', '+40758900214', TO_DATE('2022-02-10', 'YYYY-MM-DD'), 'Business Data Analyst', 'Data / BI / Analytics', 'Active', 'mpopescu', STANDARD_HASH('mpopescuDATA', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (254, 'Elena', 'Dumitrescu', 'elena.dumitrescu.analysis@company.com', '+40758900215', TO_DATE('2023-01-20', 'YYYY-MM-DD'), 'Junior Business Analyst', 'Data / BI / Analytics', 'Active', 'edumitrescu', STANDARD_HASH('edumitrescuDATA', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (255, 'Andrei', 'Voinea', 'andrei.voinea.datasci@company.com', '+40758900216', TO_DATE('2021-06-01', 'YYYY-MM-DD'), 'Data Scientist', 'Data / BI / Analytics', 'Active', 'avoinea', STANDARD_HASH('avoineaDATA', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (256, 'Bianca', 'Stancu', 'bianca.stancu.datasci@company.com', '+40758900217', TO_DATE('2020-09-15', 'YYYY-MM-DD'), 'Senior Data Scientist', 'Data / BI / Analytics', 'Active', 'bstancu', STANDARD_HASH('bstancuDATA', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (257, 'Cosmin', 'Ionescu', 'cosmin.ionescu.datasci@company.com', '+40758900218', TO_DATE('2019-11-20', 'YYYY-MM-DD'), 'Data Scientist', 'Data / BI / Analytics', 'Active', 'cionescu', STANDARD_HASH('cionescuDATA', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (258, 'Elena', 'Mihailescu', 'elena.mihailescu.datasci@company.com', '+40758900219', TO_DATE('2022-04-10', 'YYYY-MM-DD'), 'Data Scientist', 'Data / BI / Analytics', 'Active', 'emihailescu', STANDARD_HASH('emihailescuDATA', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (259, 'Radu', 'Niculae', 'radu.niculae.datasci@company.com', '+40758900220', TO_DATE('2023-03-01', 'YYYY-MM-DD'), 'Junior Data Scientist', 'Data / BI / Analytics', 'Active', 'rniculae', STANDARD_HASH('rniculaeDATA', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (260, 'Andreea', 'Georgescu', 'andreea.georgescu.mlops@company.com', '+40758900221', TO_DATE('2021-08-05', 'YYYY-MM-DD'), 'MLOps Engineer', 'Data / BI / Analytics', 'Active', 'ageorgescu', STANDARD_HASH('ageorgescuDATA', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (261, 'Bogdan', 'Vlad', 'bogdan.vlad.mlops@company.com', '+40758900222', TO_DATE('2020-12-10', 'YYYY-MM-DD'), 'Senior MLOps Engineer', 'Data / BI / Analytics', 'Active', 'bvlad', STANDARD_HASH('bvladDATA', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (262, 'Cristina', 'Iordache', 'cristina.iordache.mlops@company.com', '+40758900223', TO_DATE('2019-10-15', 'YYYY-MM-DD'), 'MLOps Engineer', 'Data / BI / Analytics', 'Active', 'ciordache', STANDARD_HASH('ciordacheDATA', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (263, 'Dan', 'Popa', 'dan.popa.mlops@company.com', '+40758900224', TO_DATE('2022-06-01', 'YYYY-MM-DD'), 'MLOps Engineer', 'Data / BI / Analytics', 'Active', 'dpopa', STANDARD_HASH('dpopaDATA', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (264, 'Elena', 'Marin', 'elena.marin.mlops@company.com', '+40758900225', TO_DATE('2023-01-12', 'YYYY-MM-DD'), 'Junior MLOps Engineer', 'Data / BI / Analytics', 'Active', 'emarin', STANDARD_HASH('emarinDATA', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (265, 'Gabriela', 'Anton', 'gabriela.anton.dg@company.com', '+40758900226', TO_DATE('2021-04-18', 'YYYY-MM-DD'), 'Data Governance Specialist', 'Data / BI / Analytics', 'Active', 'ganton', STANDARD_HASH('gantonDATA', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (266, 'Ilie', 'Dumitrescu', 'ilie.dumitrescu.dg@company.com', '+40758900227', TO_DATE('2019-12-03', 'YYYY-MM-DD'), 'Data Quality Analyst', 'Data / BI / Analytics', 'Active', 'idumitrescu', STANDARD_HASH('idumitrescuDATA', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (267, 'Monica', 'Petrescu', 'monica.petrescu.dg@company.com', '+40758900228', TO_DATE('2020-07-15', 'YYYY-MM-DD'), 'Data Governance Analyst', 'Data / BI / Analytics', 'Active', 'mpetrescu', STANDARD_HASH('mpetrescuDATA', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (268, 'Radu', 'Stroe', 'radu.stroe.dg@company.com', '+40758900229', TO_DATE('2022-03-10', 'YYYY-MM-DD'), 'Data Quality Specialist', 'Data / BI / Analytics', 'Active', 'rstroe', STANDARD_HASH('rstroeDATA', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (269, 'Sorina', 'Matei', 'sorina.matei.dg@company.com', '+40758900230', TO_DATE('2023-05-05', 'YYYY-MM-DD'), 'Junior Data Governance Analyst', 'Data / BI / Analytics', 'Active', 'smatei', STANDARD_HASH('smateiDATA', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (270, 'Marius', 'Grigore', 'marius.grigore.cyber@company.com', '+40758900231', TO_DATE('2021-09-22', 'YYYY-MM-DD'), 'Cybersecurity Analyst', 'Security / Cybersecurity', 'Active', 'mgrigore', STANDARD_HASH('mgrigoreCYBER', 'SHA256'), 'Manager');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (271, 'Ioana', 'Dobre', 'ioana.dobre.netsec@company.com', '+40758900232', TO_DATE('2020-05-10', 'YYYY-MM-DD'), 'Network Security Specialist', 'Security / Cybersecurity', 'Active', 'idobre', STANDARD_HASH('idobreCYBER', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (272, 'Vlad', 'Petcu', 'vlad.petcu.netsec@company.com', '+40758900233', TO_DATE('2021-03-18', 'YYYY-MM-DD'), 'Senior Network Security Engineer', 'Security / Cybersecurity', 'Active', 'vpetcu', STANDARD_HASH('vpetcuCYBER', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (273, 'Camelia', 'Neagu', 'camelia.neagu.netsec@company.com', '+40758900234', TO_DATE('2019-11-23', 'YYYY-MM-DD'), 'Network Security Engineer', 'Security / Cybersecurity', 'Active', 'cneagu', STANDARD_HASH('cneaguCYBER', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (274, 'George', 'Rusu', 'george.rusu.netsec@company.com', '+40758900235', TO_DATE('2022-08-01', 'YYYY-MM-DD'), 'Network Security Administrator', 'Security / Cybersecurity', 'Active', 'grusu', STANDARD_HASH('grusuCYBER', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (275, 'Diana', 'Voicu', 'diana.voicu.netsec@company.com', '+40758900236', TO_DATE('2023-04-12', 'YYYY-MM-DD'), 'Junior Network Security Analyst', 'Security / Cybersecurity', 'Active', 'dvoicu', STANDARD_HASH('dvoicuCYBER', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (276, 'Andrei', 'Iliescu', 'andrei.iliescu.appsec@company.com', '+40758900237', TO_DATE('2020-06-18', 'YYYY-MM-DD'), 'Application Security Engineer', 'Security / Cybersecurity', 'Active', 'ailiescu', STANDARD_HASH('ailiescuCYBER', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (277, 'Raluca', 'Georgescu', 'raluca.georgescu.appsec@company.com', '+40758900238', TO_DATE('2019-10-30', 'YYYY-MM-DD'), 'Senior AppSec Consultant', 'Security / Cybersecurity', 'Active', 'rgeorgescu', STANDARD_HASH('rgeorgescuCYBER', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (278, 'Tudor', 'Costache', 'tudor.costache.appsec@company.com', '+40758900239', TO_DATE('2021-01-14', 'YYYY-MM-DD'), 'Application Security Analyst', 'Security / Cybersecurity', 'Active', 'tcostache', STANDARD_HASH('tcostacheCYBER', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (279, 'Sorin', 'Marinescu', 'sorin.marinescu.appsec@company.com', '+40758900240', TO_DATE('2022-05-25', 'YYYY-MM-DD'), 'AppSec Engineer', 'Security / Cybersecurity', 'Active', 'smarinescu', STANDARD_HASH('smarinescuCYBER', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (280, 'Bianca', 'Lazar', 'bianca.lazar.appsec@company.com', '+40758900241', TO_DATE('2023-03-08', 'YYYY-MM-DD'), 'Junior AppSec Analyst', 'Security / Cybersecurity', 'Active', 'blazar', STANDARD_HASH('blazarCYBER', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (281, 'Elena', 'Tudor', 'elena.tudor.endpoint@company.com', '+40758900242', TO_DATE('2021-07-19', 'YYYY-MM-DD'), 'Endpoint Security Engineer', 'Security / Cybersecurity', 'Active', 'etudor', STANDARD_HASH('etudorCYBER', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (282, 'Alexandru', 'Dima', 'alex.dima.endpoint@company.com', '+40758900243', TO_DATE('2020-12-03', 'YYYY-MM-DD'), 'Endpoint Protection Specialist', 'Security / Cybersecurity', 'Active', 'adima', STANDARD_HASH('adimaCYBER', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (283, 'Silvia', 'Munteanu', 'silvia.munteanu.endpoint@company.com', '+40758900244', TO_DATE('2019-09-10', 'YYYY-MM-DD'), 'Endpoint Security Analyst', 'Security / Cybersecurity', 'Active', 'smunteanu', STANDARD_HASH('smunteanuCYBER', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (284, 'Cristian', 'Voinea', 'cristian.voinea.endpoint@company.com', '+40758900245', TO_DATE('2022-06-21', 'YYYY-MM-DD'), 'Endpoint Threat Analyst', 'Security / Cybersecurity', 'Active', 'cvoinea', STANDARD_HASH('cvoineaCYBER', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (285, 'Daniela', 'Stanciu', 'daniela.stanciu.endpoint@company.com', '+40758900246', TO_DATE('2023-01-29', 'YYYY-MM-DD'), 'Junior Endpoint Security Engineer', 'Security / Cybersecurity', 'Active', 'dstanciu', STANDARD_HASH('dstanciuCYBER', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (286, 'Ioana', 'Matei', 'ioana.matei.iam@company.com', '+40758900247', TO_DATE('2021-04-11', 'YYYY-MM-DD'), 'IAM Specialist', 'Security / Cybersecurity', 'Active', 'imatei', STANDARD_HASH('imateiCYBER', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (287, 'Florin', 'Serban', 'florin.serban.iam@company.com', '+40758900248', TO_DATE('2020-08-23', 'YYYY-MM-DD'), 'IAM Engineer', 'Security / Cybersecurity', 'Active', 'fserban', STANDARD_HASH('fserbanCYBER', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (288, 'Camelia', 'Popescu', 'camelia.popescu.iam@company.com', '+40758900249', TO_DATE('2022-02-02', 'YYYY-MM-DD'), 'Access Management Analyst', 'Security / Cybersecurity', 'Active', 'cpopescu', STANDARD_HASH('cpopescuCYBER', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (289, 'Marius', 'Voicu', 'marius.voicu.iam@company.com', '+40758900250', TO_DATE('2019-05-15', 'YYYY-MM-DD'), 'Identity Governance Consultant', 'Security / Cybersecurity', 'Active', 'mvoicu', STANDARD_HASH('mvoicuCYBER', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (290, 'Anca', 'Ionescu', 'anca.ionescu.iam@company.com', '+40758900251', TO_DATE('2023-09-28', 'YYYY-MM-DD'), 'IAM Administrator', 'Security / Cybersecurity', 'Active', 'aionescu', STANDARD_HASH('aionescuCYBER', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (291, 'Raluca', 'Grigore', 'raluca.grigore.threat@company.com', '+40758900252', TO_DATE('2020-11-10', 'YYYY-MM-DD'), 'Threat Intelligence Analyst', 'Security / Cybersecurity', 'Active', 'rgrigore', STANDARD_HASH('rgrigoreCYBER', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (292, 'Dorin', 'Mihailescu', 'dorin.mihailescu.threat@company.com', '+40758900253', TO_DATE('2021-06-04', 'YYYY-MM-DD'), 'Cyber Threat Analyst', 'Security / Cybersecurity', 'Active', 'dmihailescu', STANDARD_HASH('dmihailescuCYBER', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (293, 'Simona', 'Dragomir', 'simona.dragomir.threat@company.com', '+40758900254', TO_DATE('2019-03-18', 'YYYY-MM-DD'), 'Threat Intelligence Researcher', 'Security / Cybersecurity', 'Active', 'sdragomir', STANDARD_HASH('sdragomirCYBER', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (294, 'George', 'Filip', 'george.filip.threat@company.com', '+40758900255', TO_DATE('2022-10-12', 'YYYY-MM-DD'), 'Senior Threat Analyst', 'Security / Cybersecurity', 'Active', 'gfilip', STANDARD_HASH('gfilipCYBER', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (295, 'Oana', 'Iliescu', 'oana.iliescu.threat@company.com', '+40758900256', TO_DATE('2023-04-07', 'YYYY-MM-DD'), 'Threat Detection Analyst', 'Security / Cybersecurity', 'Active', 'oiliescu', STANDARD_HASH('oiliescuCYBER', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (296, 'Andrei', 'Popa', 'andrei.popa.sre@company.com', '+40760011223', TO_DATE('2021-08-16', 'YYYY-MM-DD'), 'Site Reliability Engineer', 'DevOps / Site Reliability Engineering (SRE)', 'Active', 'apopa.sre', STANDARD_HASH('apopaSRE', 'SHA256'), 'Manager');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (297, 'Larisa', 'Georgescu', 'larisa.georgescu.cicd@company.com', '+40760011224', TO_DATE('2022-05-12', 'YYYY-MM-DD'), 'CI/CD Engineer', 'DevOps / Site Reliability Engineering (SRE)', 'Active', 'lgeorgescu.cicd', STANDARD_HASH('lgeorgescuCICD', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (298, 'Mihai', 'Tudor', 'mihai.tudor.cicd@company.com', '+40760011225', TO_DATE('2021-11-30', 'YYYY-MM-DD'), 'CI/CD Pipeline Specialist', 'DevOps / Site Reliability Engineering (SRE)', 'Active', 'mtudor.cicd', STANDARD_HASH('mtudorCICD', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (299, 'Iulia', 'Radulescu', 'iulia.radulescu.cicd@company.com', '+40760011226', TO_DATE('2020-02-18', 'YYYY-MM-DD'), 'DevOps Engineer – CI/CD', 'DevOps / Site Reliability Engineering (SRE)', 'Active', 'iradulescu.cicd', STANDARD_HASH('iradulescuCICD', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (300, 'Radu', 'Stanciu', 'radu.stanciu.cicd@company.com', '+40760011227', TO_DATE('2023-07-09', 'YYYY-MM-DD'), 'CI/CD Automation Engineer', 'DevOps / Site Reliability Engineering (SRE)', 'Active', 'rstanciu.cicd', STANDARD_HASH('rstanciuCICD', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (301, 'Bianca', 'Iacob', 'bianca.iacob.cicd@company.com', '+40760011228', TO_DATE('2019-09-21', 'YYYY-MM-DD'), 'Senior CI/CD Engineer', 'DevOps / Site Reliability Engineering (SRE)', 'Active', 'biacob.cicd', STANDARD_HASH('biacobCICD', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (302, 'Andreea', 'Neagu', 'andreea.neagu.iac@company.com', '+40760011229', TO_DATE('2021-06-10', 'YYYY-MM-DD'), 'IaC Engineer', 'DevOps / Site Reliability Engineering (SRE)', 'Active', 'aneagu.iac', STANDARD_HASH('aneaguIAC', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (303, 'Cristian', 'Dobre', 'cristian.dobre.iac@company.com', '+40760011230', TO_DATE('2022-03-18', 'YYYY-MM-DD'), 'Terraform Specialist', 'DevOps / Site Reliability Engineering (SRE)', 'Active', 'cdobre.iac', STANDARD_HASH('cdobreIAC', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (304, 'Elena', 'Toma', 'elena.toma.iac@company.com', '+40760011231', TO_DATE('2020-12-01', 'YYYY-MM-DD'), 'Infrastructure Automation Engineer', 'DevOps / Site Reliability Engineering (SRE)', 'Active', 'etoma.iac', STANDARD_HASH('etomaIAC', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (305, 'Vlad', 'Iliescu', 'vlad.iliescu.iac@company.com', '+40760011232', TO_DATE('2019-08-23', 'YYYY-MM-DD'), 'Senior IaC Engineer', 'DevOps / Site Reliability Engineering (SRE)', 'Active', 'viliescu.iac', STANDARD_HASH('viliescuIAC', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (306, 'Diana', 'Petrescu', 'diana.petrescu.iac@company.com', '+40760011233', TO_DATE('2023-04-06', 'YYYY-MM-DD'), 'Cloud Infrastructure Engineer – IaC', 'DevOps / Site Reliability Engineering (SRE)', 'Active', 'dpetrescu.iac', STANDARD_HASH('dpetrescuIAC', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (307, 'Marius', 'Voicu', 'marius.voicu.monitoring@company.com', '+40760011234', TO_DATE('2020-09-15', 'YYYY-MM-DD'), 'Observability Engineer', 'DevOps / Site Reliability Engineering (SRE)', 'Active', 'mvoicu.monitor', STANDARD_HASH('mvoicuMONITOR', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (308, 'Raluca', 'Enache', 'raluca.enache.monitoring@company.com', '+40760011235', TO_DATE('2021-02-19', 'YYYY-MM-DD'), 'Monitoring Specialist', 'DevOps / Site Reliability Engineering (SRE)', 'Active', 'renache.monitor', STANDARD_HASH('renacheMONITOR', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (309, 'Alexandru', 'Zamfir', 'alex.zamfir.monitoring@company.com', '+40760011236', TO_DATE('2019-11-04', 'YYYY-MM-DD'), 'SRE – Monitoring & Logging', 'DevOps / Site Reliability Engineering (SRE)', 'Active', 'azamfir.monitor', STANDARD_HASH('azamfirMONITOR', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (310, 'Simona', 'Matei', 'simona.matei.monitoring@company.com', '+40760011237', TO_DATE('2022-06-27', 'YYYY-MM-DD'), 'Monitoring & Alerting Engineer', 'DevOps / Site Reliability Engineering (SRE)', 'Active', 'smatei.monitor', STANDARD_HASH('smateiMONITOR', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (311, 'Ovidiu', 'Cristea', 'ovidiu.cristea.monitoring@company.com', '+40760011238', TO_DATE('2023-01-12', 'YYYY-MM-DD'), 'Observability Platform Engineer', 'DevOps / Site Reliability Engineering (SRE)', 'Active', 'ocristea.monitor', STANDARD_HASH('ocristeaMONITOR', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (312, 'Florin', 'Munteanu', 'florin.munteanu.incident@company.com', '+40760011239', TO_DATE('2018-04-11', 'YYYY-MM-DD'), 'Incident Response Engineer', 'DevOps / Site Reliability Engineering (SRE)', 'Active', 'fmunteanu.inc', STANDARD_HASH('fmunteanuINC', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (313, 'Irina', 'Popescu', 'irina.popescu.reliability@company.com', '+40760011240', TO_DATE('2019-09-20', 'YYYY-MM-DD'), 'Reliability Engineer', 'DevOps / Site Reliability Engineering (SRE)', 'Active', 'ipopescu.rel', STANDARD_HASH('ipopescuREL', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (314, 'Mihai', 'Stan', 'mihai.stan.incident@company.com', '+40760011241', TO_DATE('2020-01-15', 'YYYY-MM-DD'), 'Incident Manager', 'DevOps / Site Reliability Engineering (SRE)', 'Active', 'mstan.inc', STANDARD_HASH('mstanINC', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (315, 'Georgiana', 'Dumitrescu', 'georgiana.dumitrescu.reliability@company.com', '+40760011242', TO_DATE('2021-07-30', 'YYYY-MM-DD'), 'Reliability Analyst', 'DevOps / Site Reliability Engineering (SRE)', 'Active', 'gdumitrescu.rel', STANDARD_HASH('gdumitrescuREL', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (316, 'Cosmin', 'Ionescu', 'cosmin.ionescu.incident@company.com', '+40760011243', TO_DATE('2022-11-05', 'YYYY-MM-DD'), 'Incident Analyst', 'DevOps / Site Reliability Engineering (SRE)', 'Active', 'cionescu.inc', STANDARD_HASH('cionescuINC', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (317, 'Adela', 'Grigorescu', 'adela.grigorescu.platform@company.com', '+40760011244', TO_DATE('2017-05-21', 'YYYY-MM-DD'), 'Platform Engineer', 'DevOps / Site Reliability Engineering (SRE)', 'Active', 'agrigorescu.ple', STANDARD_HASH('agrigorescuPLE', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (318, 'Sorin', 'Mateescu', 'sorin.mateescu.platform@company.com', '+40760011245', TO_DATE('2019-09-13', 'YYYY-MM-DD'), 'Senior Platform Engineer', 'DevOps / Site Reliability Engineering (SRE)', 'Active', 'smateescu.ple', STANDARD_HASH('smateescuPLE', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (319, 'Camelia', 'Vasiliu', 'camelia.vasiliu.platform@company.com', '+40760011246', TO_DATE('2020-02-25', 'YYYY-MM-DD'), 'Platform Specialist', 'DevOps / Site Reliability Engineering (SRE)', 'Active', 'cvasiliu.ple', STANDARD_HASH('cvasiliuPLE', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (320, 'Lucian', 'Petcu', 'lucian.petcu.platform@company.com', '+40760011247', TO_DATE('2021-11-09', 'YYYY-MM-DD'), 'Platform Engineer', 'DevOps / Site Reliability Engineering (SRE)', 'Active', 'lpetcu.ple', STANDARD_HASH('lpetcuPLE', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (321, 'Irina', 'Stancu', 'irina.stancu.platform@company.com', '+40760011248', TO_DATE('2022-08-17', 'YYYY-MM-DD'), 'Platform Developer', 'DevOps / Site Reliability Engineering (SRE)', 'Active', 'istancu.ple', STANDARD_HASH('istancuPLE', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (322, 'Daniel', 'Barbu', 'daniel.barbu.cloudauto@company.com', '+40760011249', TO_DATE('2018-06-20', 'YYYY-MM-DD'), 'Cloud Automation Engineer', 'DevOps / Site Reliability Engineering (SRE)', 'Active', 'dbarbu.cloudauto', STANDARD_HASH('dbarbuCLOUDAUTO', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (323, 'Ioana', 'Niculae', 'ioana.niculae.cloudauto@company.com', '+40760011250', TO_DATE('2019-10-12', 'YYYY-MM-DD'), 'Senior Cloud Automation Engineer', 'DevOps / Site Reliability Engineering (SRE)', 'Active', 'iniculae.cloudauto', STANDARD_HASH('iniculaeCLOUDAUTO', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (324, 'Radu', 'Stoica', 'radu.stoica.cloudauto@company.com', '+40760011251', TO_DATE('2020-03-03', 'YYYY-MM-DD'), 'Cloud Automation Specialist', 'DevOps / Site Reliability Engineering (SRE)', 'Active', 'rstoica.cloudauto', STANDARD_HASH('rstoicaCLOUDAUTO', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (325, 'Anca', 'Vlad', 'anca.vlad.cloudauto@company.com', '+40760011252', TO_DATE('2021-05-18', 'YYYY-MM-DD'), 'Cloud Automation Engineer', 'DevOps / Site Reliability Engineering (SRE)', 'Active', 'avlad.cloudauto', STANDARD_HASH('avladCLOUDAUTO', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (326, 'Sebastian', 'Iorga', 'sebastian.iorga.cloudauto@company.com', '+40760011253', TO_DATE('2022-12-07', 'YYYY-MM-DD'), 'Cloud Automation Developer', 'DevOps / Site Reliability Engineering (SRE)', 'Active', 'siorga.cloudauto', STANDARD_HASH('siorgaCLOUDAUTO', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (327, 'Elena', 'Popa', 'elena.popa@company.com', '+40760011456', TO_DATE('2023-01-10', 'YYYY-MM-DD'), 'Customer Success Manager', 'Customer Success / Client Support IT', 'Active', 'epopa', STANDARD_HASH('epopaCSIT', 'SHA256'), 'Manager');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (328, 'Mihai', 'Ionescu', 'mihai.ionescu.desktop@company.com', '+40760011457', TO_DATE('2021-04-15', 'YYYY-MM-DD'), 'Desktop Support Technician', 'Customer Success / Client Support IT', 'Active', 'mionescu.desktop', STANDARD_HASH('mionescuDESKTOP', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (329, 'Irina', 'Georgescu', 'irina.georgescu.desktop@company.com', '+40760011458', TO_DATE('2020-11-20', 'YYYY-MM-DD'), 'Desktop Support Specialist', 'Customer Success / Client Support IT', 'Active', 'igeorgescu.desktop', STANDARD_HASH('igeorgescuDESKTOP', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (330, 'Andrei', 'Marinescu', 'andrei.marinescu.desktop@company.com', '+40760011459', TO_DATE('2019-07-10', 'YYYY-MM-DD'), 'Desktop Support Technician', 'Customer Success / Client Support IT', 'Active', 'amarinescu.desktop', STANDARD_HASH('amarinescuDESKTOP', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (331, 'Gabriela', 'Dumitrescu', 'gabriela.dumitrescu.desktop@company.com', '+40760011460', TO_DATE('2018-05-22', 'YYYY-MM-DD'), 'Desktop Support Engineer', 'Customer Success / Client Support IT', 'Active', 'gdumitrescu.desktop', STANDARD_HASH('gdumitrescuDESKTOP', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (332, 'Raluca', 'Stanescu', 'raluca.stanescu.desktop@company.com', '+40760011461', TO_DATE('2022-02-28', 'YYYY-MM-DD'), 'Desktop Support Specialist', 'Customer Success / Client Support IT', 'Active', 'rstanescu.desktop', STANDARD_HASH('rstanescuDESKTOP', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (333, 'Cristian', 'Florescu', 'cristian.florescu.remote@company.com', '+40760011462', TO_DATE('2019-09-15', 'YYYY-MM-DD'), 'Remote Support Specialist', 'Customer Success / Client Support IT', 'Active', 'cflorescu.remote', STANDARD_HASH('cflorescuREMOTE', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (334, 'Ioana', 'Petrescu', 'ioana.petrescu.remote@company.com', '+40760011463', TO_DATE('2020-08-10', 'YYYY-MM-DD'), 'Remote Support Engineer', 'Customer Success / Client Support IT', 'Active', 'ipetrescu.remote', STANDARD_HASH('ipetrescuREMOTE', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (335, 'Alina', 'Constantinescu', 'alina.constantinescu.remote@company.com', '+40760011464', TO_DATE('2021-05-05', 'YYYY-MM-DD'), 'Remote Support Analyst', 'Customer Success / Client Support IT', 'Active', 'aconstantinescu.remote', STANDARD_HASH('aconstantinescuREMOTE', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (336, 'Marius', 'Iliescu', 'marius.iliescu.remote@company.com', '+40760011465', TO_DATE('2018-11-23', 'YYYY-MM-DD'), 'Remote Support Technician', 'Customer Success / Client Support IT', 'Active', 'miliescu.remote', STANDARD_HASH('miliescuREMOTE', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (337, 'Diana', 'Georgescu', 'diana.georgescu.remote@company.com', '+40760011466', TO_DATE('2022-03-18', 'YYYY-MM-DD'), 'Remote Support Engineer', 'Customer Success / Client Support IT', 'Active', 'dgeorgescu.remote', STANDARD_HASH('dgeorgescuREMOTE', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (338, 'Radu', 'Popescu', 'radu.popescu.knowledge@company.com', '+40760011467', TO_DATE('2020-06-12', 'YYYY-MM-DD'), 'Knowledge Manager', 'Customer Success / Client Support IT', 'Active', 'rpopescu.knowledge', STANDARD_HASH('rpopescuKNOWLEDGE', 'SHA256'), 'Manager');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (339, 'Monica', 'Dumitru', 'monica.dumitru.knowledge@company.com', '+40760011468', TO_DATE('2019-04-21', 'YYYY-MM-DD'), 'Knowledge Specialist', 'Customer Success / Client Support IT', 'Active', 'mdumitru.knowledge', STANDARD_HASH('mdumitruKNOWLEDGE', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (340, 'Sorin', 'Marinescu', 'sorin.marinescu.knowledge@company.com', '+40760011469', TO_DATE('2021-01-15', 'YYYY-MM-DD'), 'Knowledge Analyst', 'Customer Success / Client Support IT', 'Active', 'smarinescu.knowledge', STANDARD_HASH('smarinescuKNOWLEDGE', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (341, 'Elena', 'Stan', 'elena.stan.knowledge@company.com', '+40760011470', TO_DATE('2022-08-30', 'YYYY-MM-DD'), 'Knowledge Coordinator', 'Customer Success / Client Support IT', 'Active', 'estan.knowledge', STANDARD_HASH('estanKNOWLEDGE', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (342, 'Victor', 'Ionescu', 'victor.ionescu.knowledge@company.com', '+40760011471', TO_DATE('2018-12-05', 'YYYY-MM-DD'), 'Knowledge Specialist', 'Customer Success / Client Support IT', 'Active', 'vionescu.knowledge', STANDARD_HASH('vionescuKNOWLEDGE', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (343, 'Adriana', 'Munteanu', 'adriana.munteanu.vip@company.com', '+40760011472', TO_DATE('2020-02-10', 'YYYY-MM-DD'), 'VIP Support Specialist', 'Customer Success / Client Support IT', 'Active', 'amunteanu.vip', STANDARD_HASH('amunteanuVIP', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (344, 'Bogdan', 'Cristea', 'bogdan.cristea.vip@company.com', '+40760011473', TO_DATE('2019-06-20', 'YYYY-MM-DD'), 'Executive Support Engineer', 'Customer Success / Client Support IT', 'Active', 'bcristea.vip', STANDARD_HASH('bcristeaVIP', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (345, 'Corina', 'Nedelcu', 'corina.nedelcu.vip@company.com', '+40760011474', TO_DATE('2021-11-05', 'YYYY-MM-DD'), 'VIP Support Coordinator', 'Customer Success / Client Support IT', 'Active', 'cnedelcu.vip', STANDARD_HASH('cnedelcuVIP', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (346, 'Daniel', 'Popa', 'daniel.popa.vip@company.com', '+40760011475', TO_DATE('2018-09-18', 'YYYY-MM-DD'), 'Executive Support Specialist', 'Customer Success / Client Support IT', 'Active', 'dpopa.vip', STANDARD_HASH('dpopaVIP', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (347, 'Elisabeta', 'Iancu', 'elisabeta.iancu.vip@company.com', '+40760011476', TO_DATE('2022-01-27', 'YYYY-MM-DD'), 'VIP Support Engineer', 'Customer Success / Client Support IT', 'Active', 'eiancu.vip', STANDARD_HASH('eiancuVIP', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (348, 'Gabriel', 'Tudor', 'gabriel.tudor.servicedesk@company.com', '+40760011477', TO_DATE('2019-10-03', 'YYYY-MM-DD'), 'Service Desk Coordinator', 'Customer Success / Client Support IT', 'Active', 'gtudor.servicedesk', STANDARD_HASH('gtudorSERVICEDESK', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (349, 'Iulia', 'Marinescu', 'iulia.marinescu.servicedesk@company.com', '+40760011478', TO_DATE('2021-05-22', 'YYYY-MM-DD'), 'Service Desk Specialist', 'Customer Success / Client Support IT', 'Active', 'imarinescu.servicedesk', STANDARD_HASH('imarinescuSERVICEDESK', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (350, 'Cosmin', 'Voicu', 'cosmin.voicu.servicedesk@company.com', '+40760011479', TO_DATE('2018-07-11', 'YYYY-MM-DD'), 'Service Desk Analyst', 'Customer Success / Client Support IT', 'Active', 'cvoicu.servicedesk', STANDARD_HASH('cvoicuSERVICEDESK', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (351, 'Raluca', 'Barbu', 'raluca.barbu.servicedesk@company.com', '+40760011480', TO_DATE('2022-02-15', 'YYYY-MM-DD'), 'Service Desk Coordinator', 'Customer Success / Client Support IT', 'Active', 'rbarbu.servicedesk', STANDARD_HASH('rbarbuSERVICEDESK', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (352, 'Andrei', 'Florescu', 'andrei.florescu.servicedesk@company.com', '+40760011481', TO_DATE('2020-12-10', 'YYYY-MM-DD'), 'Service Desk Specialist', 'Customer Success / Client Support IT', 'Active', 'aflorescu.servicedesk', STANDARD_HASH('aflorescuSERVICEDESK', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (353, 'Ioana', 'Petrescu', 'ioana.petrescu.hr@company.com', '+40760011482', TO_DATE('2021-09-01', 'YYYY-MM-DD'), 'Tech Recruiter', 'HR / Tech Recruitment', 'Active', 'ipetrescu.hr', STANDARD_HASH('ipetrescuHR', 'SHA256'), 'Manager');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (354, 'Mihai', 'Ionescu', 'mihai.ionescu.techrecruit@company.com', '+40760011483', TO_DATE('2019-04-12', 'YYYY-MM-DD'), 'Tech Talent Acquisition Specialist', 'HR / Tech Recruitment', 'Active', 'mionescu.techrec', STANDARD_HASH('mionescuTECHREC', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (355, 'Raluca', 'Dumitrescu', 'raluca.dumitrescu.techrecruit@company.com', '+40760011484', TO_DATE('2020-07-23', 'YYYY-MM-DD'), 'Tech Talent Acquisition Specialist', 'HR / Tech Recruitment', 'Active', 'rdumitrescu.techrec', STANDARD_HASH('rdumitrescuTECHREC', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (356, 'Cristian', 'Popescu', 'cristian.popescu.techrecruit@company.com', '+40760011485', TO_DATE('2021-03-15', 'YYYY-MM-DD'), 'Tech Talent Acquisition Specialist', 'HR / Tech Recruitment', 'Active', 'cpopescu.techrec', STANDARD_HASH('cpopescuTECHREC', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (357, 'Elena', 'Stancu', 'elena.stancu.techrecruit@company.com', '+40760011486', TO_DATE('2018-11-10', 'YYYY-MM-DD'), 'Tech Talent Acquisition Specialist', 'HR / Tech Recruitment', 'Active', 'estancu.techrec', STANDARD_HASH('estancuTECHREC', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (358, 'Andreea', 'Marcu', 'andreea.marcu.techrecruit@company.com', '+40760011487', TO_DATE('2022-06-18', 'YYYY-MM-DD'), 'Tech Talent Acquisition Specialist', 'HR / Tech Recruitment', 'Active', 'amarcu.techrec', STANDARD_HASH('amarcuTECHREC', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (359, 'Irina', 'Toma', 'irina.toma.branding@company.com', '+40760011488', TO_DATE('2021-02-14', 'YYYY-MM-DD'), 'Employer Branding Specialist', 'HR / Tech Recruitment', 'Active', 'itoma.branding', STANDARD_HASH('itomaBRANDING', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (360, 'Paul', 'Neagu', 'paul.neagu.branding@company.com', '+40760011489', TO_DATE('2020-10-08', 'YYYY-MM-DD'), 'Employer Branding Coordinator', 'HR / Tech Recruitment', 'Active', 'pneagu.branding', STANDARD_HASH('pneaguBRANDING', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (361, 'Anca', 'Voicu', 'anca.voicu.branding@company.com', '+40760011490', TO_DATE('2019-06-21', 'YYYY-MM-DD'), 'Senior Employer Branding Specialist', 'HR / Tech Recruitment', 'Active', 'avoicu.branding', STANDARD_HASH('avoicuBRANDING', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (362, 'Vlad', 'Dragomir', 'vlad.dragomir.branding@company.com', '+40760011491', TO_DATE('2022-03-04', 'YYYY-MM-DD'), 'Employer Branding Associate', 'HR / Tech Recruitment', 'Active', 'vdragomir.branding', STANDARD_HASH('vdragomirBRANDING', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (363, 'Dana', 'Iliescu', 'dana.iliescu.branding@company.com', '+40760011492', TO_DATE('2023-01-17', 'YYYY-MM-DD'), 'Employer Branding Analyst', 'HR / Tech Recruitment', 'Active', 'diliescu.branding', STANDARD_HASH('diliescuBRANDING', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (364, 'Oana', 'Petrescu', 'oana.petrescu.hranalytics@company.com', '+40760011493', TO_DATE('2021-08-01', 'YYYY-MM-DD'), 'HR Data Analyst', 'HR / Tech Recruitment', 'Active', 'opetrescu.hranalytics', STANDARD_HASH('opetrescuHRANALYTICS', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (365, 'Andrei', 'Mitrea', 'andrei.mitrea.hranalytics@company.com', '+40760011494', TO_DATE('2020-05-18', 'YYYY-MM-DD'), 'Workforce Analytics Specialist', 'HR / Tech Recruitment', 'Active', 'amitrea.hranalytics', STANDARD_HASH('amitreaHARANALYTICS', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (366, 'Camelia', 'Voinea', 'camelia.voinea.hranalytics@company.com', '+40760011495', TO_DATE('2019-12-11', 'YYYY-MM-DD'), 'People Analytics Consultant', 'HR / Tech Recruitment', 'Active', 'cvoinea.hranalytics', STANDARD_HASH('cvoineaHRANALYTICS', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (367, 'Radu', 'Constantin', 'radu.constantin.hranalytics@company.com', '+40760011496', TO_DATE('2022-09-30', 'YYYY-MM-DD'), 'HR Reporting Specialist', 'HR / Tech Recruitment', 'Active', 'rconstantin.hranalytics', STANDARD_HASH('rconstantinHRANALYTICS', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (368, 'Simona', 'Albu', 'simona.albu.hranalytics@company.com', '+40760011497', TO_DATE('2023-04-06', 'YYYY-MM-DD'), 'Talent Metrics Analyst', 'HR / Tech Recruitment', 'Active', 'salbu.hranalytics', STANDARD_HASH('salbuHRANALYTICS', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (369, 'Mihai', 'Tudor', 'mihai.tudor.onboarding@company.com', '+40760011498', TO_DATE('2021-11-10', 'YYYY-MM-DD'), 'Onboarding Specialist', 'HR / Tech Recruitment', 'Active', 'mtudor.onboarding', STANDARD_HASH('mtudorONBOARDING', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (370, 'Delia', 'Georgescu', 'delia.georgescu.onboarding@company.com', '+40760011499', TO_DATE('2022-01-24', 'YYYY-MM-DD'), 'Employee Orientation Coordinator', 'HR / Tech Recruitment', 'Active', 'dgeorgescu.onboarding', STANDARD_HASH('dgeorgescuONBOARDING', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (371, 'Florin', 'Nedelea', 'florin.nedelea.onboarding@company.com', '+40760011500', TO_DATE('2020-06-05', 'YYYY-MM-DD'), 'Onboarding Program Manager', 'HR / Tech Recruitment', 'Active', 'fnedelea.onboarding', STANDARD_HASH('fnedeleaONBOARDING', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (372, 'Roxana', 'Lupu', 'roxana.lupu.onboarding@company.com', '+40760011501', TO_DATE('2019-03-19', 'YYYY-MM-DD'), 'Orientation & Culture Trainer', 'HR / Tech Recruitment', 'Active', 'rlupu.onboarding', STANDARD_HASH('rlupuONBOARDING', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (373, 'Bogdan', 'Enache', 'bogdan.enache.onboarding@company.com', '+40760011502', TO_DATE('2023-08-30', 'YYYY-MM-DD'), 'Onboarding & Engagement Analyst', 'HR / Tech Recruitment', 'Active', 'benache.onboarding', STANDARD_HASH('benacheONBOARDING', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (374, 'Corina', 'Voicu', 'corina.voicu.ld@company.com', '+40760011503', TO_DATE('2021-05-17', 'YYYY-MM-DD'), 'L&D Specialist', 'HR / Tech Recruitment', 'Active', 'cvoicu.ld', STANDARD_HASH('cvoicuLD', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (375, 'Vlad', 'Badea', 'vlad.badea.ld@company.com', '+40760011504', TO_DATE('2020-09-02', 'YYYY-MM-DD'), 'Training & Development Coordinator', 'HR / Tech Recruitment', 'Active', 'vbadea.ld', STANDARD_HASH('vbadeaLD', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (376, 'Irina', 'Sava', 'irina.sava.ld@company.com', '+40760011505', TO_DATE('2019-01-10', 'YYYY-MM-DD'), 'Learning Consultant', 'HR / Tech Recruitment', 'Active', 'isava.ld', STANDARD_HASH('isavaLD', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (377, 'George', 'Costache', 'george.costache.ld@company.com', '+40760011506', TO_DATE('2022-12-20', 'YYYY-MM-DD'), 'L&D Program Manager', 'HR / Tech Recruitment', 'Active', 'gcostache.ld', STANDARD_HASH('gcostacheLD', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (378, 'Raluca', 'Ionescu', 'raluca.ionescu.ld@company.com', '+40760011507', TO_DATE('2023-04-14', 'YYYY-MM-DD'), 'Corporate Trainer', 'HR / Tech Recruitment', 'Active', 'rionescu.ld', STANDARD_HASH('rionescuLD', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (379, 'Andreea', 'Popescu', 'andreea.popescu.pm@company.com', '+40760011508', TO_DATE('2021-03-22', 'YYYY-MM-DD'), 'Performance Manager', 'HR / Tech Recruitment', 'Active', 'apopescu.pm', STANDARD_HASH('apopescuPM', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (380, 'Marius', 'Toma', 'marius.toma.pm@company.com', '+40760011509', TO_DATE('2020-07-30', 'YYYY-MM-DD'), 'Performance Analyst', 'HR / Tech Recruitment', 'Active', 'mtoma.pm', STANDARD_HASH('mtomaPM', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (381, 'Silvia', 'Enescu', 'silvia.enescu.pm@company.com', '+40760011510', TO_DATE('2019-12-10', 'YYYY-MM-DD'), 'HR Performance Coordinator', 'HR / Tech Recruitment', 'Active', 'senescu.pm', STANDARD_HASH('senescuPM', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (382, 'Radu', 'Iftimie', 'radu.iftimie.pm@company.com', '+40760011511', TO_DATE('2022-06-18', 'YYYY-MM-DD'), 'Performance Evaluation Specialist', 'HR / Tech Recruitment', 'Active', 'riftimie.pm', STANDARD_HASH('riftimiePM', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (383, 'Carmen', 'Marinescu', 'carmen.marinescu.pm@company.com', '+40760011512', TO_DATE('2023-01-08', 'YYYY-MM-DD'), 'Performance & Appraisal Lead', 'HR / Tech Recruitment', 'Active', 'cmarinescu.pm', STANDARD_HASH('cmarinescuPM', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (384, 'Oana', 'Dragomir', 'oana.dragomir.sales@company.com', '+40760011513', TO_DATE('2022-09-15', 'YYYY-MM-DD'), 'IT Presales Consultant', 'Sales & Presales IT', 'Active', 'odragomir.sales', STANDARD_HASH('odragomirSALES', 'SHA256'), 'Manager');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (385, 'Vlad', 'Matei', 'vlad.matei.presales@company.com', '+40760011520', TO_DATE('2021-04-10', 'YYYY-MM-DD'), 'Presales Engineer', 'Sales & Presales IT', 'Active', 'vmatei.presales', STANDARD_HASH('vmateiPRESALES', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (386, 'Iulia', 'Constantin', 'iulia.constantin.presales@company.com', '+40760011521', TO_DATE('2020-11-03', 'YYYY-MM-DD'), 'Solutions Presales Engineer', 'Sales & Presales IT', 'Active', 'iconstantin.presales', STANDARD_HASH('iconstantinPRESALES', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (387, 'George', 'Simion', 'george.simion.presales@company.com', '+40760011522', TO_DATE('2019-08-21', 'YYYY-MM-DD'), 'Technical Presales Consultant', 'Sales & Presales IT', 'Active', 'gsimion.presales', STANDARD_HASH('gsimionPRESALES', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (388, 'Anca', 'Neagu', 'anca.neagu.presales@company.com', '+40760011523', TO_DATE('2022-01-14', 'YYYY-MM-DD'), 'Presales Solution Architect', 'Sales & Presales IT', 'Active', 'aneagu.presales', STANDARD_HASH('aneaguPRESALES', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (389, 'Răzvan', 'Cojocaru', 'razvan.cojocaru.presales@company.com', '+40760011524', TO_DATE('2023-05-02', 'YYYY-MM-DD'), 'Presales IT Consultant', 'Sales & Presales IT', 'Active', 'rcojocaru.presales', STANDARD_HASH('rcojocaruPRESALES', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (390, 'Teodora', 'Ionescu', 'teodora.ionescu.tam@company.com', '+40760011601', TO_DATE('2021-03-11', 'YYYY-MM-DD'), 'Technical Account Manager', 'Sales & Presales IT', 'Active', 'tionescu.tam', STANDARD_HASH('tionescuTAM', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (391, 'Mihnea', 'Georgescu', 'mihnea.georgescu.tam@company.com', '+40760011602', TO_DATE('2020-12-01', 'YYYY-MM-DD'), 'Senior Technical Account Manager', 'Sales & Presales IT', 'Active', 'mgeorgescu.tam', STANDARD_HASH('mgeorgescuTAM', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (392, 'Elena', 'Radu', 'elena.radu.tam@company.com', '+40760011603', TO_DATE('2019-10-10', 'YYYY-MM-DD'), 'Technical Customer Success Manager', 'Sales & Presales IT', 'Active', 'eradu.tam', STANDARD_HASH('eraduTAM', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (393, 'Cosmin', 'Pop', 'cosmin.pop.tam@company.com', '+40760011604', TO_DATE('2022-04-27', 'YYYY-MM-DD'), 'TAM - Infrastructure & Cloud', 'Sales & Presales IT', 'Active', 'cpop.tam', STANDARD_HASH('cpopTAM', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (394, 'Irina', 'Marcu', 'irina.marcu.tam@company.com', '+40760011605', TO_DATE('2023-06-08', 'YYYY-MM-DD'), 'Technical Partner Manager', 'Sales & Presales IT', 'Active', 'imarcu.tam', STANDARD_HASH('imarcuTAM', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (395, 'Alin', 'Tudor', 'alin.tudor.bid@company.com', '+40760011610', TO_DATE('2021-07-15', 'YYYY-MM-DD'), 'Bid Manager', 'Sales & Presales IT', 'Active', 'atudor.bid', STANDARD_HASH('atudorBID', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (396, 'Camelia', 'Stan', 'camelia.stan.proposal@company.com', '+40760011611', TO_DATE('2020-10-09', 'YYYY-MM-DD'), 'Proposal Manager', 'Sales & Presales IT', 'Active', 'cstan.proposal', STANDARD_HASH('cstanPROPOSAL', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (397, 'Paul', 'Negrescu', 'paul.negrescu.bid@company.com', '+40760011612', TO_DATE('2022-02-28', 'YYYY-MM-DD'), 'Technical Proposal Coordinator', 'Sales & Presales IT', 'Active', 'pnegrescu.bid', STANDARD_HASH('pnegrescuBID', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (398, 'Andreea', 'Costache', 'andreea.costache.proposal@company.com', '+40760011613', TO_DATE('2019-12-05', 'YYYY-MM-DD'), 'Presales Proposal Specialist', 'Sales & Presales IT', 'Active', 'acostache.proposal', STANDARD_HASH('acostachePROPOSAL', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (399, 'Dragoș', 'Vlad', 'dragos.vlad.bid@company.com', '+40760011614', TO_DATE('2023-03-22', 'YYYY-MM-DD'), 'Bid & Tender Manager', 'Sales & Presales IT', 'Active', 'dvlad.bid', STANDARD_HASH('dvladBID', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (400, 'Ioana', 'Neagu', 'ioana.neagu.enablement@company.com', '+40760011620', TO_DATE('2021-09-01', 'YYYY-MM-DD'), 'Sales Enablement Specialist', 'Sales & Presales IT', 'Active', 'ineagu.enable', STANDARD_HASH('ineaguENABLE', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (401, 'Radu', 'Simeon', 'radu.simeon.training@company.com', '+40760011621', TO_DATE('2020-06-15', 'YYYY-MM-DD'), 'Sales Trainer', 'Sales & Presales IT', 'Active', 'rsimeon.train', STANDARD_HASH('rsimeonTRAIN', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (402, 'Anca', 'Barbu', 'anca.barbu.enablement@company.com', '+40760011622', TO_DATE('2019-11-03', 'YYYY-MM-DD'), 'Sales Enablement Manager', 'Sales & Presales IT', 'Active', 'abarbu.enable', STANDARD_HASH('abarbuENABLE', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (403, 'Florin', 'Iancu', 'florin.iancu.training@company.com', '+40760011623', TO_DATE('2022-01-27', 'YYYY-MM-DD'), 'Sales Skills Coach', 'Sales & Presales IT', 'Active', 'fiancu.train', STANDARD_HASH('fiancuTRAIN', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (404, 'Sorina', 'Marinescu', 'sorina.marinescu.enablement@company.com', '+40760011624', TO_DATE('2023-05-10', 'YYYY-MM-DD'), 'Sales Enablement Analyst', 'Sales & Presales IT', 'Active', 'smarinescu.enable', STANDARD_HASH('smarinescuENABLE', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (405, 'Andrei', 'Rusu', 'andrei.rusu.kam@company.com', '+40760011630', TO_DATE('2020-03-18', 'YYYY-MM-DD'), 'Key Account Manager', 'Sales & Presales IT', 'Active', 'arusu.kam', STANDARD_HASH('arusuKAM', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (406, 'Bianca', 'Dumitrescu', 'bianca.dumitrescu.kam@company.com', '+40760011631', TO_DATE('2019-05-12', 'YYYY-MM-DD'), 'Senior Key Account Manager', 'Sales & Presales IT', 'Active', 'bdumitrescu.kam', STANDARD_HASH('bdumitrescuKAM', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (407, 'Mihai', 'Enache', 'mihai.enache.kam@company.com', '+40760011632', TO_DATE('2021-01-05', 'YYYY-MM-DD'), 'KAM - Strategic Clients', 'Sales & Presales IT', 'Active', 'menache.kam', STANDARD_HASH('menacheKAM', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (408, 'Roxana', 'Matei', 'roxana.matei.kam@company.com', '+40760011633', TO_DATE('2022-07-14', 'YYYY-MM-DD'), 'Junior Key Account Manager', 'Sales & Presales IT', 'Active', 'rmatei.kam', STANDARD_HASH('rmateiKAM', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (409, 'Cristian', 'Petrescu', 'cristian.petrescu.kam@company.com', '+40760011634', TO_DATE('2023-04-03', 'YYYY-MM-DD'), 'Global Account Manager', 'Sales & Presales IT', 'Active', 'cpetrescu.kam', STANDARD_HASH('cpetrescuKAM', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (410, 'Delia', 'Georgescu', 'delia.georgescu.inside@company.com', '+40760011635', TO_DATE('2021-02-10', 'YYYY-MM-DD'), 'Inside Sales Representative', 'Sales & Presales IT', 'Active', 'dgeorgescu.inside', STANDARD_HASH('dgeorgescuINSIDE', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (411, 'Lucian', 'Marinescu', 'lucian.marinescu.inside@company.com', '+40760011636', TO_DATE('2020-09-21', 'YYYY-MM-DD'), 'Inside Sales Specialist', 'Sales & Presales IT', 'Active', 'lmarinescu.inside', STANDARD_HASH('lmarinescuINSIDE', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (412, 'Iulia', 'Voicu', 'iulia.voicu.inside@company.com', '+40760011637', TO_DATE('2022-05-17', 'YYYY-MM-DD'), 'Inside Sales Executive', 'Sales & Presales IT', 'Active', 'ivoicu.inside', STANDARD_HASH('ivoicuINSIDE', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (413, 'Paul', 'Antonescu', 'paul.antonescu.inside@company.com', '+40760011638', TO_DATE('2019-11-03', 'YYYY-MM-DD'), 'Senior Inside Sales Rep', 'Sales & Presales IT', 'Active', 'pantonescu.inside', STANDARD_HASH('pantonescuINSIDE', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (414, 'Anca', 'Dobre', 'anca.dobre.inside@company.com', '+40760011639', TO_DATE('2023-08-01', 'YYYY-MM-DD'), 'Junior Inside Sales Representative', 'Sales & Presales IT', 'Active', 'adobre.inside', STANDARD_HASH('adobreINSIDE', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (415, 'Irina', 'Badea', 'irina.badea.marketing@company.com', '+40760011700', TO_DATE('2021-09-14', 'YYYY-MM-DD'), 'Digital Marketing Specialist', 'Marketing Tech / Digital Marketing', 'Active', 'ibadea.marketing', STANDARD_HASH('ibadeaMARKETING', 'SHA256'), 'Manager');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (416, 'Vlad', 'Petrescu', 'vlad.petrescu.ad@company.com', '+40760011701', TO_DATE('2022-03-01', 'YYYY-MM-DD'), 'PPC Specialist', 'Marketing Tech / Digital Marketing', 'Active', 'vpetrescu.ad', STANDARD_HASH('vpetrescuAD', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (417, 'Anca', 'Voinea', 'anca.voinea.display@company.com', '+40760011702', TO_DATE('2021-11-10', 'YYYY-MM-DD'), 'Display Advertising Specialist', 'Marketing Tech / Digital Marketing', 'Active', 'avoinea.display', STANDARD_HASH('avoineaDISPLAY', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (418, 'Mihai', 'Dumitru', 'mihai.dumitru.ads@company.com', '+40760011703', TO_DATE('2020-06-18', 'YYYY-MM-DD'), 'Digital Advertising Analyst', 'Marketing Tech / Digital Marketing', 'Active', 'mdumitru.ads', STANDARD_HASH('mdumitruADS', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (419, 'Raluca', 'Enache', 'raluca.enache.ppc@company.com', '+40760011704', TO_DATE('2023-01-24', 'YYYY-MM-DD'), 'Paid Media Specialist', 'Marketing Tech / Digital Marketing', 'Active', 'renache.ppc', STANDARD_HASH('renachePPC', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (420, 'George', 'Matei', 'george.matei.marketing@company.com', '+40760011705', TO_DATE('2019-10-09', 'YYYY-MM-DD'), 'Programmatic Ads Specialist', 'Marketing Tech / Digital Marketing', 'Active', 'gmatei.ads', STANDARD_HASH('gmateiADS', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (421, 'Ioana', 'Mihalache', 'ioana.mihalache.content@company.com', '+40760011706', TO_DATE('2022-04-12', 'YYYY-MM-DD'), 'Content Marketing Specialist', 'Marketing Tech / Digital Marketing', 'Active', 'imihalache.content', STANDARD_HASH('imihalacheCONTENT', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (422, 'Andrei', 'Neagu', 'andrei.neagu.writer@company.com', '+40760011707', TO_DATE('2021-07-19', 'YYYY-MM-DD'), 'Content Writer', 'Marketing Tech / Digital Marketing', 'Active', 'aneagu.writer', STANDARD_HASH('aneaguCONTENT', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (423, 'Larisa', 'Ionescu', 'larisa.ionescu.content@company.com', '+40760011708', TO_DATE('2020-11-03', 'YYYY-MM-DD'), 'Content Strategist', 'Marketing Tech / Digital Marketing', 'Active', 'lionescu.content', STANDARD_HASH('lionescuCONTENT', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (424, 'Robert', 'Tudor', 'robert.tudor.editor@company.com', '+40760011709', TO_DATE('2019-08-25', 'YYYY-MM-DD'), 'Content Editor', 'Marketing Tech / Digital Marketing', 'Active', 'rtudor.editor', STANDARD_HASH('rtudorCONTENT', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (425, 'Diana', 'Georgescu', 'diana.georgescu.marketing@company.com', '+40760011710', TO_DATE('2023-05-16', 'YYYY-MM-DD'), 'Content Marketing Manager', 'Marketing Tech / Digital Marketing', 'Active', 'dgeorgescu.content', STANDARD_HASH('dgeorgescuCONTENT', 'SHA256'), 'Manager');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (426, 'Alin', 'Popescu', 'alin.popescu.social@company.com', '+40760011711', TO_DATE('2022-01-05', 'YYYY-MM-DD'), 'Social Media Specialist', 'Marketing Tech / Digital Marketing', 'Active', 'apopescu.social', STANDARD_HASH('apopescuSOCIAL', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (427, 'Cristina', 'Radu', 'cristina.radu.smm@company.com', '+40760011712', TO_DATE('2020-09-21', 'YYYY-MM-DD'), 'Social Media Manager', 'Marketing Tech / Digital Marketing', 'Active', 'cradu.smm', STANDARD_HASH('craduSOCIAL', 'SHA256'), 'Manager');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (428, 'Bogdan', 'Iacob', 'bogdan.iacob.social@company.com', '+40760011713', TO_DATE('2021-05-10', 'YYYY-MM-DD'), 'Social Media Analyst', 'Marketing Tech / Digital Marketing', 'Active', 'biacob.social', STANDARD_HASH('biacobSOCIAL', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (429, 'Elena', 'Dobre', 'elena.dobre.social@company.com', '+40760011714', TO_DATE('2019-12-01', 'YYYY-MM-DD'), 'Social Media Coordinator', 'Marketing Tech / Digital Marketing', 'Active', 'edobre.social', STANDARD_HASH('edobreSOCIAL', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (430, 'Radu', 'Florea', 'radu.florea.smm@company.com', '+40760011715', TO_DATE('2023-04-20', 'YYYY-MM-DD'), 'Social Media Content Creator', 'Marketing Tech / Digital Marketing', 'Active', 'rflorea.smm', STANDARD_HASH('rfloreaSOCIAL', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (431, 'Gabriela', 'Stan', 'gabriela.stan.email@company.com', '+40760011716', TO_DATE('2021-06-10', 'YYYY-MM-DD'), 'Email Marketing Specialist', 'Marketing Tech / Digital Marketing', 'Active', 'gstan.email', STANDARD_HASH('gstanEMAIL', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (432, 'Mihai', 'Vasilescu', 'mihai.vasilescu.email@company.com', '+40760011717', TO_DATE('2020-03-15', 'YYYY-MM-DD'), 'Email Campaign Manager', 'Marketing Tech / Digital Marketing', 'Active', 'mvasilescu.email', STANDARD_HASH('mvasilescuEMAIL', 'SHA256'), 'Manager');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (433, 'Andreea', 'Popa', 'andreea.popa.email@company.com', '+40760011718', TO_DATE('2019-08-22', 'YYYY-MM-DD'), 'Email Marketing Analyst', 'Marketing Tech / Digital Marketing', 'Active', 'apopa.email', STANDARD_HASH('apopaEMAIL', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (434, 'Vlad', 'Petrescu', 'vlad.petrescu.email@company.com', '+40760011719', TO_DATE('2022-11-30', 'YYYY-MM-DD'), 'Email Marketing Coordinator', 'Marketing Tech / Digital Marketing', 'Active', 'vpetrescu.email', STANDARD_HASH('vpetrescuEMAIL', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (435, 'Camelia', 'Ionescu', 'camelia.ionescu.email@company.com', '+40760011720', TO_DATE('2023-02-14', 'YYYY-MM-DD'), 'Email Marketing Manager', 'Marketing Tech / Digital Marketing', 'Active', 'cionescu.email', STANDARD_HASH('cionescuEMAIL', 'SHA256'), 'Manager');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (436, 'Daniel', 'Munteanu', 'daniel.munteanu.affiliate@company.com', '+40760011721', TO_DATE('2021-04-12', 'YYYY-MM-DD'), 'Affiliate Marketing Specialist', 'Marketing Tech / Digital Marketing', 'Active', 'dmunteanu.aff', STANDARD_HASH('dmunteanuAFF', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (437, 'Ioana', 'Petcu', 'ioana.petcu.affiliate@company.com', '+40760011722', TO_DATE('2020-08-05', 'YYYY-MM-DD'), 'Affiliate Marketing Manager', 'Marketing Tech / Digital Marketing', 'Active', 'ipetcu.aff', STANDARD_HASH('ipetcuAFF', 'SHA256'), 'Manager');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (438, 'Radu', 'Georgescu', 'radu.georgescu.affiliate@company.com', '+40760011723', TO_DATE('2019-11-18', 'YYYY-MM-DD'), 'Affiliate Marketing Analyst', 'Marketing Tech / Digital Marketing', 'Active', 'rgeorgescu.aff', STANDARD_HASH('rgeorgescuAFF', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (439, 'Alina', 'Stoica', 'alina.stoica.affiliate@company.com', '+40760011724', TO_DATE('2022-02-28', 'YYYY-MM-DD'), 'Affiliate Marketing Coordinator', 'Marketing Tech / Digital Marketing', 'Active', 'astoica.aff', STANDARD_HASH('astoicaAFF', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (440, 'Marius', 'Dumitrescu', 'marius.dumitrescu.affiliate@company.com', '+40760011725', TO_DATE('2023-01-09', 'YYYY-MM-DD'), 'Affiliate Marketing Specialist', 'Marketing Tech / Digital Marketing', 'Active', 'mdumitrescu.aff', STANDARD_HASH('mdumitrescuAFF', 'SHA256'), 'User');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (441, 'Simona', 'Iliescu', 'simona.iliescu.automation@company.com', '+40760011726', TO_DATE('2021-07-19', 'YYYY-MM-DD'), 'Marketing Automation Specialist', 'Marketing Tech / Digital Marketing', 'Active', 'siliescu.automation', STANDARD_HASH('siliescuAUTOMATION', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (442, 'Roxana', 'Marinescu', 'roxana.marinescu.automation@company.com', '+40760011727', TO_DATE('2020-10-25', 'YYYY-MM-DD'), 'Marketing Automation Engineer', 'Marketing Tech / Digital Marketing', 'Active', 'rmarinescu.automation', STANDARD_HASH('rmarinescuAUTOMATION', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (443, 'Alexandru', 'Voicu', 'alexandru.voicu.automation@company.com', '+40760011728', TO_DATE('2019-09-11', 'YYYY-MM-DD'), 'Marketing Automation Analyst', 'Marketing Tech / Digital Marketing', 'Active', 'avoicu.automation', STANDARD_HASH('avoicuAUTOMATION', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (444, 'Elena', 'Popescu', 'elena.popescu.automation@company.com', '+40760011729', TO_DATE('2022-03-08', 'YYYY-MM-DD'), 'Marketing Automation Coordinator', 'Marketing Tech / Digital Marketing', 'Active', 'epopescu.automation', STANDARD_HASH('epopescuAUTOMATION', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (445, 'Mihnea', 'Radu', 'mihnea.radu.automation@company.com', '+40760011730', TO_DATE('2023-04-22', 'YYYY-MM-DD'), 'Marketing Automation Manager', 'Marketing Tech / Digital Marketing', 'Active', 'mradu.automation', STANDARD_HASH('mraduAUTOMATION', 'SHA256'), 'Manager');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (456, 'Raluca', 'Dumitrescu', 'raluca.dumitrescu.devops1@company.com', '+40760010004', TO_DATE('2023-06-20', 'YYYY-MM-DD'), 'DevOps Team Leader', 'Software Development - DevOps', 'Active', 'rdumitrescu.devops1', STANDARD_HASH('rdumitrescuDEVOPS', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (457, 'Andrei', 'Popescu', 'andrei.popescu.devops2@company.com', '+40760010001', TO_DATE('2023-01-15', 'YYYY-MM-DD'), 'DevOps Engineer', 'Software Development - DevOps', 'Active', 'apopescu.devops2', STANDARD_HASH('apopescuDEVOPS', 'SHA256'), 'Engineer');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (458, 'Ioana', 'Marin', 'ioana.marin.devops3@company.com', '+40760010002', TO_DATE('2022-10-10', 'YYYY-MM-DD'), 'Senior DevOps Engineer', 'Software Development - DevOps', 'Active', 'imarin.devops3', STANDARD_HASH('imarinDEVOPS', 'SHA256'), 'Senior Engineer');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (459, 'Mihai', 'Ionescu', 'mihai.ionescu.devops4@company.com', '+40760010003', TO_DATE('2024-03-05', 'YYYY-MM-DD'), 'DevOps Engineer', 'Software Development - DevOps', 'Active', 'mionescu.devops4', STANDARD_HASH('mionescuDEVOPS', 'SHA256'), 'Engineer');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (460, 'Cristian', 'Vasilescu', 'cristian.vasilescu.devops5@company.com', '+40760010005', TO_DATE('2022-08-01', 'YYYY-MM-DD'), 'Junior DevOps Engineer', 'Software Development - DevOps', 'Active', 'cvasilescu.devops5', STANDARD_HASH('cvasilescuDEVOPS', 'SHA256'), 'Junior Engineer');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (461, 'Maria', 'Petrescu', 'maria.petrescu.arch1@company.com', '+40760020004', TO_DATE('2023-07-20', 'YYYY-MM-DD'), 'Architecture Team Leader', 'Software Development - Architecture', 'Active', 'mpetrescu.arch1', STANDARD_HASH('mpetrescuARCH', 'SHA256'), 'Team Leader');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (462, 'Adrian', 'Georgescu', 'adrian.georgescu.arch2@company.com', '+40760020001', TO_DATE('2022-11-10', 'YYYY-MM-DD'), 'Software Architect', 'Software Development - Architecture', 'Active', 'ageorgescu.arch2', STANDARD_HASH('ageorgescuARCH', 'SHA256'), 'Architect');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (463, 'Elena', 'Nedelcu', 'elena.nedelcu.arch3@company.com', '+40760020002', TO_DATE('2023-02-15', 'YYYY-MM-DD'), 'Senior Software Architect', 'Software Development - Architecture', 'Active', 'enedelcu.arch3', STANDARD_HASH('enedelcuARCH', 'SHA256'), 'Senior Architect');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (464, 'Cosmin', 'Ionescu', 'cosmin.ionescu.arch4@company.com', '+40760020003', TO_DATE('2024-01-05', 'YYYY-MM-DD'), 'Architect Consultant', 'Software Development - Architecture', 'Active', 'cionescu.arch4', STANDARD_HASH('cionescuARCH', 'SHA256'), 'Consultant');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role)
VALUES (465, 'Vlad', 'Popa', 'vlad.popa.arch5@company.com', '+40760020005', TO_DATE('2022-09-01', 'YYYY-MM-DD'), 'Junior Software Architect', 'Software Development - Architecture', 'Active', 'vpopa.arch5', STANDARD_HASH('vpopaARCH', 'SHA256'), 'Junior Architect');

INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role) 
VALUES (801, 'Andrei', 'Popescu', 'andrei.popescu@example.com', '0722000001', TO_DATE('2025-06-01','YYYY-MM-DD'), 'Recruiter', 'HR Recruiting', 'Active', 'andrei.popescu', STANDARD_HASH('andrei_popescu', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role) 
VALUES (802, 'Ioana', 'Ionescu', 'ioana.ionescu@example.com', '0722000002', TO_DATE('2025-06-02','YYYY-MM-DD'), 'Recruiter', 'HR Recruiting', 'Active', 'ioana.ionescu', STANDARD_HASH('ioana_ionescu', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role) 
VALUES (803, 'Mihai', 'Georgescu', 'mihai.georgescu@example.com', '0722000003', TO_DATE('2025-06-03','YYYY-MM-DD'), 'Recruiter', 'HR Recruiting', 'Active', 'mihai.georgescu', STANDARD_HASH('mihai_georgescu', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role) 
VALUES (804, 'Elena', 'Dumitrescu', 'elena.dumitrescu@example.com', '0722000004', TO_DATE('2025-06-04','YYYY-MM-DD'), 'Recruiter', 'HR Recruiting', 'Active', 'elena.dumitrescu', STANDARD_HASH('elena_dumitrescu', 'SHA256'), 'User');
INSERT INTO Employees (Employee_ID, First_Name, Last_Name, Email, Phone_Number, Hire_Date, Job_Title, Department, Status, Username, Password_Hash, Role) 
VALUES (805, 'Cristian', 'Marin', 'cristian.marin@example.com', '0722000005', TO_DATE('2025-06-05','YYYY-MM-DD'), 'Recruiter', 'HR Recruiting', 'Active', 'cristian.marin', STANDARD_HASH('cristian_marin', 'SHA256'), 'User');

INSERT INTO VIP_Clients (Client_ID, Client_Name, Contact_Person, Email, Phone_Number, Client_Since, VIP_Level, Account_Manager_ID, Annual_Revenue, Status)
VALUES (1, 'Tech Solutions SRL', 'Andrei Popescu', 'andrei.popescu@techsolutions.com', '+40721234567', TO_DATE('2017-06-15', 'YYYY-MM-DD'), 'Gold', 1, 2500000.00, 'Active');
INSERT INTO VIP_Clients (Client_ID, Client_Name, Contact_Person, Email, Phone_Number, Client_Since, VIP_Level, Account_Manager_ID, Annual_Revenue, Status)
VALUES (2, 'Innovatech SA', 'Raluca Ionescu', 'raluca.ionescu@innovatech.ro', '+40721567890', TO_DATE('2018-01-22', 'YYYY-MM-DD'), 'Platinum', 2, 5400000.00, 'Active');
INSERT INTO VIP_Clients (Client_ID, Client_Name, Contact_Person, Email, Phone_Number, Client_Since, VIP_Level, Account_Manager_ID, Annual_Revenue, Status)
VALUES (3, 'Green Energy Ltd.', 'Mihai Georgescu', 'mihai.georgescu@greenenergy.com', '+40722112233', TO_DATE('2019-05-10', 'YYYY-MM-DD'), 'Diamond', 3, 7800000.00, 'Active');
INSERT INTO VIP_Clients (Client_ID, Client_Name, Contact_Person, Email, Phone_Number, Client_Since, VIP_Level, Account_Manager_ID, Annual_Revenue, Status)
VALUES (4, 'NextGen Robotics', 'Elena Dumitrescu', 'elena.dumitrescu@nextgenrobotics.com', '+40723004567', TO_DATE('2020-11-05', 'YYYY-MM-DD'), 'Gold', 4, 3200000.00, 'Active');
INSERT INTO VIP_Clients (Client_ID, Client_Name, Contact_Person, Email, Phone_Number, Client_Since, VIP_Level, Account_Manager_ID, Annual_Revenue, Status)
VALUES (5, 'AquaSoft Solutions', 'Cristian Marinescu', 'cristian.marinescu@aquasoft.ro', '+40724005678', TO_DATE('2016-09-30', 'YYYY-MM-DD'), 'Platinum', 5, 4500000.00, 'Active');
INSERT INTO VIP_Clients (Client_ID, Client_Name, Contact_Person, Email, Phone_Number, Client_Since, VIP_Level, Account_Manager_ID, Annual_Revenue, Status)
VALUES (6, 'DigitalWave Corp.', 'Andreea Popa', 'andreea.popa@digitalwave.com', '+40725006789', TO_DATE('2017-12-12', 'YYYY-MM-DD'), 'Diamond', 6, 9100000.00, 'Active');
INSERT INTO VIP_Clients (Client_ID, Client_Name, Contact_Person, Email, Phone_Number, Client_Since, VIP_Level, Account_Manager_ID, Annual_Revenue, Status)
VALUES (7, 'Skyline Enterprises', 'Bogdan Radu', 'bogdan.radu@skylineent.com', '+40726007890', TO_DATE('2019-07-18', 'YYYY-MM-DD'), 'Gold', 7, 2700000.00, 'Active');
INSERT INTO VIP_Clients (Client_ID, Client_Name, Contact_Person, Email, Phone_Number, Client_Since, VIP_Level, Account_Manager_ID, Annual_Revenue, Status)
VALUES (8, 'FinTech Innovators', 'Ioana Petrescu', 'ioana.petrescu@fintechinnovators.com', '+40727008901', TO_DATE('2021-03-21', 'YYYY-MM-DD'), 'Platinum', 8, 6200000.00, 'Active');
INSERT INTO VIP_Clients (Client_ID, Client_Name, Contact_Person, Email, Phone_Number, Client_Since, VIP_Level, Account_Manager_ID, Annual_Revenue, Status)
VALUES (9, 'HealthTech Dynamics', 'Adrian Stoica', 'adrian.stoica@healthtechdynamics.com', '+40728009012', TO_DATE('2018-08-14', 'YYYY-MM-DD'), 'Diamond', 9, 8300000.00, 'Active');
INSERT INTO VIP_Clients (Client_ID, Client_Name, Contact_Person, Email, Phone_Number, Client_Since, VIP_Level, Account_Manager_ID, Annual_Revenue, Status)
VALUES (10, 'SmartHome Systems', 'Gabriela Moldovan', 'gabriela.moldovan@smarthome.com', '+40729001234', TO_DATE('2020-05-26', 'YYYY-MM-DD'), 'Gold', 10, 3100000.00, 'Active');
INSERT INTO VIP_Clients (Client_ID, Client_Name, Contact_Person, Email, Phone_Number, Client_Since, VIP_Level, Account_Manager_ID, Annual_Revenue, Status)
VALUES (11, 'EduTech Solutions', 'Marius Iancu', 'marius.iancu@edutech.com', '+40730002345', TO_DATE('2017-04-10', 'YYYY-MM-DD'), 'Platinum', 11, 5500000.00, 'Active');
INSERT INTO VIP_Clients (Client_ID, Client_Name, Contact_Person, Email, Phone_Number, Client_Since, VIP_Level, Account_Manager_ID, Annual_Revenue, Status)
VALUES (12, 'AutoDrive Inc.', 'Raluca Dumitru', 'raluca.dumitru@autodrive.com', '+40731003456', TO_DATE('2019-10-09', 'YYYY-MM-DD'), 'Diamond', 12, 7900000.00, 'Active');
INSERT INTO VIP_Clients (Client_ID, Client_Name, Contact_Person, Email, Phone_Number, Client_Since, VIP_Level, Account_Manager_ID, Annual_Revenue, Status)
VALUES (13, 'CleanTech Ventures', 'Claudiu Marinescu', 'claudiu.marinescu@cleantech.com', '+40732004567', TO_DATE('2018-02-20', 'YYYY-MM-DD'), 'Gold', 13, 2600000.00, 'Active');
INSERT INTO VIP_Clients (Client_ID, Client_Name, Contact_Person, Email, Phone_Number, Client_Since, VIP_Level, Account_Manager_ID, Annual_Revenue, Status)
VALUES (14, 'Quantum Analytics', 'Elena Ionescu', 'elena.ionescu@quantumanalytics.com', '+40733005678', TO_DATE('2021-09-15', 'YYYY-MM-DD'), 'Platinum', 14, 6100000.00, 'Active');
INSERT INTO VIP_Clients (Client_ID, Client_Name, Contact_Person, Email, Phone_Number, Client_Since, VIP_Level, Account_Manager_ID, Annual_Revenue, Status)
VALUES (15, 'CyberSecure Ltd.', 'Vlad Petrescu', 'vlad.petrescu@cybersecure.com', '+40734006789', TO_DATE('2016-11-30', 'YYYY-MM-DD'), 'Diamond', 15, 8800000.00, 'Active');


INSERT INTO Customers (Customer_ID, Customer_Name, Contact_Person, Email, Phone_Number, Address, City, Country, Registration_Date, Customer_Type, Status) VALUES (1, 'ElectroWorld SRL', 'Ion Popescu', 'contact@electroworld.ro', '+40721234567', 'Str. Libertății 10', 'București', 'Romania', TO_DATE('2018-05-12', 'YYYY-MM-DD'), 'Company', 'Active');
INSERT INTO Customers (Customer_ID, Customer_Name, Contact_Person, Email, Phone_Number, Address, City, Country, Registration_Date, Customer_Type, Status) VALUES (2, 'Maria Ionescu', 'Maria Ionescu', 'maria.ionescu@gmail.com', '+40712345678', 'Str. Mărăști 45', 'Cluj-Napoca', 'Romania', TO_DATE('2020-11-03', 'YYYY-MM-DD'), 'Individual', 'Active');
INSERT INTO Customers (Customer_ID, Customer_Name, Contact_Person, Email, Phone_Number, Address, City, Country, Registration_Date, Customer_Type, Status) VALUES (3, 'Tech Solutions Ltd.', 'George Enescu', 'george.enescu@techsolutions.com', '+442071234567', '12 Baker St', 'London', 'UK', TO_DATE('2019-02-20', 'YYYY-MM-DD'), 'Company', 'Active');
INSERT INTO Customers (Customer_ID, Customer_Name, Contact_Person, Email, Phone_Number, Address, City, Country, Registration_Date, Customer_Type, Status) VALUES (4, 'VIP Stars', 'Alina Popa', 'vipstars@vipclients.com', '+40765432100', 'Str. Eroilor 22', 'Timișoara', 'Romania', TO_DATE('2017-08-30', 'YYYY-MM-DD'), 'VIP', 'Active');
INSERT INTO Customers (Customer_ID, Customer_Name, Contact_Person, Email, Phone_Number, Address, City, Country, Registration_Date, Customer_Type, Status) VALUES (5, 'Andrei Vasilescu', 'Andrei Vasilescu', 'andrei.vasilescu@yahoo.com', '+40721239876', 'Str. Unirii 7', 'Iași', 'Romania', TO_DATE('2021-06-15', 'YYYY-MM-DD'), 'Individual', 'Active');
INSERT INTO Customers (Customer_ID, Customer_Name, Contact_Person, Email, Phone_Number, Address, City, Country, Registration_Date, Customer_Type, Status) VALUES (6, 'Global Marketing AG', 'Sven Schmidt', 'sven.schmidt@globalmarketing.de', '+4915123456789', 'Hauptstrasse 3', 'Berlin', 'Germany', TO_DATE('2016-10-01', 'YYYY-MM-DD'), 'Company', 'Active');
INSERT INTO Customers (Customer_ID, Customer_Name, Contact_Person, Email, Phone_Number, Address, City, Country, Registration_Date, Customer_Type, Status) VALUES (7, 'VIP Platinum Partners', 'Elena Radu', 'platinum@vipclients.com', '+40721239900', 'Bd. Republicii 15', 'Cluj-Napoca', 'Romania', TO_DATE('2015-12-12', 'YYYY-MM-DD'), 'VIP', 'Active');
INSERT INTO Customers (Customer_ID, Customer_Name, Contact_Person, Email, Phone_Number, Address, City, Country, Registration_Date, Customer_Type, Status) VALUES (8, 'Ion Georgescu', 'Ion Georgescu', 'ion.georgescu@hotmail.com', '+40731234567', 'Str. Mihai Viteazul 33', 'Brașov', 'Romania', TO_DATE('2020-01-20', 'YYYY-MM-DD'), 'Individual', 'Inactive');
INSERT INTO Customers (Customer_ID, Customer_Name, Contact_Person, Email, Phone_Number, Address, City, Country, Registration_Date, Customer_Type, Status) VALUES (9, 'Smart Technologies', 'Mihai Popa', 'mihai.popa@smarttech.com', '+40721234588', 'Str. Independentei 89', 'Sibiu', 'Romania', TO_DATE('2019-07-25', 'YYYY-MM-DD'), 'Company', 'Active');
INSERT INTO Customers (Customer_ID, Customer_Name, Contact_Person, Email, Phone_Number, Address, City, Country, Registration_Date, Customer_Type, Status) VALUES (10, 'VIP Gold Clients', 'Andreea Marin', 'gold@vipclients.com', '+40765432222', 'Str. Libertății 88', 'București', 'Romania', TO_DATE('2014-04-10', 'YYYY-MM-DD'), 'VIP', 'Active');
INSERT INTO Customers (Customer_ID, Customer_Name, Contact_Person, Email, Phone_Number, Address, City, Country, Registration_Date, Customer_Type, Status) VALUES (11, 'Alexandru Iancu', 'Alexandru Iancu', 'alex.iancu@gmail.com', '+40722223333', 'Str. Lalelelor 5', 'Constanța', 'Romania', TO_DATE('2021-03-05', 'YYYY-MM-DD'), 'Individual', 'Active');
INSERT INTO Customers (Customer_ID, Customer_Name, Contact_Person, Email, Phone_Number, Address, City, Country, Registration_Date, Customer_Type, Status) VALUES (12, 'Creative Solutions LLC', 'Diana Stanciu', 'diana.stanciu@creativesol.com', '+14155552671', '200 5th Ave', 'New York', 'USA', TO_DATE('2018-09-15', 'YYYY-MM-DD'), 'Company', 'Active');
INSERT INTO Customers (Customer_ID, Customer_Name, Contact_Person, Email, Phone_Number, Address, City, Country, Registration_Date, Customer_Type, Status) VALUES (13, 'VIP Diamond Group', 'Cristian Tudor', 'diamond@vipclients.com', '+40731239999', 'Str. Păcii 10', 'Cluj-Napoca', 'Romania', TO_DATE('2013-11-29', 'YYYY-MM-DD'), 'VIP', 'Active');
INSERT INTO Customers (Customer_ID, Customer_Name, Contact_Person, Email, Phone_Number, Address, City, Country, Registration_Date, Customer_Type, Status) VALUES (14, 'Daniela Popescu', 'Daniela Popescu', 'daniela.popescu@yahoo.com', '+40741234567', 'Str. Libertății 25', 'Timișoara', 'Romania', TO_DATE('2019-08-08', 'YYYY-MM-DD'), 'Individual', 'Active');
INSERT INTO Customers (Customer_ID, Customer_Name, Contact_Person, Email, Phone_Number, Address, City, Country, Registration_Date, Customer_Type, Status) VALUES (15, 'Global Traders Inc.', 'John Smith', 'john.smith@globaltraders.com', '+18005551234', '123 Market St', 'San Francisco', 'USA', TO_DATE('2017-12-01', 'YYYY-MM-DD'), 'Company', 'Inactive');


INSERT INTO Software_Development (Development_ID, Description, Team_Leader_ID, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 'Platforma e-commerce B2B pentru clienți internaționali', 1, 'Active', TO_DATE('2024-09-01', 'YYYY-MM-DD'), TO_DATE('2025-06-30', 'YYYY-MM-DD'));

INSERT INTO Frontend (Frontend_ID, Development_ID, Team_Leader_ID, Frameworks, Technologies, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (1, 1, 2, 'React, Redux', 'JavaScript, TypeScript, HTML5, CSS3', 5, 'Active', TO_DATE('2024-09-01', 'YYYY-MM-DD'), TO_DATE('2025-03-31', 'YYYY-MM-DD'));
INSERT INTO Frontend (Frontend_ID, Development_ID, Team_Leader_ID, Frameworks, Technologies, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (2, 1, 2, 'Angular, RxJS', 'TypeScript, SCSS, Webpack', 5, 'Active', TO_DATE('2024-10-15', 'YYYY-MM-DD'), TO_DATE('2025-05-20', 'YYYY-MM-DD'));
INSERT INTO Frontend (Frontend_ID, Development_ID, Team_Leader_ID, Frameworks, Technologies, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (3, 1, 2, 'Vue.js, Nuxt', 'JavaScript, TailwindCSS, Axios', 5, 'Pending', TO_DATE('2025-01-10', 'YYYY-MM-DD'), TO_DATE('2025-09-10', 'YYYY-MM-DD'));
INSERT INTO Frontend (Frontend_ID, Development_ID, Team_Leader_ID, Frameworks, Technologies, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (4, 1, 2, 'Svelte', 'JavaScript, CSS Modules, Vite', 5, 'Inactive', TO_DATE('2023-11-01', 'YYYY-MM-DD'), TO_DATE('2024-08-01', 'YYYY-MM-DD'));
INSERT INTO Frontend (Frontend_ID, Development_ID, Team_Leader_ID, Frameworks, Technologies, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (5, 1, 2, 'Next.js, React', 'TypeScript, GraphQL, Styled Components', 5, 'Active', TO_DATE('2024-06-01', 'YYYY-MM-DD'), TO_DATE('2025-06-01', 'YYYY-MM-DD'));

INSERT INTO Backend (Backend_ID, Development_ID, Team_Leader_ID, Technologies, Databases, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (1, 1, 7, 'Java, Spring Boot, REST APIs', 'PostgreSQL, Redis', 5, 'Active', TO_DATE('2024-08-01', 'YYYY-MM-DD'), TO_DATE('2025-04-01', 'YYYY-MM-DD'));
INSERT INTO Backend (Backend_ID, Development_ID, Team_Leader_ID, Technologies, Databases, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (2, 1, 7, 'Node.js, Express.js', 'MongoDB, MySQL', 5, 'Pending', TO_DATE('2024-10-15', 'YYYY-MM-DD'), TO_DATE('2025-06-15', 'YYYY-MM-DD'));
INSERT INTO Backend (Backend_ID, Development_ID, Team_Leader_ID, Technologies, Databases, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (3, 1, 7, 'Python, Django, Celery', 'Oracle, Redis', 5, 'Active', TO_DATE('2025-01-05', 'YYYY-MM-DD'), TO_DATE('2025-11-01', 'YYYY-MM-DD'));
INSERT INTO Backend (Backend_ID, Development_ID, Team_Leader_ID, Technologies, Databases, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (4, 1, 7, 'Go, gRPC, REST APIs', 'Cassandra, PostgreSQL', 5, 'Inactive', TO_DATE('2023-09-01', 'YYYY-MM-DD'), TO_DATE('2024-09-01', 'YYYY-MM-DD'));
INSERT INTO Backend (Backend_ID, Development_ID, Team_Leader_ID, Technologies, Databases, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (5, 1, 7, 'Ruby on Rails, Sidekiq', 'MySQL, SQLite', 5, 'Active', TO_DATE('2024-05-10', 'YYYY-MM-DD'), TO_DATE('2025-03-10', 'YYYY-MM-DD'));

INSERT INTO Full_Stack (Full_Stack_ID, Development_ID, Team_Leader_ID, Frontend_Technologies, Backend_Technologies, Databases, Full_Stack_Tools, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (1, 1, 12, 'React, Tailwind CSS', 'Node.js, Express.js', 'MongoDB', 'Docker, Git, Postman', 5, 'Active', TO_DATE('2024-09-01', 'YYYY-MM-DD'), TO_DATE('2025-05-01', 'YYYY-MM-DD'));
INSERT INTO Full_Stack (Full_Stack_ID, Development_ID, Team_Leader_ID, Frontend_Technologies, Backend_Technologies, Databases, Full_Stack_Tools, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (2, 1, 12, 'Angular, SCSS', 'Java, Spring Boot', 'PostgreSQL', 'Kubernetes, Jenkins, JIRA', 5, 'Pending', TO_DATE('2024-11-10', 'YYYY-MM-DD'), TO_DATE('2025-07-30', 'YYYY-MM-DD'));
INSERT INTO Full_Stack (Full_Stack_ID, Development_ID, Team_Leader_ID, Frontend_Technologies, Backend_Technologies, Databases, Full_Stack_Tools, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (3, 1, 12, 'Vue.js, Bootstrap', 'PHP, Laravel', 'MySQL', 'Bitbucket, Composer, Docker', 5, 'Active', TO_DATE('2025-01-15', 'YYYY-MM-DD'), TO_DATE('2025-10-15', 'YYYY-MM-DD'));
INSERT INTO Full_Stack (Full_Stack_ID, Development_ID, Team_Leader_ID, Frontend_Technologies, Backend_Technologies, Databases, Full_Stack_Tools, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (4, 1, 12, 'Svelte, CSS3', 'Go, gRPC', 'CockroachDB', 'GitLab, Helm, Grafana', 5, 'Inactive', TO_DATE('2023-05-20', 'YYYY-MM-DD'), TO_DATE('2024-03-01', 'YYYY-MM-DD'));
INSERT INTO Full_Stack (Full_Stack_ID, Development_ID, Team_Leader_ID, Frontend_Technologies, Backend_Technologies, Databases, Full_Stack_Tools, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (5, 1, 12, 'Blazor, HTML5', 'C#, ASP.NET Core', 'SQL Server', 'Azure DevOps, Visual Studio, Swagger', 5, 'Active', TO_DATE('2024-06-12', 'YYYY-MM-DD'), TO_DATE('2025-04-25', 'YYYY-MM-DD'));

INSERT INTO Mobile (Mobile_ID, Development_ID, Team_Leader_ID, Platforms, Languages, Frameworks, Mobile_Tools, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (1, 1, 17, 'iOS, Android', 'Swift, Kotlin', 'Native', 'Xcode, Android Studio, Firebase', 5, 'Active', TO_DATE('2024-08-01', 'YYYY-MM-DD'), TO_DATE('2025-04-30', 'YYYY-MM-DD'));
INSERT INTO Mobile (Mobile_ID, Development_ID, Team_Leader_ID, Platforms, Languages, Frameworks, Mobile_Tools, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (2, 1, 17, 'iOS', 'Swift', 'SwiftUI', 'Xcode, TestFlight, Fastlane', 5, 'Pending', TO_DATE('2024-11-15', 'YYYY-MM-DD'), TO_DATE('2025-07-01', 'YYYY-MM-DD'));
INSERT INTO Mobile (Mobile_ID, Development_ID, Team_Leader_ID, Platforms, Languages, Frameworks, Mobile_Tools, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (3, 1, 17, 'Android', 'Kotlin', 'Jetpack Compose', 'Android Studio, Gradle, Crashlytics', 5, 'Active', TO_DATE('2025-01-10', 'YYYY-MM-DD'), TO_DATE('2025-09-30', 'YYYY-MM-DD'));
INSERT INTO Mobile (Mobile_ID, Development_ID, Team_Leader_ID, Platforms, Languages, Frameworks, Mobile_Tools, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (4, 1, 17, 'Cross-platform', 'Dart', 'Flutter', 'VS Code, Firebase, Codemagic', 5, 'Inactive', TO_DATE('2023-06-20', 'YYYY-MM-DD'), TO_DATE('2024-03-15', 'YYYY-MM-DD'));
INSERT INTO Mobile (Mobile_ID, Development_ID, Team_Leader_ID, Platforms, Languages, Frameworks, Mobile_Tools, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (5, 1, 17, 'Cross-platform', 'JavaScript, TypeScript', 'React Native', 'Expo, Bitrise, JIRA', 5, 'Active', TO_DATE('2024-05-12', 'YYYY-MM-DD'), TO_DATE('2025-02-28', 'YYYY-MM-DD'));

INSERT INTO DevOps (DevOps_ID, Development_ID, Team_Leader_ID, CI_CD_Tools, Infrastructure_Technologies, Monitoring_Technologies, Configuration_Management, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (1, 1, 456, 'Jenkins, GitLab CI', 'AWS, Docker', 'Prometheus, Grafana', 'Ansible', 5, 'Active', TO_DATE('2024-09-01', 'YYYY-MM-DD'), TO_DATE('2025-05-01', 'YYYY-MM-DD'));
INSERT INTO DevOps (DevOps_ID, Development_ID, Team_Leader_ID, CI_CD_Tools, Infrastructure_Technologies, Monitoring_Technologies, Configuration_Management, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (2, 1, 456, 'Azure DevOps', 'Azure, Kubernetes', 'New Relic, Datadog', 'Terraform', 5, 'Pending', TO_DATE('2025-01-15', 'YYYY-MM-DD'), TO_DATE('2025-10-15', 'YYYY-MM-DD'));
INSERT INTO DevOps (DevOps_ID, Development_ID, Team_Leader_ID, CI_CD_Tools, Infrastructure_Technologies, Monitoring_Technologies, Configuration_Management, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (3, 1, 456, 'CircleCI, Travis CI', 'GCP, Docker Swarm', 'Zabbix, Stackdriver', 'Puppet', 5, 'Inactive', TO_DATE('2023-03-10', 'YYYY-MM-DD'), TO_DATE('2024-01-01', 'YYYY-MM-DD'));
INSERT INTO DevOps (DevOps_ID, Development_ID, Team_Leader_ID, CI_CD_Tools, Infrastructure_Technologies, Monitoring_Technologies, Configuration_Management, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (4, 1, 456, 'GitHub Actions', 'AWS, ECS', 'Elastic Stack', 'Chef', 5, 'Active', TO_DATE('2024-06-01', 'YYYY-MM-DD'), TO_DATE('2025-03-31', 'YYYY-MM-DD'));
INSERT INTO DevOps (DevOps_ID, Development_ID, Team_Leader_ID, CI_CD_Tools, Infrastructure_Technologies, Monitoring_Technologies, Configuration_Management, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (5, 1, 456, 'TeamCity', 'On-premise VMs, VMware', 'Nagios, PRTG', 'SaltStack', 5, 'Pending', TO_DATE('2024-10-01', 'YYYY-MM-DD'), TO_DATE('2025-07-31', 'YYYY-MM-DD'));

INSERT INTO Architecture (Architecture_ID, Development_ID, Team_Leader_ID, Architecture_Type, Design_Patterns, Technical_Decisions, Documentation_Links, Review_Cycle, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (1, 1, 461, 'Microservices', 'Service Registry, Circuit Breaker, API Gateway', 'Split monolith into microservices', 'https://docs.company.com/arch1', 'Quarterly', 5, 'Active', TO_DATE('2024-01-10', 'YYYY-MM-DD'), TO_DATE('2024-12-15', 'YYYY-MM-DD'));
INSERT INTO Architecture (Architecture_ID, Development_ID, Team_Leader_ID, Architecture_Type, Design_Patterns, Technical_Decisions, Documentation_Links, Review_Cycle, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (2, 1, 461, 'Monolithic', 'MVC, Singleton, DAO', 'Use Spring Boot for entire app', 'https://docs.company.com/arch2', 'Bi-Annually', 5, 'Pending', TO_DATE('2024-05-01', 'YYYY-MM-DD'), TO_DATE('2025-03-01', 'YYYY-MM-DD'));
INSERT INTO Architecture (Architecture_ID, Development_ID, Team_Leader_ID, Architecture_Type, Design_Patterns, Technical_Decisions, Documentation_Links, Review_Cycle, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (3, 1, 461, 'Event-Driven', 'Publisher-Subscriber, CQRS', 'Integrate Kafka as core bus', 'https://docs.company.com/arch3', 'Monthly', 5, 'Inactive', TO_DATE('2023-06-15', 'YYYY-MM-DD'), TO_DATE('2024-04-15', 'YYYY-MM-DD'));
INSERT INTO Architecture (Architecture_ID, Development_ID, Team_Leader_ID, Architecture_Type, Design_Patterns, Technical_Decisions, Documentation_Links, Review_Cycle, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (4, 1, 461, 'Layered Architecture', 'Repository, Facade, Adapter', 'Apply strict layer boundaries', 'https://docs.company.com/arch4', 'Every Sprint', 5, 'Active', TO_DATE('2024-09-01', 'YYYY-MM-DD'), TO_DATE('2025-06-01', 'YYYY-MM-DD'));
INSERT INTO Architecture (Architecture_ID, Development_ID, Team_Leader_ID, Architecture_Type, Design_Patterns, Technical_Decisions, Documentation_Links, Review_Cycle, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (5, 1, 461, 'Serverless', 'Function-based, Stateless', 'Adopt AWS Lambda and API Gateway', 'https://docs.company.com/arch5', 'Per Release', 5, 'Pending', TO_DATE('2024-11-20', 'YYYY-MM-DD'), TO_DATE('2025-08-30', 'YYYY-MM-DD'));

INSERT INTO QA_Testing (QA_ID, Description, Team_Leader_ID, Focus_Area, Tested_Projects, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 'Testare completă pentru sistemul de management al documentelor', 22, 'Automated Testing, UI/UX Testing, Performance Testing', 8, 6, 'Active', TO_DATE('2024-03-01', 'YYYY-MM-DD'), TO_DATE('2024-12-15', 'YYYY-MM-DD'));

INSERT INTO Manual_Testing (Manual_Testing_ID, QA_ID, Team_Leader_ID, Test_Types, Test_Cases_Documented, Reported_Defects, Documentation_Tools, Used_Environments, Client_Interaction, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 2, 23, 'Functional, Regression', 120, 34, 'TestRail, Confluence', 'Windows, macOS', 'Yes', 5, 'Active', TO_DATE('2024-01-15', 'YYYY-MM-DD'), TO_DATE('2024-06-30', 'YYYY-MM-DD'));
INSERT INTO Manual_Testing (Manual_Testing_ID, QA_ID, Team_Leader_ID, Test_Types, Test_Cases_Documented, Reported_Defects, Documentation_Tools, Used_Environments, Client_Interaction, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (2, 2, 23, 'Exploratory, Smoke', 85, 19, 'Zephyr, Jira', 'Linux, Android', 'No', 5, 'Active', TO_DATE('2023-09-01', 'YYYY-MM-DD'), TO_DATE('2024-02-20', 'YYYY-MM-DD'));
INSERT INTO Manual_Testing (Manual_Testing_ID, QA_ID, Team_Leader_ID, Test_Types, Test_Cases_Documented, Reported_Defects, Documentation_Tools, Used_Environments, Client_Interaction, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 2, 23, 'Integration, Usability', 100, 25, 'TestLink, SharePoint', 'iOS, Web', 'Yes', 5, 'Pending', TO_DATE('2024-04-01', 'YYYY-MM-DD'), TO_DATE('2024-11-10', 'YYYY-MM-DD'));
INSERT INTO Manual_Testing (Manual_Testing_ID, QA_ID, Team_Leader_ID, Test_Types, Test_Cases_Documented, Reported_Defects, Documentation_Tools, Used_Environments, Client_Interaction, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 2, 23, 'Sanity, Compatibility', 75, 11, 'Excel, Word', 'Windows, Linux', 'No', 5, 'Active', TO_DATE('2023-06-10', 'YYYY-MM-DD'), TO_DATE('2023-12-10', 'YYYY-MM-DD'));
INSERT INTO Manual_Testing (Manual_Testing_ID, QA_ID, Team_Leader_ID, Test_Types, Test_Cases_Documented, Reported_Defects, Documentation_Tools, Used_Environments, Client_Interaction, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 2, 23, 'Ad-hoc, Functional', 95, 22, 'qTest, OneNote', 'macOS, ChromeOS', 'Yes', 5, 'Active', TO_DATE('2024-05-01', 'YYYY-MM-DD'), TO_DATE('2024-10-15', 'YYYY-MM-DD'));

INSERT INTO Automated_Testing (Automated_Testing_ID, QA_ID, Team_Leader_ID, Frameworks, Languages, Coverage_Percentage,Test_Cases_Documented, Tools, CI_CD_Integration, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 2, 28, 'Selenium, TestNG', 'Java, Python', 85, 200, 'Jenkins, Allure, GitLab CI', 'Yes', 5, 'Active', TO_DATE('2024-01-10', 'YYYY-MM-DD'), TO_DATE('2024-06-15', 'YYYY-MM-DD'));
INSERT INTO Automated_Testing (Automated_Testing_ID, QA_ID, Team_Leader_ID, Frameworks, Languages, Coverage_Percentage, Test_Cases_Documented, Tools, CI_CD_Integration, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 2, 28, 'Cypress', 'JavaScript, TypeScript', 75, 150, 'CircleCI, Mocha, Chai', 'Yes', 5, 'Active', TO_DATE('2023-08-01', 'YYYY-MM-DD'), TO_DATE('2024-01-20', 'YYYY-MM-DD'));
INSERT INTO Automated_Testing (Automated_Testing_ID, QA_ID, Team_Leader_ID, Frameworks, Languages, Coverage_Percentage, Test_Cases_Documented, Tools, CI_CD_Integration, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 2, 28, 'Robot Framework', 'Python', 65, 120, 'Azure DevOps, Postman, Pytest', 'No', 5, 'Pending', TO_DATE('2024-04-05', 'YYYY-MM-DD'), TO_DATE('2024-11-30', 'YYYY-MM-DD'));
INSERT INTO Automated_Testing (Automated_Testing_ID, QA_ID, Team_Leader_ID, Frameworks, Languages, Coverage_Percentage, Test_Cases_Documented, Tools, CI_CD_Integration, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 2, 28, 'Jest, Puppeteer', 'JavaScript', 70, 130, 'GitHub Actions, Jest HTML Reporter', 'Yes', 5, 'Active', TO_DATE('2023-05-20', 'YYYY-MM-DD'), TO_DATE('2023-12-05', 'YYYY-MM-DD'));
INSERT INTO Automated_Testing (Automated_Testing_ID, QA_ID, Team_Leader_ID, Frameworks, Languages, Coverage_Percentage, Test_Cases_Documented, Tools, CI_CD_Integration, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 2, 28, 'Playwright', 'Python, JavaScript', 90, 250, 'GitLab CI, Allure, Docker', 'Yes', 5, 'Active', TO_DATE('2024-02-15', 'YYYY-MM-DD'), TO_DATE('2024-07-31', 'YYYY-MM-DD'));

INSERT INTO QA_Testing (QA_ID, Description, Team_Leader_ID, Focus_Area, Tested_Projects, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 'Testare completă pentru sistemul de management al documentelor', 22, 'Automated Testing, UI/UX Testing, Performance Testing', 8, 6, 'Active', TO_DATE('2024-03-01', 'YYYY-MM-DD'), TO_DATE('2024-12-15', 'YYYY-MM-DD'));

INSERT INTO Manual_Testing (Manual_Testing_ID, QA_ID, Team_Leader_ID, Test_Types, Test_Cases_Documented, Reported_Defects, Documentation_Tools, Used_Environments, Client_Interaction, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 2, 23, 'Functional, Regression', 120, 34, 'TestRail, Confluence', 'Windows, macOS', 'Yes', 5, 'Active', TO_DATE('2024-01-15', 'YYYY-MM-DD'), TO_DATE('2024-06-30', 'YYYY-MM-DD'));
INSERT INTO Manual_Testing (Manual_Testing_ID, QA_ID, Team_Leader_ID, Test_Types, Test_Cases_Documented, Reported_Defects, Documentation_Tools, Used_Environments, Client_Interaction, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (2, 2, 23, 'Exploratory, Smoke', 85, 19, 'Zephyr, Jira', 'Linux, Android', 'No', 5, 'Active', TO_DATE('2023-09-01', 'YYYY-MM-DD'), TO_DATE('2024-02-20', 'YYYY-MM-DD'));
INSERT INTO Manual_Testing (Manual_Testing_ID, QA_ID, Team_Leader_ID, Test_Types, Test_Cases_Documented, Reported_Defects, Documentation_Tools, Used_Environments, Client_Interaction, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 2, 23, 'Integration, Usability', 100, 25, 'TestLink, SharePoint', 'iOS, Web', 'Yes', 5, 'Pending', TO_DATE('2024-04-01', 'YYYY-MM-DD'), TO_DATE('2024-11-10', 'YYYY-MM-DD'));
INSERT INTO Manual_Testing (Manual_Testing_ID, QA_ID, Team_Leader_ID, Test_Types, Test_Cases_Documented, Reported_Defects, Documentation_Tools, Used_Environments, Client_Interaction, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 2, 23, 'Sanity, Compatibility', 75, 11, 'Excel, Word', 'Windows, Linux', 'No', 5, 'Active', TO_DATE('2023-06-10', 'YYYY-MM-DD'), TO_DATE('2023-12-10', 'YYYY-MM-DD'));
INSERT INTO Manual_Testing (Manual_Testing_ID, QA_ID, Team_Leader_ID, Test_Types, Test_Cases_Documented, Reported_Defects, Documentation_Tools, Used_Environments, Client_Interaction, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 2, 23, 'Ad-hoc, Functional', 95, 22, 'qTest, OneNote', 'macOS, ChromeOS', 'Yes', 5, 'Active', TO_DATE('2024-05-01', 'YYYY-MM-DD'), TO_DATE('2024-10-15', 'YYYY-MM-DD'));

INSERT INTO Automated_Testing (Automated_Testing_ID, QA_ID, Team_Leader_ID, Frameworks, Languages, Coverage_Percentage,Test_Cases_Documented, Tools, CI_CD_Integration, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 2, 28, 'Selenium, TestNG', 'Java, Python', 85, 200, 'Jenkins, Allure, GitLab CI', 'Yes', 5, 'Active', TO_DATE('2024-01-10', 'YYYY-MM-DD'), TO_DATE('2024-06-15', 'YYYY-MM-DD'));
INSERT INTO Automated_Testing (Automated_Testing_ID, QA_ID, Team_Leader_ID, Frameworks, Languages, Coverage_Percentage, Test_Cases_Documented, Tools, CI_CD_Integration, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 2, 28, 'Cypress', 'JavaScript, TypeScript', 75, 150, 'CircleCI, Mocha, Chai', 'Yes', 5, 'Active', TO_DATE('2023-08-01', 'YYYY-MM-DD'), TO_DATE('2024-01-20', 'YYYY-MM-DD'));
INSERT INTO Automated_Testing (Automated_Testing_ID, QA_ID, Team_Leader_ID, Frameworks, Languages, Coverage_Percentage, Test_Cases_Documented, Tools, CI_CD_Integration, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 2, 28, 'Robot Framework', 'Python', 65, 120, 'Azure DevOps, Postman, Pytest', 'No', 5, 'Pending', TO_DATE('2024-04-05', 'YYYY-MM-DD'), TO_DATE('2024-11-30', 'YYYY-MM-DD'));
INSERT INTO Automated_Testing (Automated_Testing_ID, QA_ID, Team_Leader_ID, Frameworks, Languages, Coverage_Percentage, Test_Cases_Documented, Tools, CI_CD_Integration, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 2, 28, 'Jest, Puppeteer', 'JavaScript', 70, 130, 'GitHub Actions, Jest HTML Reporter', 'Yes', 5, 'Active', TO_DATE('2023-05-20', 'YYYY-MM-DD'), TO_DATE('2023-12-05', 'YYYY-MM-DD'));
INSERT INTO Automated_Testing (Automated_Testing_ID, QA_ID, Team_Leader_ID, Frameworks, Languages, Coverage_Percentage, Test_Cases_Documented, Tools, CI_CD_Integration, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 2, 28, 'Playwright', 'Python, JavaScript', 90, 250, 'GitLab CI, Allure, Docker', 'Yes', 5, 'Active', TO_DATE('2024-02-15', 'YYYY-MM-DD'), TO_DATE('2024-07-31', 'YYYY-MM-DD'));

INSERT INTO Performance_Testing (Performance_Testing_ID, QA_ID, Team_Leader_ID, Test_Types, Tools, Monitored_Metrics, Concurrent_Users, Duration_Seconds, Infrastructure, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 2, 33, 'Load, Stress', 'JMeter, Grafana', 'Throughput, Latency', 500, 3600, 'AWS EC2, RDS', 5, 'Active', TO_DATE('2024-02-01', 'YYYY-MM-DD'), TO_DATE('2024-05-01', 'YYYY-MM-DD'));
INSERT INTO Performance_Testing (Performance_Testing_ID, QA_ID, Team_Leader_ID, Test_Types, Tools, Monitored_Metrics, Concurrent_Users, Duration_Seconds, Infrastructure, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 2, 33, 'Soak, Spike', 'LoadRunner, Dynatrace', 'Memory, CPU, Errors', 1000, 7200, 'Azure VM, SQL DB', 5, 'Active', TO_DATE('2023-11-15', 'YYYY-MM-DD'), TO_DATE('2024-03-15', 'YYYY-MM-DD'));
INSERT INTO Performance_Testing (Performance_Testing_ID, QA_ID, Team_Leader_ID, Test_Types, Tools, Monitored_Metrics, Concurrent_Users, Duration_Seconds, Infrastructure, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 2, 33, 'Load', 'Gatling, Prometheus', 'Response Time, CPU', 300, 1800, 'On-Prem Linux Servers', 5, 'Pending', TO_DATE('2024-04-01', 'YYYY-MM-DD'), TO_DATE('2024-07-01', 'YYYY-MM-DD'));
INSERT INTO Performance_Testing (Performance_Testing_ID, QA_ID, Team_Leader_ID, Test_Types, Tools, Monitored_Metrics, Concurrent_Users, Duration_Seconds, Infrastructure, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 2, 33, 'Stress', 'NeoLoad, Zabbix', 'Latency, Errors', 1500, 5400, 'Hybrid Cloud (AWS + On-Prem)', 5, 'Active', TO_DATE('2024-01-20', 'YYYY-MM-DD'), TO_DATE('2024-04-20', 'YYYY-MM-DD'));
INSERT INTO Performance_Testing (Performance_Testing_ID, QA_ID, Team_Leader_ID, Test_Types, Tools, Monitored_Metrics, Concurrent_Users, Duration_Seconds, Infrastructure, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 2, 33, 'Endurance', 'K6, New Relic', 'Memory Leak, Throughput', 200, 10800, 'Google Cloud Kubernetes', 4, 'Inactive', TO_DATE('2024-03-01', 'YYYY-MM-DD'), TO_DATE('2024-06-01', 'YYYY-MM-DD'));

INSERT INTO Security_Testing (Security_Testing_ID, QA_ID, Team_Leader_ID, Methods, Tools, Vulnerabilities_Found, Applied_Standards, Incidents_Reported, Client_Data_Access, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 2, 38, 'Penetration Testing', 'Burp Suite, OWASP ZAP', 12, 'OWASP Top 10', 1, 'Yes', 5, 'Active', TO_DATE('2024-01-15', 'YYYY-MM-DD'), TO_DATE('2024-04-10', 'YYYY-MM-DD'));
INSERT INTO Security_Testing (Security_Testing_ID, QA_ID, Team_Leader_ID, Methods, Tools, Vulnerabilities_Found, Applied_Standards, Incidents_Reported, Client_Data_Access, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 2, 38, 'Vulnerability Scanning', 'Nessus, Qualys', 8, 'CIS Benchmarks', 0, 'No', 5, 'Pending', TO_DATE('2023-11-01', 'YYYY-MM-DD'), TO_DATE('2024-02-01', 'YYYY-MM-DD'));
INSERT INTO Security_Testing (Security_Testing_ID, QA_ID, Team_Leader_ID, Methods, Tools, Vulnerabilities_Found, Applied_Standards, Incidents_Reported, Client_Data_Access, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 2, 38, 'Code Review, Fuzzing', 'SonarQube, AFL', 5, 'ISO/IEC 27001', 0, 'No', 5, 'Active', TO_DATE('2024-03-10', 'YYYY-MM-DD'), TO_DATE('2024-06-10', 'YYYY-MM-DD'));
INSERT INTO Security_Testing (Security_Testing_ID, QA_ID, Team_Leader_ID, Methods, Tools, Vulnerabilities_Found, Applied_Standards, Incidents_Reported, Client_Data_Access, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 2, 38, 'Security Audit', 'OpenVAS, Metasploit', 15, 'NIST SP 800-115', 2, 'Yes', 5, 'Active', TO_DATE('2024-02-20', 'YYYY-MM-DD'), TO_DATE('2024-05-20', 'YYYY-MM-DD'));
INSERT INTO Security_Testing (Security_Testing_ID, QA_ID, Team_Leader_ID, Methods, Tools, Vulnerabilities_Found, Applied_Standards, Incidents_Reported, Client_Data_Access, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 2, 38, 'Threat Modeling', 'Threat Dragon, STRIDE Tools', 3, 'OWASP SAMM', 0, 'No', 5, 'Inactive', TO_DATE('2024-04-01', 'YYYY-MM-DD'), TO_DATE('2024-07-01', 'YYYY-MM-DD'));

INSERT INTO Mobile_Testing (Mobile_Testing_ID, QA_ID, Team_Leader_ID, Tested_Platforms, Devices, Automation, Automation_Tools, Manual_Testing_Percent, Defects_Reported, Network_Conditions, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 2, 43, 'iOS, Android', 'iPhone 13, Samsung Galaxy S22', 'Yes', 'Appium, Espresso', 30, 12, 'Wi-Fi, 4G', 5, 'Active', TO_DATE('2024-01-10', 'YYYY-MM-DD'), TO_DATE('2024-03-10', 'YYYY-MM-DD'));
INSERT INTO Mobile_Testing (Mobile_Testing_ID, QA_ID, Team_Leader_ID, Tested_Platforms, Devices, Automation, Automation_Tools, Manual_Testing_Percent, Defects_Reported, Network_Conditions, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 2, 43, 'Android', 'Pixel 6, OnePlus 9', 'No', NULL, 100, 20, '3G, 5G', 5, 'Pending', TO_DATE('2024-02-15', 'YYYY-MM-DD'), TO_DATE('2024-04-15', 'YYYY-MM-DD'));
INSERT INTO Mobile_Testing (Mobile_Testing_ID, QA_ID, Team_Leader_ID, Tested_Platforms, Devices, Automation, Automation_Tools, Manual_Testing_Percent, Defects_Reported, Network_Conditions, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 2, 43, 'iOS', 'iPhone SE, iPhone 14', 'Yes', 'XCTest', 50, 10, 'LTE, Wi-Fi', 5, 'Active', TO_DATE('2023-11-01', 'YYYY-MM-DD'), TO_DATE('2024-01-30', 'YYYY-MM-DD'));
INSERT INTO Mobile_Testing (Mobile_Testing_ID, QA_ID, Team_Leader_ID, Tested_Platforms, Devices, Automation, Automation_Tools, Manual_Testing_Percent, Defects_Reported, Network_Conditions, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 2, 43, 'iOS, Android', 'Samsung Galaxy A52, iPad Mini', 'Yes', 'Detox, Appium', 40, 15, 'Wi-Fi, 3G', 5, 'Inactive', TO_DATE('2024-03-01', 'YYYY-MM-DD'), TO_DATE('2024-06-01', 'YYYY-MM-DD'));
INSERT INTO Mobile_Testing (Mobile_Testing_ID, QA_ID, Team_Leader_ID, Tested_Platforms, Devices, Automation, Automation_Tools, Manual_Testing_Percent, Defects_Reported, Network_Conditions, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 2, 43, 'Android', 'Xiaomi Mi 11, Oppo Find X3', 'No', NULL, 100, 8, '5G, LTE', 5, 'Pending', TO_DATE('2024-05-10', 'YYYY-MM-DD'), TO_DATE('2024-07-30', 'YYYY-MM-DD'));

INSERT INTO UI_UX_Testing (UI_UX_Testing_ID, QA_ID, Team_Leader_ID, Devices_Resolutions, Design_Guidelines, Tools, Issues_Reported, A_B_Testing, Accessibility, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 2, 48, '1920x1080, 1366x768', 'Material Design', 'Figma, Zeplin', 12, 'Yes', 'Yes', 4, 'Active', TO_DATE('2024-01-10', 'YYYY-MM-DD'), TO_DATE('2024-03-01', 'YYYY-MM-DD'));
INSERT INTO UI_UX_Testing (UI_UX_Testing_ID, QA_ID, Team_Leader_ID, Devices_Resolutions, Design_Guidelines, Tools, Issues_Reported, A_B_Testing, Accessibility, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 2, 48, '1280x720, 1600x900', 'Apple HIG', 'Sketch, InVision', 7, 'No', 'Yes', 3, 'Pending', TO_DATE('2024-02-05', 'YYYY-MM-DD'), TO_DATE('2024-04-15', 'YYYY-MM-DD'));
INSERT INTO UI_UX_Testing (UI_UX_Testing_ID, QA_ID, Team_Leader_ID, Devices_Resolutions, Design_Guidelines, Tools, Issues_Reported, A_B_Testing, Accessibility, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 2, 48, '1440x900, 1024x768', 'Custom Enterprise Guidelines', 'Adobe XD', 5, 'Yes', 'No', 5, 'Inactive', TO_DATE('2023-12-01', 'YYYY-MM-DD'), TO_DATE('2024-02-28', 'YYYY-MM-DD'));
INSERT INTO UI_UX_Testing (UI_UX_Testing_ID, QA_ID, Team_Leader_ID, Devices_Resolutions, Design_Guidelines, Tools, Issues_Reported, A_B_Testing, Accessibility, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 2, 48, '2560x1440, 1366x768', 'Fluent UI', 'Figma, Miro', 9, 'No', 'Yes', 6, 'Active', TO_DATE('2024-03-10', 'YYYY-MM-DD'), TO_DATE('2024-05-25', 'YYYY-MM-DD'));
INSERT INTO UI_UX_Testing (UI_UX_Testing_ID, QA_ID, Team_Leader_ID, Devices_Resolutions, Design_Guidelines, Tools, Issues_Reported, A_B_Testing, Accessibility, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 2, 48, '1920x1080, 768x1024', 'WCAG Standards', 'Axure RP, Zeplin', 14, 'Yes', 'Yes', 4, 'Pending', TO_DATE('2024-04-01', 'YYYY-MM-DD'), TO_DATE('2024-06-15', 'YYYY-MM-DD'));

INSERT INTO Security_Testing (Security_Testing_ID, QA_ID, Team_Leader_ID, Methods, Tools, Vulnerabilities_Found, Applied_Standards, Incidents_Reported, Client_Data_Access, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 2, 38, 'Penetration Testing', 'Burp Suite, OWASP ZAP', 12, 'OWASP Top 10', 1, 'Yes', 5, 'Active', TO_DATE('2024-01-15', 'YYYY-MM-DD'), TO_DATE('2024-04-10', 'YYYY-MM-DD'));
INSERT INTO Security_Testing (Security_Testing_ID, QA_ID, Team_Leader_ID, Methods, Tools, Vulnerabilities_Found, Applied_Standards, Incidents_Reported, Client_Data_Access, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 2, 38, 'Vulnerability Scanning', 'Nessus, Qualys', 8, 'CIS Benchmarks', 0, 'No', 5, 'Pending', TO_DATE('2023-11-01', 'YYYY-MM-DD'), TO_DATE('2024-02-01', 'YYYY-MM-DD'));
INSERT INTO Security_Testing (Security_Testing_ID, QA_ID, Team_Leader_ID, Methods, Tools, Vulnerabilities_Found, Applied_Standards, Incidents_Reported, Client_Data_Access, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 2, 38, 'Code Review, Fuzzing', 'SonarQube, AFL', 5, 'ISO/IEC 27001', 0, 'No', 5, 'Active', TO_DATE('2024-03-10', 'YYYY-MM-DD'), TO_DATE('2024-06-10', 'YYYY-MM-DD'));
INSERT INTO Security_Testing (Security_Testing_ID, QA_ID, Team_Leader_ID, Methods, Tools, Vulnerabilities_Found, Applied_Standards, Incidents_Reported, Client_Data_Access, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 2, 38, 'Security Audit', 'OpenVAS, Metasploit', 15, 'NIST SP 800-115', 2, 'Yes', 5, 'Active', TO_DATE('2024-02-20', 'YYYY-MM-DD'), TO_DATE('2024-05-20', 'YYYY-MM-DD'));
INSERT INTO Security_Testing (Security_Testing_ID, QA_ID, Team_Leader_ID, Methods, Tools, Vulnerabilities_Found, Applied_Standards, Incidents_Reported, Client_Data_Access, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 2, 38, 'Threat Modeling', 'Threat Dragon, STRIDE Tools', 3, 'OWASP SAMM', 0, 'No', 5, 'Inactive', TO_DATE('2024-04-01', 'YYYY-MM-DD'), TO_DATE('2024-07-01', 'YYYY-MM-DD'));

INSERT INTO Mobile_Testing (Mobile_Testing_ID, QA_ID, Team_Leader_ID, Tested_Platforms, Devices, Automation, Automation_Tools, Manual_Testing_Percent, Defects_Reported, Network_Conditions, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 2, 43, 'iOS, Android', 'iPhone 13, Samsung Galaxy S22', 'Yes', 'Appium, Espresso', 30, 12, 'Wi-Fi, 4G', 5, 'Active', TO_DATE('2024-01-10', 'YYYY-MM-DD'), TO_DATE('2024-03-10', 'YYYY-MM-DD'));
INSERT INTO Mobile_Testing (Mobile_Testing_ID, QA_ID, Team_Leader_ID, Tested_Platforms, Devices, Automation, Automation_Tools, Manual_Testing_Percent, Defects_Reported, Network_Conditions, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 2, 43, 'Android', 'Pixel 6, OnePlus 9', 'No', NULL, 100, 20, '3G, 5G', 5, 'Pending', TO_DATE('2024-02-15', 'YYYY-MM-DD'), TO_DATE('2024-04-15', 'YYYY-MM-DD'));
INSERT INTO Mobile_Testing (Mobile_Testing_ID, QA_ID, Team_Leader_ID, Tested_Platforms, Devices, Automation, Automation_Tools, Manual_Testing_Percent, Defects_Reported, Network_Conditions, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 2, 43, 'iOS', 'iPhone SE, iPhone 14', 'Yes', 'XCTest', 50, 10, 'LTE, Wi-Fi', 5, 'Active', TO_DATE('2023-11-01', 'YYYY-MM-DD'), TO_DATE('2024-01-30', 'YYYY-MM-DD'));
INSERT INTO Mobile_Testing (Mobile_Testing_ID, QA_ID, Team_Leader_ID, Tested_Platforms, Devices, Automation, Automation_Tools, Manual_Testing_Percent, Defects_Reported, Network_Conditions, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 2, 43, 'iOS, Android', 'Samsung Galaxy A52, iPad Mini', 'Yes', 'Detox, Appium', 40, 15, 'Wi-Fi, 3G', 5, 'Inactive', TO_DATE('2024-03-01', 'YYYY-MM-DD'), TO_DATE('2024-06-01', 'YYYY-MM-DD'));
INSERT INTO Mobile_Testing (Mobile_Testing_ID, QA_ID, Team_Leader_ID, Tested_Platforms, Devices, Automation, Automation_Tools, Manual_Testing_Percent, Defects_Reported, Network_Conditions, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 2, 43, 'Android', 'Xiaomi Mi 11, Oppo Find X3', 'No', NULL, 100, 8, '5G, LTE', 5, 'Pending', TO_DATE('2024-05-10', 'YYYY-MM-DD'), TO_DATE('2024-07-30', 'YYYY-MM-DD'));

INSERT INTO UI_UX_Testing (UI_UX_Testing_ID, QA_ID, Team_Leader_ID, Devices_Resolutions, Design_Guidelines, Tools, Issues_Reported, A_B_Testing, Accessibility, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 2, 48, '1920x1080, 1366x768', 'Material Design', 'Figma, Zeplin', 12, 'Yes', 'Yes', 4, 'Active', TO_DATE('2024-01-10', 'YYYY-MM-DD'), TO_DATE('2024-03-01', 'YYYY-MM-DD'));
INSERT INTO UI_UX_Testing (UI_UX_Testing_ID, QA_ID, Team_Leader_ID, Devices_Resolutions, Design_Guidelines, Tools, Issues_Reported, A_B_Testing, Accessibility, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 2, 48, '1280x720, 1600x900', 'Apple HIG', 'Sketch, InVision', 7, 'No', 'Yes', 3, 'Pending', TO_DATE('2024-02-05', 'YYYY-MM-DD'), TO_DATE('2024-04-15', 'YYYY-MM-DD'));
INSERT INTO UI_UX_Testing (UI_UX_Testing_ID, QA_ID, Team_Leader_ID, Devices_Resolutions, Design_Guidelines, Tools, Issues_Reported, A_B_Testing, Accessibility, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 2, 48, '1440x900, 1024x768', 'Custom Enterprise Guidelines', 'Adobe XD', 5, 'Yes', 'No', 5, 'Inactive', TO_DATE('2023-12-01', 'YYYY-MM-DD'), TO_DATE('2024-02-28', 'YYYY-MM-DD'));
INSERT INTO UI_UX_Testing (UI_UX_Testing_ID, QA_ID, Team_Leader_ID, Devices_Resolutions, Design_Guidelines, Tools, Issues_Reported, A_B_Testing, Accessibility, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 2, 48, '2560x1440, 1366x768', 'Fluent UI', 'Figma, Miro', 9, 'No', 'Yes', 6, 'Active', TO_DATE('2024-03-10', 'YYYY-MM-DD'), TO_DATE('2024-05-25', 'YYYY-MM-DD'));
INSERT INTO UI_UX_Testing (UI_UX_Testing_ID, QA_ID, Team_Leader_ID, Devices_Resolutions, Design_Guidelines, Tools, Issues_Reported, A_B_Testing, Accessibility, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 2, 48, '1920x1080, 768x1024', 'WCAG Standards', 'Axure RP, Zeplin', 14, 'Yes', 'Yes', 4, 'Pending', TO_DATE('2024-04-01', 'YYYY-MM-DD'), TO_DATE('2024-06-15', 'YYYY-MM-DD'));

INSERT INTO Project_Management (PJ_ID, Description, Team_Leader_ID, Methodology, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 'Implementare sistem de gestiune resurse interne', 49, 'Agile', 5, 'Active', TO_DATE('2024-01-05', 'YYYY-MM-DD'), TO_DATE('2024-06-30', 'YYYY-MM-DD'));

INSERT INTO Agile (Agile_ID, PJ_ID, Team_Leader_ID, Scrum_Teams, Sprint_Length, Framework, Tools, Daily_Meetings, Retrospectives, Has_Product_Owner, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 3, 50, 2, 2, 'Scrum', 'Jira, Confluence', 'Yes', 'Yes', 'Yes', 5, 'Active', TO_DATE('2024-01-05', 'YYYY-MM-DD'), TO_DATE('2024-06-30', 'YYYY-MM-DD'));
INSERT INTO Agile (Agile_ID, PJ_ID, Team_Leader_ID, Scrum_Teams, Sprint_Length, Framework, Tools, Daily_Meetings, Retrospectives, Has_Product_Owner, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 3, 50, 1, 3, 'ScrumBan', 'Trello', 'Yes', 'No', 'Yes', 5, 'Pending', TO_DATE('2024-02-01', 'YYYY-MM-DD'), TO_DATE('2024-07-01', 'YYYY-MM-DD'));
INSERT INTO Agile (Agile_ID, PJ_ID, Team_Leader_ID, Scrum_Teams, Sprint_Length, Framework, Tools, Daily_Meetings, Retrospectives, Has_Product_Owner, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 3, 50, 3, 2, 'Scrum', 'Azure DevOps', 'Yes', 'Yes', 'No', 5, 'Active', TO_DATE('2024-03-10', 'YYYY-MM-DD'), TO_DATE('2024-08-10', 'YYYY-MM-DD'));
INSERT INTO Agile (Agile_ID, PJ_ID, Team_Leader_ID, Scrum_Teams, Sprint_Length, Framework, Tools, Daily_Meetings, Retrospectives, Has_Product_Owner, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 3, 50, 2, 1, 'LeSS', 'Jira', 'No', 'Yes', 'Yes', 5, 'Inactive', TO_DATE('2024-01-20', 'YYYY-MM-DD'), TO_DATE('2024-05-20', 'YYYY-MM-DD'));
INSERT INTO Agile (Agile_ID, PJ_ID, Team_Leader_ID, Scrum_Teams, Sprint_Length, Framework, Tools, Daily_Meetings, Retrospectives, Has_Product_Owner, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 3, 50, 1, 4, 'SAFe', 'VersionOne, Confluence', 'Yes', 'No', 'Yes', 5, 'Pending', TO_DATE('2024-04-01', 'YYYY-MM-DD'), TO_DATE('2024-09-01', 'YYYY-MM-DD'));

INSERT INTO Waterfall (Waterfall_ID, PJ_ID, Team_Leader_ID, Active_Projects, Number_Of_Phases, Current_Phase, Full_Documentation, Has_Gantt_Chart, Tools, Delay_Estimate_Days, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 3, 55, 3, 5, 'Design', 'Yes', 'Yes', 'MS Project, GanttPRO', 10, 5, 'Active', TO_DATE('2024-01-05', 'YYYY-MM-DD'), TO_DATE('2024-06-30', 'YYYY-MM-DD'));
INSERT INTO Waterfall (Waterfall_ID, PJ_ID, Team_Leader_ID, Active_Projects, Number_Of_Phases, Current_Phase, Full_Documentation, Has_Gantt_Chart, Tools, Delay_Estimate_Days, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 3, 55, 2, 6, 'Implementation', 'No', 'Yes', 'Smartsheet', 15, 5, 'Pending', TO_DATE('2024-02-01', 'YYYY-MM-DD'), TO_DATE('2024-07-01', 'YYYY-MM-DD'));
INSERT INTO Waterfall (Waterfall_ID, PJ_ID, Team_Leader_ID, Active_Projects, Number_Of_Phases, Current_Phase, Full_Documentation, Has_Gantt_Chart, Tools, Delay_Estimate_Days, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 3, 55, 1, 4, 'Testing', 'Yes', 'No', 'Wrike', 5, 5, 'Active', TO_DATE('2024-03-10', 'YYYY-MM-DD'), TO_DATE('2024-08-10', 'YYYY-MM-DD'));
INSERT INTO Waterfall (Waterfall_ID, PJ_ID, Team_Leader_ID, Active_Projects, Number_Of_Phases, Current_Phase, Full_Documentation, Has_Gantt_Chart, Tools, Delay_Estimate_Days, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 3, 55, 4, 7, 'Requirements Gathering', 'Yes', 'Yes', 'TeamGantt', 7, 5, 'Inactive', TO_DATE('2024-01-20', 'YYYY-MM-DD'), TO_DATE('2024-05-20', 'YYYY-MM-DD'));
INSERT INTO Waterfall (Waterfall_ID, PJ_ID, Team_Leader_ID, Active_Projects, Number_Of_Phases, Current_Phase, Full_Documentation, Has_Gantt_Chart, Tools, Delay_Estimate_Days, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 3, 55, 2, 5, 'Deployment', 'No', 'No', 'MS Project', 20, 5, 'Pending', TO_DATE('2024-04-01', 'YYYY-MM-DD'), TO_DATE('2024-09-01', 'YYYY-MM-DD'));

INSERT INTO Hybrid_PM (Hybrid_ID, PJ_ID, Team_Leader_ID, Agile_Phase_Included, Waterfall_Phase_Included, Main_Methodology, Agile_Tools, Waterfall_Tools, Methodology_Integration, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 3, 60, 'Yes', 'Yes', 'Hybrid Agile-Waterfall', 'Jira, Confluence', 'MS Project, TeamGantt', 'Phase-based integration with Agile sprints inside Waterfall phases', 5, 'Active', TO_DATE('2024-01-05', 'YYYY-MM-DD'), TO_DATE('2024-06-30', 'YYYY-MM-DD'));
INSERT INTO Hybrid_PM (Hybrid_ID, PJ_ID, Team_Leader_ID, Agile_Phase_Included, Waterfall_Phase_Included, Main_Methodology, Agile_Tools, Waterfall_Tools, Methodology_Integration, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 3, 60, 'Yes', 'No', 'Hybrid Agile', 'Trello', NULL, 'Scrum ceremonies with waterfall documentation', 5, 'Pending', TO_DATE('2024-02-01', 'YYYY-MM-DD'), TO_DATE('2024-07-01', 'YYYY-MM-DD'));
INSERT INTO Hybrid_PM (Hybrid_ID, PJ_ID, Team_Leader_ID, Agile_Phase_Included, Waterfall_Phase_Included, Main_Methodology, Agile_Tools, Waterfall_Tools, Methodology_Integration, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 3, 60, 'No', 'Yes', 'Hybrid Waterfall', NULL, 'Smartsheet, Wrike', 'Waterfall with Agile-inspired retrospectives', 5, 'Active', TO_DATE('2024-03-10', 'YYYY-MM-DD'), TO_DATE('2024-08-10', 'YYYY-MM-DD'));
INSERT INTO Hybrid_PM (Hybrid_ID, PJ_ID, Team_Leader_ID, Agile_Phase_Included, Waterfall_Phase_Included, Main_Methodology, Agile_Tools, Waterfall_Tools, Methodology_Integration, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 3, 60, 'Yes', 'Yes', 'Tailored Hybrid', 'Azure DevOps', 'MS Project', 'Customized phases combining both methods', 5, 'Inactive', TO_DATE('2024-01-20', 'YYYY-MM-DD'), TO_DATE('2024-05-20', 'YYYY-MM-DD'));
INSERT INTO Hybrid_PM (Hybrid_ID, PJ_ID, Team_Leader_ID, Agile_Phase_Included, Waterfall_Phase_Included, Main_Methodology, Agile_Tools, Waterfall_Tools, Methodology_Integration, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 3, 60, 'Yes', 'No', 'Hybrid Agile Focused', 'VersionOne', NULL, 'Agile sprints with waterfall governance', 5, 'Pending', TO_DATE('2024-04-01', 'YYYY-MM-DD'), TO_DATE('2024-09-01', 'YYYY-MM-DD'));

INSERT INTO Program_Management (Program_ID, PJ_ID, Team_Leader_ID, Program_Name, Manager_ID, Total_Projects, Active_Projects, Budget, Program_Objective, Key_Risks, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 3, 65, 'Enterprise Resource Management', 175, 8, 5, 1500000.00, 'Optimize resource allocation and reduce costs', 'Yes', 5, 'Active', TO_DATE('2024-01-01', 'YYYY-MM-DD'), TO_DATE('2024-12-31', 'YYYY-MM-DD'));
INSERT INTO Program_Management (Program_ID, PJ_ID, Team_Leader_ID, Program_Name, Manager_ID, Total_Projects, Active_Projects, Budget, Program_Objective, Key_Risks, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 3, 65, 'Customer Experience Enhancement', 176, 6, 4, 1200000.00, 'Improve UX/UI across all platforms', 'No', 5, 'Pending', TO_DATE('2024-02-01', 'YYYY-MM-DD'), TO_DATE('2024-11-30', 'YYYY-MM-DD'));
INSERT INTO Program_Management (Program_ID, PJ_ID, Team_Leader_ID, Program_Name, Manager_ID, Total_Projects, Active_Projects, Budget, Program_Objective, Key_Risks, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 3, 65, 'Security Upgrade Initiative', 177, 5, 3, 900000.00, 'Enhance security protocols and compliance', 'Yes', 5, 'Active', TO_DATE('2024-03-01', 'YYYY-MM-DD'), TO_DATE('2024-10-15', 'YYYY-MM-DD'));
INSERT INTO Program_Management (Program_ID, PJ_ID, Team_Leader_ID, Program_Name, Manager_ID, Total_Projects, Active_Projects, Budget, Program_Objective, Key_Risks, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 3, 65, 'Mobile Platform Expansion', 178, 7, 5, 1300000.00, 'Expand mobile app capabilities and user base', 'No', 5, 'Inactive', TO_DATE('2024-01-15', 'YYYY-MM-DD'), TO_DATE('2024-09-30', 'YYYY-MM-DD'));
INSERT INTO Program_Management (Program_ID, PJ_ID, Team_Leader_ID, Program_Name, Manager_ID, Total_Projects, Active_Projects, Budget, Program_Objective, Key_Risks, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 3, 65, 'DevOps Process Improvement', 179, 4, 2, 750000.00, 'Streamline deployment pipelines and automation', 'Yes', 5, 'Pending', TO_DATE('2024-04-01', 'YYYY-MM-DD'), TO_DATE('2024-12-01', 'YYYY-MM-DD'));

INSERT INTO Project_Coordination (Coordination_ID, PJ_ID, Team_Leader_ID, Manager_ID, Training_Programs, Standardized_Templates, KPI_Monitoring, Admin_Tools, Audit_Allowed, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 3, 70, 175, 'Yes', 10, 'Yes', 'Jira, Confluence', 'Yes', 5, 'Active', TO_DATE('2024-01-05', 'YYYY-MM-DD'), TO_DATE('2024-06-30', 'YYYY-MM-DD'));
INSERT INTO Project_Coordination (Coordination_ID, PJ_ID, Team_Leader_ID, Manager_ID, Training_Programs, Standardized_Templates, KPI_Monitoring, Admin_Tools, Audit_Allowed, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 3, 70, 176, 'No', 8, 'No', 'Trello, Slack', 'No', 5, 'Pending', TO_DATE('2024-02-10', 'YYYY-MM-DD'), TO_DATE('2024-07-15', 'YYYY-MM-DD'));
INSERT INTO Project_Coordination (Coordination_ID, PJ_ID, Team_Leader_ID, Manager_ID, Training_Programs, Standardized_Templates, KPI_Monitoring, Admin_Tools, Audit_Allowed, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 3, 70, 177, 'Yes', 12, 'Yes', 'MS Project, Teams', 'Yes', 5, 'Active', TO_DATE('2024-03-01', 'YYYY-MM-DD'), TO_DATE('2024-08-30', 'YYYY-MM-DD'));
INSERT INTO Project_Coordination (Coordination_ID, PJ_ID, Team_Leader_ID, Manager_ID, Training_Programs, Standardized_Templates, KPI_Monitoring, Admin_Tools, Audit_Allowed, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 3, 70, 178, 'No', 7, 'Yes', 'Asana, Zoom', 'No', 5, 'Inactive', TO_DATE('2024-01-20', 'YYYY-MM-DD'), TO_DATE('2024-05-30', 'YYYY-MM-DD'));
INSERT INTO Project_Coordination (Coordination_ID, PJ_ID, Team_Leader_ID, Manager_ID, Training_Programs, Standardized_Templates, KPI_Monitoring, Admin_Tools, Audit_Allowed, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 3, 70, 179, 'Yes', 9, 'No', 'ClickUp, Google Workspace', 'Yes', 5, 'Pending', TO_DATE('2024-04-10', 'YYYY-MM-DD'), TO_DATE('2024-09-10', 'YYYY-MM-DD'));

INSERT INTO IT_Support (Helpdesk_ID, Description, Team_Leader_ID, Purpose, Work_Hours, Location, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 'Suport tehnic pentru departamentul financiar', 71, 'Helpdesk', '09:00-18:00', 'On-Site', 5, 'Active', TO_DATE('2024-01-15', 'YYYY-MM-DD'), TO_DATE('2024-12-31', 'YYYY-MM-DD'));

INSERT INTO L1_Support (L1_ID, Helpdesk_ID, Team_Leader_ID, Daily_Tickets, Response_Time, Common_Issues, Tickets_Escalated_L2, Tools, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 4, 72, 50, 15, 'Parole uitate, Probleme retea', 5, 'Zendesk, Freshdesk', 5, 'Active', TO_DATE('2024-01-10', 'YYYY-MM-DD'), TO_DATE('2024-06-30', 'YYYY-MM-DD'));
INSERT INTO L1_Support (L1_ID, Helpdesk_ID, Team_Leader_ID, Daily_Tickets, Response_Time, Common_Issues, Tickets_Escalated_L2, Tools, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 4, 72, 40, 20, 'Configurari software, Instalari', 7, 'Jira Service Desk', 5, 'Pending', TO_DATE('2024-02-15', 'YYYY-MM-DD'), TO_DATE('2024-07-15', 'YYYY-MM-DD'));
INSERT INTO L1_Support (L1_ID, Helpdesk_ID, Team_Leader_ID, Daily_Tickets, Response_Time, Common_Issues, Tickets_Escalated_L2, Tools, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 4, 72, 60, 10, 'Probleme hardware, Resetare PC', 8, 'ServiceNow', 5, 'Active', TO_DATE('2024-03-01', 'YYYY-MM-DD'), TO_DATE('2024-08-01', 'YYYY-MM-DD'));
INSERT INTO L1_Support (L1_ID, Helpdesk_ID, Team_Leader_ID, Daily_Tickets, Response_Time, Common_Issues, Tickets_Escalated_L2, Tools, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 4, 72, 30, 25, 'Actualizari software, Backup', 4, 'ManageEngine', 5, 'Inactive', TO_DATE('2023-12-15', 'YYYY-MM-DD'), TO_DATE('2024-05-15', 'YYYY-MM-DD'));
INSERT INTO L1_Support (L1_ID, Helpdesk_ID, Team_Leader_ID, Daily_Tickets, Response_Time, Common_Issues, Tickets_Escalated_L2, Tools, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 4, 72, 45, 18, 'Email configurari, VPN', 6, 'BMC Remedy', 5, 'Active', TO_DATE('2024-01-20', 'YYYY-MM-DD'), TO_DATE('2024-07-20', 'YYYY-MM-DD'));

INSERT INTO L2_Support (L2_ID, Helpdesk_ID, Team_Leader_ID, Domains, Resolution_Time, Ticket_Destination, Incidents_Handled, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 4, 77, 'Network, Security', 48, 'Network Team', 'Firewall, VPN issues', 5, 'Active', TO_DATE('2024-01-05', 'YYYY-MM-DD'), TO_DATE('2024-06-30', 'YYYY-MM-DD'));
INSERT INTO L2_Support (L2_ID, Helpdesk_ID, Team_Leader_ID, Domains, Resolution_Time, Ticket_Destination, Incidents_Handled, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 4, 77, 'Software, OS', 72, 'Software Dev Team', 'OS crashes, Software bugs', 5, 'Pending', TO_DATE('2024-02-10', 'YYYY-MM-DD'), TO_DATE('2024-07-10', 'YYYY-MM-DD'));
INSERT INTO L2_Support (L2_ID, Helpdesk_ID, Team_Leader_ID, Domains, Resolution_Time, Ticket_Destination, Incidents_Handled, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 4, 77, 'Hardware, Devices', 36, 'Hardware Team', 'Hardware faults, Device replacements', 5, 'Active', TO_DATE('2024-03-01', 'YYYY-MM-DD'), TO_DATE('2024-08-01', 'YYYY-MM-DD'));
INSERT INTO L2_Support (L2_ID, Helpdesk_ID, Team_Leader_ID, Domains, Resolution_Time, Ticket_Destination, Incidents_Handled, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 4, 77, 'Database, Backup', 60, 'DB Admin Team', 'Data recovery, Backup failures', 5, 'Inactive', TO_DATE('2023-12-15', 'YYYY-MM-DD'), TO_DATE('2024-05-15', 'YYYY-MM-DD'));
INSERT INTO L2_Support (L2_ID, Helpdesk_ID, Team_Leader_ID, Domains, Resolution_Time, Ticket_Destination, Incidents_Handled, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 4, 77, 'Email, VPN', 24, 'Network Team', 'Email issues, VPN connection', 5, 'Active', TO_DATE('2024-01-20', 'YYYY-MM-DD'), TO_DATE('2024-07-20', 'YYYY-MM-DD'));

INSERT INTO L3_Support (L3_ID, Helpdesk_ID, Team_Leader_ID, Domains, Managed_Systems, Bug_Fixing, Vendor_Interaction, L2_Escalation_Rate, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 4, 82, 'Network, Security', 'Firewalls, VPN', 'Yes', 'Yes', 15, 5, 'Active', TO_DATE('2024-01-10', 'YYYY-MM-DD'), TO_DATE('2024-06-30', 'YYYY-MM-DD'));
INSERT INTO L3_Support (L3_ID, Helpdesk_ID, Team_Leader_ID, Domains, Managed_Systems, Bug_Fixing, Vendor_Interaction, L2_Escalation_Rate, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 4, 82, 'Software, OS', 'Windows, Linux', 'Yes', 'No', 10, 5, 'Pending', TO_DATE('2024-02-01', 'YYYY-MM-DD'), TO_DATE('2024-07-01', 'YYYY-MM-DD'));
INSERT INTO L3_Support (L3_ID, Helpdesk_ID, Team_Leader_ID, Domains, Managed_Systems, Bug_Fixing, Vendor_Interaction, L2_Escalation_Rate, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 4, 82, 'Hardware, Devices', 'Printers, Laptops', 'No', 'Yes', 12, 5, 'Active', TO_DATE('2024-03-05', 'YYYY-MM-DD'), TO_DATE('2024-08-05', 'YYYY-MM-DD'));
INSERT INTO L3_Support (L3_ID, Helpdesk_ID, Team_Leader_ID, Domains, Managed_Systems, Bug_Fixing, Vendor_Interaction, L2_Escalation_Rate, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 4, 82, 'Database, Backup', 'Oracle, SQL Server', 'Yes', 'Yes', 8, 5, 'Inactive', TO_DATE('2023-12-15', 'YYYY-MM-DD'), TO_DATE('2024-05-15', 'YYYY-MM-DD'));
INSERT INTO L3_Support (L3_ID, Helpdesk_ID, Team_Leader_ID, Domains, Managed_Systems, Bug_Fixing, Vendor_Interaction, L2_Escalation_Rate, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 4, 82, 'Email, VPN', 'Exchange, Cisco VPN', 'No', 'No', 14, 5, 'Active', TO_DATE('2024-01-20', 'YYYY-MM-DD'), TO_DATE('2024-07-20', 'YYYY-MM-DD'));

INSERT INTO Incident_Management (Incident_ID, Helpdesk_ID, Team_Leader_ID, Incidents_Handled, SLA_Compliance, Critical_Incidents, Escalation_Policy, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 4, 87, 'Network outages, Hardware failures', 95, 5, 'Immediate escalation to L3 support', 5, 'Active', TO_DATE('2024-01-10', 'YYYY-MM-DD'), TO_DATE('2024-06-30', 'YYYY-MM-DD'));
INSERT INTO Incident_Management (Incident_ID, Helpdesk_ID, Team_Leader_ID, Incidents_Handled, SLA_Compliance, Critical_Incidents, Escalation_Policy, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 4, 87, 'Software bugs, User access issues', 90, 3, 'Notify team leader within 2 hours', 5, 'Pending', TO_DATE('2024-02-15', 'YYYY-MM-DD'), TO_DATE('2024-07-15', 'YYYY-MM-DD'));
INSERT INTO Incident_Management (Incident_ID, Helpdesk_ID, Team_Leader_ID, Incidents_Handled, SLA_Compliance, Critical_Incidents, Escalation_Policy, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 4, 87, 'Database errors, Backup failures', 85, 7, 'Escalate to DBA and L3 team', 5, 'Active', TO_DATE('2024-03-01', 'YYYY-MM-DD'), TO_DATE('2024-08-01', 'YYYY-MM-DD'));
INSERT INTO Incident_Management (Incident_ID, Helpdesk_ID, Team_Leader_ID, Incidents_Handled, SLA_Compliance, Critical_Incidents, Escalation_Policy, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 4, 87, 'Email downtime, VPN issues', 92, 2, 'Immediate vendor notification', 5, 'Inactive', TO_DATE('2023-12-10', 'YYYY-MM-DD'), TO_DATE('2024-05-10', 'YYYY-MM-DD'));
INSERT INTO Incident_Management (Incident_ID, Helpdesk_ID, Team_Leader_ID, Incidents_Handled, SLA_Compliance, Critical_Incidents, Escalation_Policy, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 4, 87, 'Security breaches, Phishing attempts', 88, 10, 'Follow security incident protocol', 5, 'Active', TO_DATE('2024-01-20', 'YYYY-MM-DD'), TO_DATE('2024-06-20', 'YYYY-MM-DD'));

INSERT INTO Service_Request_Management (Request_ID, Helpdesk_ID, Team_Leader_ID, Request_Type, Resolution_Time, Monthly_Requests, Automation_Level, Approval, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 4, 92, 'Password Reset', 30, 120, 2, 'Yes', 5, 'Active', TO_DATE('2024-01-15', 'YYYY-MM-DD'), TO_DATE('2024-06-15', 'YYYY-MM-DD'));
INSERT INTO Service_Request_Management (Request_ID, Helpdesk_ID, Team_Leader_ID, Request_Type, Resolution_Time, Monthly_Requests, Automation_Level, Approval, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 4, 92, 'Software Installation', 120, 60, 1, 'No', 5, 'Pending', TO_DATE('2024-02-01', 'YYYY-MM-DD'), TO_DATE('2024-07-01', 'YYYY-MM-DD'));
INSERT INTO Service_Request_Management (Request_ID, Helpdesk_ID, Team_Leader_ID, Request_Type, Resolution_Time, Monthly_Requests, Automation_Level, Approval, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 4, 92, 'Hardware Upgrade', 240, 20, 0, 'Yes', 5, 'Active', TO_DATE('2024-03-10', 'YYYY-MM-DD'), TO_DATE('2024-08-10', 'YYYY-MM-DD'));
INSERT INTO Service_Request_Management (Request_ID, Helpdesk_ID, Team_Leader_ID, Request_Type, Resolution_Time, Monthly_Requests, Automation_Level, Approval, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 4, 92, 'Access Request', 60, 80, 3, 'Yes', 5, 'Inactive', TO_DATE('2023-12-05', 'YYYY-MM-DD'), TO_DATE('2024-05-05', 'YYYY-MM-DD'));
INSERT INTO Service_Request_Management (Request_ID, Helpdesk_ID, Team_Leader_ID, Request_Type, Resolution_Time, Monthly_Requests, Automation_Level, Approval, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 4, 92, 'Network Setup', 180, 15, 1, 'No', 5, 'Active', TO_DATE('2024-01-25', 'YYYY-MM-DD'), TO_DATE('2024-06-25', 'YYYY-MM-DD'));

INSERT INTO IT_Asset_Management (Asset_ID, Helpdesk_ID, Team_Leader_ID, Equipment_Count, Categories, Inventory_System, Audit_Frequency, Loss_Defect_Percentage, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 4, 97, 150, 'Laptops, Desktops, Monitors', 'SAP Inventory', 'Monthly', 2, 5, 'Active', TO_DATE('2024-01-10', 'YYYY-MM-DD'), TO_DATE('2024-06-10', 'YYYY-MM-DD'));
INSERT INTO IT_Asset_Management (Asset_ID, Helpdesk_ID, Team_Leader_ID, Equipment_Count, Categories, Inventory_System, Audit_Frequency, Loss_Defect_Percentage, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 4, 97, 80, 'Printers, Scanners', 'Oracle Assets', 'Quarterly', 1, 3, 'Pending', TO_DATE('2024-02-15', 'YYYY-MM-DD'), TO_DATE('2024-07-15', 'YYYY-MM-DD'));
INSERT INTO IT_Asset_Management (Asset_ID, Helpdesk_ID, Team_Leader_ID, Equipment_Count, Categories, Inventory_System, Audit_Frequency, Loss_Defect_Percentage, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 4, 97, 200, 'Networking Equipment', 'In-House DB', 'Monthly', 3, 6, 'Active', TO_DATE('2024-03-05', 'YYYY-MM-DD'), TO_DATE('2024-08-05', 'YYYY-MM-DD'));
INSERT INTO IT_Asset_Management (Asset_ID, Helpdesk_ID, Team_Leader_ID, Equipment_Count, Categories, Inventory_System, Audit_Frequency, Loss_Defect_Percentage, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 4, 97, 50, 'Mobile Devices', 'SAP Inventory', 'Monthly', 0, 4, 'Inactive', TO_DATE('2023-12-01', 'YYYY-MM-DD'), TO_DATE('2024-05-01', 'YYYY-MM-DD'));
INSERT INTO IT_Asset_Management (Asset_ID, Helpdesk_ID, Team_Leader_ID, Equipment_Count, Categories, Inventory_System, Audit_Frequency, Loss_Defect_Percentage, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 4, 97, 120, 'Servers, Storage', 'Oracle Assets', 'Yearly', 1, 5, 'Active', TO_DATE('2024-01-20', 'YYYY-MM-DD'), TO_DATE('2024-06-20', 'YYYY-MM-DD'));

INSERT INTO Infrastructure (Infrastructure_ID, Description, Team_Leader_ID, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 'Modernizare infrastructură rețea în sediul central', 98, 5, 'Active', TO_DATE('2024-03-01', 'YYYY-MM-DD'), TO_DATE('2024-08-15', 'YYYY-MM-DD'));

INSERT INTO System_Administration (Administration_ID, Infrastructure_ID, Team_Leader_ID, Operating_Systems, Server_Count, Tools, Monthly_Issues_Resolved, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 5, 99, 'Windows Server, Linux', 25, 'Ansible, Nagios', 120, 5, 'Active', TO_DATE('2024-01-15', 'YYYY-MM-DD'), TO_DATE('2024-06-30', 'YYYY-MM-DD'));
INSERT INTO System_Administration (Administration_ID, Infrastructure_ID, Team_Leader_ID, Operating_Systems, Server_Count, Tools, Monthly_Issues_Resolved, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 5, 99, 'Red Hat, Ubuntu', 18, 'Zabbix, Puppet', 90, 5, 'Pending', TO_DATE('2024-02-01', 'YYYY-MM-DD'), TO_DATE('2024-07-15', 'YYYY-MM-DD'));
INSERT INTO System_Administration (Administration_ID, Infrastructure_ID, Team_Leader_ID, Operating_Systems, Server_Count, Tools, Monthly_Issues_Resolved, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 5, 99, 'Debian, CentOS', 30, 'Chef, Prometheus', 150, 5, 'Active', TO_DATE('2024-03-01', 'YYYY-MM-DD'), TO_DATE('2024-08-31', 'YYYY-MM-DD'));
INSERT INTO System_Administration (Administration_ID, Infrastructure_ID, Team_Leader_ID, Operating_Systems, Server_Count, Tools, Monthly_Issues_Resolved, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 5, 99, 'SUSE, Windows Server', 22, 'SolarWinds, Splunk', 100, 5, 'Inactive', TO_DATE('2024-01-20', 'YYYY-MM-DD'), TO_DATE('2024-05-30', 'YYYY-MM-DD'));
INSERT INTO System_Administration (Administration_ID, Infrastructure_ID, Team_Leader_ID, Operating_Systems, Server_Count, Tools, Monthly_Issues_Resolved, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 5, 99, 'Oracle Linux, Fedora', 16, 'ManageEngine, Cacti', 80, 5, 'Active', TO_DATE('2024-04-10', 'YYYY-MM-DD'), TO_DATE('2024-09-20', 'YYYY-MM-DD'));

INSERT INTO Network_Engineering (Network_ID, Infrastructure_ID, Team_Leader_ID, Network_Devices, Topology, Monitoring_Tools, Active_VPN_Connections, Bandwidth_Usage, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 5, 104, 'Cisco Routers, HP Switches', 'Star', 'PRTG, NetFlow Analyzer', 120, 500.75, 5, 'Active', TO_DATE('2024-01-10', 'YYYY-MM-DD'), TO_DATE('2024-06-15', 'YYYY-MM-DD'));
INSERT INTO Network_Engineering (Network_ID, Infrastructure_ID, Team_Leader_ID, Network_Devices, Topology, Monitoring_Tools, Active_VPN_Connections, Bandwidth_Usage, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 5, 104, 'Juniper Switches, Dell Firewalls', 'Mesh', 'Zabbix, Wireshark', 85, 300.40, 5, 'Pending', TO_DATE('2024-02-01', 'YYYY-MM-DD'), TO_DATE('2024-07-20', 'YYYY-MM-DD'));
INSERT INTO Network_Engineering (Network_ID, Infrastructure_ID, Team_Leader_ID, Network_Devices, Topology, Monitoring_Tools, Active_VPN_Connections, Bandwidth_Usage, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 5, 104, 'Ubiquiti APs, MikroTik Routers', 'Ring', 'Nagios, Cacti', 60, 280.00, 5, 'Active', TO_DATE('2024-03-05', 'YYYY-MM-DD'), TO_DATE('2024-09-01', 'YYYY-MM-DD'));
INSERT INTO Network_Engineering (Network_ID, Infrastructure_ID, Team_Leader_ID, Network_Devices, Topology, Monitoring_Tools, Active_VPN_Connections, Bandwidth_Usage, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 5, 104, 'Fortinet Firewalls, Cisco Switches', 'Hybrid', 'SolarWinds, NetCrunch', 100, 450.20, 5, 'Inactive', TO_DATE('2024-01-25', 'YYYY-MM-DD'), TO_DATE('2024-08-30', 'YYYY-MM-DD'));
INSERT INTO Network_Engineering (Network_ID, Infrastructure_ID, Team_Leader_ID, Network_Devices, Topology, Monitoring_Tools, Active_VPN_Connections, Bandwidth_Usage, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 5, 104, 'Aruba Switches, Palo Alto Firewalls', 'Bus', 'LogicMonitor, OpManager', 70, 320.90, 5, 'Active', TO_DATE('2024-04-01', 'YYYY-MM-DD'), TO_DATE('2024-10-15', 'YYYY-MM-DD'));

INSERT INTO Cloud_Infrastructure (Cloud_ID, Infrastructure_ID, Team_Leader_ID, Cloud_Providers, IAAS_Resources, Container_Technologies, IaC_Tools, Monthly_Cloud_Spend, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 5, 109, 'AWS, Azure', 40, 'Docker, Kubernetes', 'Terraform, CloudFormation', 12500.00, 5, 'Active', TO_DATE('2024-01-10', 'YYYY-MM-DD'), TO_DATE('2024-06-30', 'YYYY-MM-DD'));
INSERT INTO Cloud_Infrastructure (Cloud_ID, Infrastructure_ID, Team_Leader_ID, Cloud_Providers, IAAS_Resources, Container_Technologies, IaC_Tools, Monthly_Cloud_Spend, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 5, 109, 'Google Cloud, AWS', 25, 'Podman, Docker', 'Pulumi, Terraform', 8900.75, 5, 'Pending', TO_DATE('2024-02-15', 'YYYY-MM-DD'), TO_DATE('2024-08-10', 'YYYY-MM-DD'));
INSERT INTO Cloud_Infrastructure (Cloud_ID, Infrastructure_ID, Team_Leader_ID, Cloud_Providers, IAAS_Resources, Container_Technologies, IaC_Tools, Monthly_Cloud_Spend, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 5, 109, 'Azure, Oracle Cloud', 30, 'LXC, Docker', 'Ansible, Terraform', 10700.50, 5, 'Inactive', TO_DATE('2024-03-01', 'YYYY-MM-DD'), TO_DATE('2024-09-01', 'YYYY-MM-DD'));
INSERT INTO Cloud_Infrastructure (Cloud_ID, Infrastructure_ID, Team_Leader_ID, Cloud_Providers, IAAS_Resources, Container_Technologies, IaC_Tools, Monthly_Cloud_Spend, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 5, 109, 'AWS', 50, 'Kubernetes', 'CloudFormation, Chef', 13200.00, 5, 'Active', TO_DATE('2024-01-20', 'YYYY-MM-DD'), TO_DATE('2024-07-25', 'YYYY-MM-DD'));
INSERT INTO Cloud_Infrastructure (Cloud_ID, Infrastructure_ID, Team_Leader_ID, Cloud_Providers, IAAS_Resources, Container_Technologies, IaC_Tools, Monthly_Cloud_Spend, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 5, 109, 'IBM Cloud, Google Cloud', 20, 'Docker', 'Terraform, Puppet', 7600.80, 5, 'Active', TO_DATE('2024-04-10', 'YYYY-MM-DD'), TO_DATE('2024-10-05', 'YYYY-MM-DD'));

INSERT INTO Virtualization_Storage (VS_ID, Infrastructure_ID, Team_Leader_ID, Virtualization_Tech, Virtual_Machines, Storage_Tech, Storage_Capacity_GB, Storage_Usage_Percent, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 5, 114, 'VMware ESXi', 35, 'NetApp', 8000, 72.5, 5, 'Active', TO_DATE('2024-01-05', 'YYYY-MM-DD'), TO_DATE('2024-06-30', 'YYYY-MM-DD'));
INSERT INTO Virtualization_Storage (VS_ID, Infrastructure_ID, Team_Leader_ID, Virtualization_Tech, Virtual_Machines, Storage_Tech, Storage_Capacity_GB, Storage_Usage_Percent, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 5, 114, 'Microsoft Hyper-V', 25, 'Dell EMC', 6000, 58.3, 5, 'Pending', TO_DATE('2024-02-10', 'YYYY-MM-DD'), TO_DATE('2024-08-20', 'YYYY-MM-DD'));
INSERT INTO Virtualization_Storage (VS_ID, Infrastructure_ID, Team_Leader_ID, Virtualization_Tech, Virtual_Machines, Storage_Tech, Storage_Capacity_GB, Storage_Usage_Percent, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 5, 114, 'KVM', 18, 'HP 3PAR', 4000, 41.7, 5, 'Inactive', TO_DATE('2024-03-01', 'YYYY-MM-DD'), TO_DATE('2024-09-15', 'YYYY-MM-DD'));
INSERT INTO Virtualization_Storage (VS_ID, Infrastructure_ID, Team_Leader_ID, Virtualization_Tech, Virtual_Machines, Storage_Tech, Storage_Capacity_GB, Storage_Usage_Percent, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 5, 114, 'Citrix XenServer', 30, 'Hitachi Vantara', 7000, 64.9, 5, 'Active', TO_DATE('2024-01-25', 'YYYY-MM-DD'), TO_DATE('2024-07-30', 'YYYY-MM-DD'));
INSERT INTO Virtualization_Storage (VS_ID, Infrastructure_ID, Team_Leader_ID, Virtualization_Tech, Virtual_Machines, Storage_Tech, Storage_Capacity_GB, Storage_Usage_Percent, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 5, 114, 'Proxmox VE', 12, 'Synology NAS', 2000, 35.0, 5, 'Pending', TO_DATE('2024-04-15', 'YYYY-MM-DD'), TO_DATE('2024-10-10', 'YYYY-MM-DD'));

INSERT INTO Data_Center_Operations (Data_Center_ID, Infrastructure_ID, Team_Leader_ID, Physical_Servers, Locations, Power_Usage_KW, Cooling_System, Security_Measures, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (1, 5, 119, 120, 'New York, USA', 350.75, 'CRAC Units', 'Biometric, CCTV', 5, 'Active', TO_DATE('2024-01-01', 'YYYY-MM-DD'), TO_DATE('2024-12-31', 'YYYY-MM-DD'));
INSERT INTO Data_Center_Operations (Data_Center_ID, Infrastructure_ID, Team_Leader_ID, Physical_Servers, Locations, Power_Usage_KW, Cooling_System, Security_Measures, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (2, 5, 119, 80, 'Frankfurt, Germany', 220.40, 'Liquid Cooling', 'RFID Access, Guards', 5, 'Pending', TO_DATE('2024-02-01', 'YYYY-MM-DD'), TO_DATE('2024-11-30', 'YYYY-MM-DD'));
INSERT INTO Data_Center_Operations (Data_Center_ID, Infrastructure_ID, Team_Leader_ID, Physical_Servers, Locations, Power_Usage_KW, Cooling_System, Security_Measures, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (3, 5, 119, 60, 'Tokyo, Japan', 180.60, 'Chilled Water', 'Access Cards, Cameras', 5, 'Inactive', TO_DATE('2024-03-15', 'YYYY-MM-DD'), TO_DATE('2024-09-15', 'YYYY-MM-DD'));
INSERT INTO Data_Center_Operations (Data_Center_ID, Infrastructure_ID, Team_Leader_ID, Physical_Servers, Locations, Power_Usage_KW, Cooling_System, Security_Measures, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (4, 5, 119, 200, 'Dallas, USA', 500.90, 'Raised Floor Cooling', 'Biometric, Motion Sensors', 5, 'Active', TO_DATE('2024-01-20', 'YYYY-MM-DD'), TO_DATE('2024-10-20', 'YYYY-MM-DD'));
INSERT INTO Data_Center_Operations (Data_Center_ID, Infrastructure_ID, Team_Leader_ID, Physical_Servers, Locations, Power_Usage_KW, Cooling_System, Security_Measures, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (5, 5, 119, 95, 'London, UK', 275.30, 'Evaporative Cooling', 'Mantrap, Guards', 5, 'Pending', TO_DATE('2024-04-01', 'YYYY-MM-DD'), TO_DATE('2024-12-01', 'YYYY-MM-DD'));

INSERT INTO Infrastructure_Security (Infrastructure_Security_ID, Infrastructure_ID, Team_Leader_ID, Firewalls, IDS_IPS_Systems, Patch_Management, Annual_Audits, Compliance_Frameworks, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 5, 124, 5, 'Snort, Suricata', 'Automated via SCCM', 2, 'ISO 27001, NIST', 5, 'Active', TO_DATE('2024-01-10', 'YYYY-MM-DD'), TO_DATE('2024-12-31', 'YYYY-MM-DD'));
INSERT INTO Infrastructure_Security (Infrastructure_Security_ID, Infrastructure_ID, Team_Leader_ID, Firewalls, IDS_IPS_Systems, Patch_Management, Annual_Audits, Compliance_Frameworks, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 5, 124, 4, 'Zeek, OSSEC', 'Manual Quarterly', 1, 'SOC 2, PCI-DSS', 5, 'Pending', TO_DATE('2024-03-01', 'YYYY-MM-DD'), TO_DATE('2024-11-30', 'YYYY-MM-DD'));
INSERT INTO Infrastructure_Security (Infrastructure_Security_ID, Infrastructure_ID, Team_Leader_ID, Firewalls, IDS_IPS_Systems, Patch_Management, Annual_Audits, Compliance_Frameworks, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 5, 124, 6, 'Cisco Firepower, Snort', 'WSUS and Ansible', 2, 'HIPAA, ISO 27017', 5, 'Inactive', TO_DATE('2024-02-15', 'YYYY-MM-DD'), TO_DATE('2024-08-15', 'YYYY-MM-DD'));
INSERT INTO Infrastructure_Security (Infrastructure_Security_ID, Infrastructure_ID, Team_Leader_ID, Firewalls, IDS_IPS_Systems, Patch_Management, Annual_Audits, Compliance_Frameworks, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 5, 124, 3, 'Palo Alto Threat Prevention', 'Patch My PC', 3, 'ISO 27001', 5, 'Active', TO_DATE('2024-04-01', 'YYYY-MM-DD'), TO_DATE('2024-10-01', 'YYYY-MM-DD'));
INSERT INTO Infrastructure_Security (Infrastructure_Security_ID, Infrastructure_ID, Team_Leader_ID, Firewalls, IDS_IPS_Systems, Patch_Management, Annual_Audits, Compliance_Frameworks, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 5, 124, 8, 'CrowdStrike Falcon, Zeek', 'Automated Weekly', 4, 'NIST CSF, CIS', 5, 'Pending', TO_DATE('2024-05-01', 'YYYY-MM-DD'), TO_DATE('2024-12-01', 'YYYY-MM-DD'));

INSERT INTO UI_UX_Design (UI_UX_Design_ID, Description, Team_Leader_ID, Projects_Count, Toolset, Design_System, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (6, 'Refactorizare experiență utilizator pentru platforma e-commerce', 125, 5, 'Figma, Adobe XD', 'Material Design', 5, 'Active', TO_DATE('2024-02-01', 'YYYY-MM-DD'), TO_DATE('2024-07-31', 'YYYY-MM-DD'));

INSERT INTO UX_Research (UX_Research_ID, UI_UX_Design_ID, Team_Leader_ID, Research_Methods, Users_Count, Research_Tools, Documentation_Link, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 6, 126, 'Interviuri, Sondaje', 50, 'Lookback, Maze', 'https://intranet.company.com/research1', 5, 'Active', TO_DATE('2024-01-15', 'YYYY-MM-DD'), TO_DATE('2024-03-30', 'YYYY-MM-DD'));
INSERT INTO UX_Research (UX_Research_ID, UI_UX_Design_ID, Team_Leader_ID, Research_Methods, Users_Count, Research_Tools, Documentation_Link, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 6, 126, 'Teste de utilizare', 30, 'Hotjar, Optimal Workshop', 'https://intranet.company.com/research2', 5, 'Active', TO_DATE('2024-04-01', 'YYYY-MM-DD'), TO_DATE('2024-05-31', 'YYYY-MM-DD'));
INSERT INTO UX_Research (UX_Research_ID, UI_UX_Design_ID, Team_Leader_ID, Research_Methods, Users_Count, Research_Tools, Documentation_Link, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 6, 126, 'Card sorting, Interviuri', 40, 'Dovetail, Useberry', 'https://intranet.company.com/research3', 5, 'Pending', TO_DATE('2024-06-01', 'YYYY-MM-DD'), TO_DATE('2024-08-15', 'YYYY-MM-DD'));
INSERT INTO UX_Research (UX_Research_ID, UI_UX_Design_ID, Team_Leader_ID, Research_Methods, Users_Count, Research_Tools, Documentation_Link, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 6, 126, 'Analiză comportamentală', 60, 'Google Analytics, Smartlook', 'https://intranet.company.com/research4', 5, 'Inactive', TO_DATE('2024-02-10', 'YYYY-MM-DD'), TO_DATE('2024-04-10', 'YYYY-MM-DD'));
INSERT INTO UX_Research (UX_Research_ID, UI_UX_Design_ID, Team_Leader_ID, Research_Methods, Users_Count, Research_Tools, Documentation_Link, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 6, 126, 'Focus group, Interviuri', 25, 'Zoom, Miro', 'https://intranet.company.com/research5', 5, 'Active', TO_DATE('2024-03-01', 'YYYY-MM-DD'), TO_DATE('2024-06-01', 'YYYY-MM-DD'));

INSERT INTO UI_Research (UI_Research_ID, UI_UX_Design_ID, Team_Leader_ID, Design_Lead_ID, Visual_Test_Methods, Users_Count, Tools, Design_Document_Link, Results_Summary, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 6, 131, 301, 'A/B Testing', 40, 'Figma, Adobe XD', 'https://intranet.company.com/ui_research1', 'Versiunea B a avut o rată de conversie cu 15% mai mare.', 5, 'Active', TO_DATE('2024-02-01', 'YYYY-MM-DD'), TO_DATE('2024-03-01', 'YYYY-MM-DD'));
INSERT INTO UI_Research (UI_Research_ID, UI_UX_Design_ID, Team_Leader_ID, Design_Lead_ID, Visual_Test_Methods, Users_Count, Tools, Design_Document_Link, Results_Summary, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 6, 131, 302, 'Eye Tracking', 35, 'Useberry, Smartlook', 'https://intranet.company.com/ui_research2', 'Elementele CTA au fost neobservate de 20% dintre utilizatori.', 5, 'Pending', TO_DATE('2024-03-10', 'YYYY-MM-DD'), TO_DATE('2024-04-15', 'YYYY-MM-DD'));
INSERT INTO UI_Research (UI_Research_ID, UI_UX_Design_ID, Team_Leader_ID, Design_Lead_ID, Visual_Test_Methods, Users_Count, Tools, Design_Document_Link, Results_Summary, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 6, 131, 303, 'First Click Test', 50, 'Maze, Optimal Workshop', 'https://intranet.company.com/ui_research3', '75% dintre utilizatori au făcut click corect din prima.', 5, 'Active', TO_DATE('2024-04-20', 'YYYY-MM-DD'), TO_DATE('2024-05-20', 'YYYY-MM-DD'));
INSERT INTO UI_Research (UI_Research_ID, UI_UX_Design_ID, Team_Leader_ID, Design_Lead_ID, Visual_Test_Methods, Users_Count, Tools, Design_Document_Link, Results_Summary, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 6, 131, 304, 'Preference Test', 45, 'Figma, Miro', 'https://intranet.company.com/ui_research4', 'Designul minimalist a fost preferat de 68% dintre participanți.', 5, 'Inactive', TO_DATE('2024-01-15', 'YYYY-MM-DD'), TO_DATE('2024-02-15', 'YYYY-MM-DD'));
INSERT INTO UI_Research (UI_Research_ID, UI_UX_Design_ID, Team_Leader_ID, Design_Lead_ID, Visual_Test_Methods, Users_Count, Tools, Design_Document_Link, Results_Summary, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 6, 131, 305, 'Tree Testing', 30, 'UXtweak, Treejack', 'https://intranet.company.com/ui_research5', 'Structura informațională a fost considerată intuitivă.', 5, 'Active', TO_DATE('2024-05-01', 'YYYY-MM-DD'), TO_DATE('2024-06-01', 'YYYY-MM-DD'));

INSERT INTO Interaction_Design (Interaction_Design_ID, UI_UX_Design_ID, Team_Leader_ID, Design_Lead_ID, Components_Designed, Tools, Interaction_Patterns, User_Flow, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 6, 136, 301, 'Formulare, Modale', 'Figma, ProtoPie', 'Feedback instant, validări inline', 'Înregistrare utilizator', 5, 'Active', TO_DATE('2024-02-10', 'YYYY-MM-DD'), TO_DATE('2024-03-05', 'YYYY-MM-DD'));
INSERT INTO Interaction_Design (Interaction_Design_ID, UI_UX_Design_ID, Team_Leader_ID, Design_Lead_ID, Components_Designed, Tools, Interaction_Patterns, User_Flow, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 6, 136, 302, 'Carduri, Acordeon', 'Adobe XD, InVision', 'Navigare pe taburi, animații de trecere', 'Căutare produse', 5, 'Pending', TO_DATE('2024-03-15', 'YYYY-MM-DD'), TO_DATE('2024-04-10', 'YYYY-MM-DD'));
INSERT INTO Interaction_Design (Interaction_Design_ID, UI_UX_Design_ID, Team_Leader_ID, Design_Lead_ID, Components_Designed, Tools, Interaction_Patterns, User_Flow, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 6, 136, 303, 'Tooltip-uri, Dropdown-uri', 'Sketch, Zeplin', 'Hover & Focus states', 'Plasare comandă', 5, 'Active', TO_DATE('2024-04-20', 'YYYY-MM-DD'), TO_DATE('2024-05-15', 'YYYY-MM-DD'));
INSERT INTO Interaction_Design (Interaction_Design_ID, UI_UX_Design_ID, Team_Leader_ID, Design_Lead_ID, Components_Designed, Tools, Interaction_Patterns, User_Flow, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 6, 136, 304, 'Slider, Switch', 'UXPin, Figma', 'Micro-interacțiuni, tranziții netede', 'Selectare preferințe', 5, 'Inactive', TO_DATE('2024-01-20', 'YYYY-MM-DD'), TO_DATE('2024-02-15', 'YYYY-MM-DD'));
INSERT INTO Interaction_Design (Interaction_Design_ID, UI_UX_Design_ID, Team_Leader_ID, Design_Lead_ID, Components_Designed, Tools, Interaction_Patterns, User_Flow, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 6, 136, 305, 'Butoane, Carusel', 'Figma, Framer', 'Click delay, tranziții dinamice', 'Prezentare produs', 5, 'Active', TO_DATE('2024-05-01', 'YYYY-MM-DD'), TO_DATE('2024-06-01', 'YYYY-MM-DD'));

INSERT INTO Prototyping (Prototyping_ID, UI_UX_Design_ID, Team_Leader_ID, Design_Lead_ID, Tool, Prototype_Type, Screen_Count, Prototype_Link, Tested_By_Users, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 6, 141, 301, 'Figma', 'High-fidelity', 15, 'https://example.com/prototype1', 'Yes', 5, 'Active', TO_DATE('2024-02-01', 'YYYY-MM-DD'), TO_DATE('2024-02-28', 'YYYY-MM-DD'));
INSERT INTO Prototyping (Prototyping_ID, UI_UX_Design_ID, Team_Leader_ID, Design_Lead_ID, Tool, Prototype_Type, Screen_Count, Prototype_Link, Tested_By_Users, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 6, 141, 302, 'Adobe XD', 'Low-fidelity', 8, 'https://example.com/prototype2', 'No', 5, 'Pending', TO_DATE('2024-03-01', 'YYYY-MM-DD'), TO_DATE('2024-03-20', 'YYYY-MM-DD'));
INSERT INTO Prototyping (Prototyping_ID, UI_UX_Design_ID, Team_Leader_ID, Design_Lead_ID, Tool, Prototype_Type, Screen_Count, Prototype_Link, Tested_By_Users, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 6, 141, 303, 'InVision', 'Clickable wireframe', 10, 'https://example.com/prototype3', 'Yes', 5, 'Active', TO_DATE('2024-04-01', 'YYYY-MM-DD'), TO_DATE('2024-04-30', 'YYYY-MM-DD'));
INSERT INTO Prototyping (Prototyping_ID, UI_UX_Design_ID, Team_Leader_ID, Design_Lead_ID, Tool, Prototype_Type, Screen_Count, Prototype_Link, Tested_By_Users, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 6, 141, 304, 'UXPin', 'Interactive', 12, 'https://example.com/prototype4', 'Yes', 5, 'Inactive', TO_DATE('2024-01-15', 'YYYY-MM-DD'), TO_DATE('2024-02-10', 'YYYY-MM-DD'));
INSERT INTO Prototyping (Prototyping_ID, UI_UX_Design_ID, Team_Leader_ID, Design_Lead_ID, Tool, Prototype_Type, Screen_Count, Prototype_Link, Tested_By_Users, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 6, 141, 305, 'Framer', 'Motion prototype', 20, 'https://example.com/prototype5', 'No', 5, 'Active', TO_DATE('2024-05-01', 'YYYY-MM-DD'), TO_DATE('2024-06-01', 'YYYY-MM-DD'));

INSERT INTO Information_Architecture (IA_ID, UI_UX_Design_ID, Team_Leader_ID, Structure_Type, Methods, Deliverables, Tool, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 6, 146, 'Hierarchical', 'Card Sorting, Tree Testing', 'Sitemap, Navigation Flow', 'Lucidchart', 5, 'Active', TO_DATE('2024-01-10', 'YYYY-MM-DD'), TO_DATE('2024-02-10', 'YYYY-MM-DD'));
INSERT INTO Information_Architecture (IA_ID, UI_UX_Design_ID, Team_Leader_ID, Structure_Type, Methods, Deliverables, Tool, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 6, 146, 'Sequential', 'User Journey Mapping', 'Flow Diagrams', 'Miro', 5, 'Pending', TO_DATE('2024-02-15', 'YYYY-MM-DD'), TO_DATE('2024-03-10', 'YYYY-MM-DD'));
INSERT INTO Information_Architecture (IA_ID, UI_UX_Design_ID, Team_Leader_ID, Structure_Type, Methods, Deliverables, Tool, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 6, 146, 'Matrix', 'Content Inventory, Card Sorting', 'Navigation Matrix', 'Figma', 5, 'Active', TO_DATE('2024-03-20', 'YYYY-MM-DD'), TO_DATE('2024-04-15', 'YYYY-MM-DD'));
INSERT INTO Information_Architecture (IA_ID, UI_UX_Design_ID, Team_Leader_ID, Structure_Type, Methods, Deliverables, Tool, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 6, 146, 'Hierarchical', 'Tree Testing', 'Content Map', 'Axure RP', 5, 'Inactive', TO_DATE('2024-01-01', 'YYYY-MM-DD'), TO_DATE('2024-01-30', 'YYYY-MM-DD'));
INSERT INTO Information_Architecture (IA_ID, UI_UX_Design_ID, Team_Leader_ID, Structure_Type, Methods, Deliverables, Tool, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 6, 146, 'Sequential', 'User Scenarios', 'IA Diagrams', 'Draw.io', 5, 'Active', TO_DATE('2024-04-20', 'YYYY-MM-DD'), TO_DATE('2024-05-20', 'YYYY-MM-DD'));

INSERT INTO Accessibility_Design (Accessibility_ID, UI_UX_Design_ID, Team_Leader_ID, Compliance_Level, Tools, Audit_Date, Issues_Found, Issues_Fixed, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 6, 151, 'WCAG 2.1 AA', 'axe, WAVE', TO_DATE('2024-01-05', 'YYYY-MM-DD'), 12, 10, 5, 'Active', TO_DATE('2024-01-01', 'YYYY-MM-DD'), TO_DATE('2024-02-01', 'YYYY-MM-DD'));
INSERT INTO Accessibility_Design (Accessibility_ID, UI_UX_Design_ID, Team_Leader_ID, Compliance_Level, Tools, Audit_Date, Issues_Found, Issues_Fixed, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 6, 151, 'WCAG 2.0 A', 'Accessibility Insights', TO_DATE('2024-02-10', 'YYYY-MM-DD'), 8, 8, 5, 'Pending', TO_DATE('2024-02-01', 'YYYY-MM-DD'), TO_DATE('2024-03-01', 'YYYY-MM-DD'));
INSERT INTO Accessibility_Design (Accessibility_ID, UI_UX_Design_ID, Team_Leader_ID, Compliance_Level, Tools, Audit_Date, Issues_Found, Issues_Fixed, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 6, 151, 'WCAG 2.1 AAA', 'axe DevTools', TO_DATE('2024-03-15', 'YYYY-MM-DD'), 15, 13, 5, 'Active', TO_DATE('2024-03-01', 'YYYY-MM-DD'), TO_DATE('2024-04-01', 'YYYY-MM-DD'));
INSERT INTO Accessibility_Design (Accessibility_ID, UI_UX_Design_ID, Team_Leader_ID, Compliance_Level, Tools, Audit_Date, Issues_Found, Issues_Fixed, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 6, 151, 'Section 508', 'WAVE, axe', TO_DATE('2024-01-25', 'YYYY-MM-DD'), 5, 5, 5, 'Inactive', TO_DATE('2024-01-01', 'YYYY-MM-DD'), TO_DATE('2024-02-01', 'YYYY-MM-DD'));
INSERT INTO Accessibility_Design (Accessibility_ID, UI_UX_Design_ID, Team_Leader_ID, Compliance_Level, Tools, Audit_Date, Issues_Found, Issues_Fixed, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 6, 151, 'WCAG 2.1 AA', 'NVDA, axe', TO_DATE('2024-04-10', 'YYYY-MM-DD'), 10, 10, 5, 'Active', TO_DATE('2024-04-01', 'YYYY-MM-DD'), TO_DATE('2024-05-01', 'YYYY-MM-DD'));

INSERT INTO Research_Development (RD_ID, Description, Team_Leader_ID, Domain, Goal, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (7, 'Exploring AI-driven UI optimization techniques', 152, 'Artificial Intelligence', 'Improve UI responsiveness using ML models', 5, 'Active', TO_DATE('2024-01-10', 'YYYY-MM-DD'), TO_DATE('2024-06-10', 'YYYY-MM-DD'));

INSERT INTO Scientific_Research (Scientific_ID, RD_ID, Team_Leader_ID, Domain, Academic_Collaborations, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 7, 153, 'Artificial Intelligence', 'MIT, Stanford University', 5, 'Active', TO_DATE('2024-01-15', 'YYYY-MM-DD'), TO_DATE('2024-12-15', 'YYYY-MM-DD'));
INSERT INTO Scientific_Research (Scientific_ID, RD_ID, Team_Leader_ID, Domain, Academic_Collaborations, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 7, 153, 'Machine Learning', 'Carnegie Mellon University', 5, 'Active', TO_DATE('2024-02-01', 'YYYY-MM-DD'), TO_DATE('2024-11-30', 'YYYY-MM-DD'));
INSERT INTO Scientific_Research (Scientific_ID, RD_ID, Team_Leader_ID, Domain, Academic_Collaborations, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 7, 153, 'Data Science', 'University of California, Berkeley', 5, 'Pending', TO_DATE('2024-03-05', 'YYYY-MM-DD'), NULL);
INSERT INTO Scientific_Research (Scientific_ID, RD_ID, Team_Leader_ID, Domain, Academic_Collaborations, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 7, 153, 'Cybersecurity', 'Oxford University', 5, 'Inactive', TO_DATE('2023-10-10', 'YYYY-MM-DD'), TO_DATE('2024-04-10', 'YYYY-MM-DD'));
INSERT INTO Scientific_Research (Scientific_ID, RD_ID, Team_Leader_ID, Domain, Academic_Collaborations, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 7, 153, 'Quantum Computing', 'Harvard University', 5, 'Active', TO_DATE('2024-05-20', 'YYYY-MM-DD'), TO_DATE('2025-05-20', 'YYYY-MM-DD'));

INSERT INTO Technological_Innovation (Technological_ID, RD_ID, Team_Leader_ID, Innovation_Area, Patent_Pending, Partner_Companies, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 7, 158, 'AI-driven Automation', 'Yes', 'Google, IBM', 5, 'Active', TO_DATE('2024-01-10', 'YYYY-MM-DD'), TO_DATE('2024-12-10', 'YYYY-MM-DD'));
INSERT INTO Technological_Innovation (Technological_ID, RD_ID, Team_Leader_ID, Innovation_Area, Patent_Pending, Partner_Companies, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 7, 158, 'Advanced Robotics', 'No', 'Boston Dynamics', 5, 'Active', TO_DATE('2024-02-15', 'YYYY-MM-DD'), NULL);
INSERT INTO Technological_Innovation (Technological_ID, RD_ID, Team_Leader_ID, Innovation_Area, Patent_Pending, Partner_Companies, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 7, 158, 'Blockchain Applications', 'Yes', 'Ethereum Foundation', 5, 'Pending', TO_DATE('2024-03-01', 'YYYY-MM-DD'), TO_DATE('2025-03-01', 'YYYY-MM-DD'));
INSERT INTO Technological_Innovation (Technological_ID, RD_ID, Team_Leader_ID, Innovation_Area, Patent_Pending, Partner_Companies, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 7, 158, 'Quantum Computing', 'No', 'IBM Q', 5, 'Active', TO_DATE('2024-04-20', 'YYYY-MM-DD'), TO_DATE('2025-04-20', 'YYYY-MM-DD'));
INSERT INTO Technological_Innovation (Technological_ID, RD_ID, Team_Leader_ID, Innovation_Area, Patent_Pending, Partner_Companies, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 7, 158, '5G Network Solutions', 'Yes', 'Ericsson, Nokia', 5, 'Inactive', TO_DATE('2023-12-01', 'YYYY-MM-DD'), TO_DATE('2024-11-30', 'YYYY-MM-DD'));

INSERT INTO Hardware_Development (Hardware_ID, RD_ID, Team_Leader_ID, Prototype_Name, Hardware_Type, Is_3D_Printed, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 7, 163, 'ProtoX', 'Wearable Device', 'Yes', 5, 'Active', TO_DATE('2024-01-05', 'YYYY-MM-DD'), TO_DATE('2024-10-05', 'YYYY-MM-DD'));
INSERT INTO Hardware_Development (Hardware_ID, RD_ID, Team_Leader_ID, Prototype_Name, Hardware_Type, Is_3D_Printed, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 7, 163, 'NanoChip', 'Microprocessor', 'No', 5, 'Active', TO_DATE('2024-02-10', 'YYYY-MM-DD'), NULL);
INSERT INTO Hardware_Development (Hardware_ID, RD_ID, Team_Leader_ID, Prototype_Name, Hardware_Type, Is_3D_Printed, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 7, 163, 'RoboArm', 'Robotic Limb', 'Yes', 5, 'Pending', TO_DATE('2024-03-20', 'YYYY-MM-DD'), TO_DATE('2025-03-20', 'YYYY-MM-DD'));
INSERT INTO Hardware_Development (Hardware_ID, RD_ID, Team_Leader_ID, Prototype_Name, Hardware_Type, Is_3D_Printed, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 7, 163, 'EcoSensor', 'Environmental Sensor', 'No', 5, 'Active', TO_DATE('2024-04-15', 'YYYY-MM-DD'), TO_DATE('2025-04-15', 'YYYY-MM-DD'));
INSERT INTO Hardware_Development (Hardware_ID, RD_ID, Team_Leader_ID, Prototype_Name, Hardware_Type, Is_3D_Printed, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 7, 163, 'SmartLens', 'Optical Device', 'Yes', 5, 'Inactive', TO_DATE('2023-11-01', 'YYYY-MM-DD'), TO_DATE('2024-10-31', 'YYYY-MM-DD'));

INSERT INTO Market_Research (Market_ID, RD_ID, Team_Leader_ID, Target_Market, Research_Methods, Competition_Analysis, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 7, 168, 'Consumer Electronics', 'Surveys', 'Yes', 5, 'Active', TO_DATE('2024-01-10', 'YYYY-MM-DD'), TO_DATE('2024-06-10', 'YYYY-MM-DD'));
INSERT INTO Market_Research (Market_ID, RD_ID, Team_Leader_ID, Target_Market, Research_Methods, Competition_Analysis, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 7, 168, 'Healthcare', 'Focus Groups', 'No', 5, 'Pending', TO_DATE('2024-02-15', 'YYYY-MM-DD'), NULL);
INSERT INTO Market_Research (Market_ID, RD_ID, Team_Leader_ID, Target_Market, Research_Methods, Competition_Analysis, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 7, 168, 'Automotive', 'Interviews', 'Yes', 5, 'Active', TO_DATE('2024-03-20', 'YYYY-MM-DD'), TO_DATE('2024-09-20', 'YYYY-MM-DD'));
INSERT INTO Market_Research (Market_ID, RD_ID, Team_Leader_ID, Target_Market, Research_Methods, Competition_Analysis, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 7, 168, 'Financial Services', 'Data Analytics', 'No', 5, 'Inactive', TO_DATE('2024-04-25', 'YYYY-MM-DD'), TO_DATE('2025-04-25', 'YYYY-MM-DD'));
INSERT INTO Market_Research (Market_ID, RD_ID, Team_Leader_ID, Target_Market, Research_Methods, Competition_Analysis, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 7, 168, 'Retail', 'Observations', 'Yes', 5, 'Active', TO_DATE('2023-12-05', 'YYYY-MM-DD'), TO_DATE('2024-05-05', 'YYYY-MM-DD'));

INSERT INTO Experimental_Projects (Experimental_ID, RD_ID, Team_Leader_ID, Project_Name, Experiment_Type, Risk_Level, Funding, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 7, 173, 'AI Optimization', 'Algorithm Testing', 'High', 'Yes', 5, 'Active', TO_DATE('2024-01-15', 'YYYY-MM-DD'), TO_DATE('2024-12-15', 'YYYY-MM-DD'));
INSERT INTO Experimental_Projects (Experimental_ID, RD_ID, Team_Leader_ID, Project_Name, Experiment_Type, Risk_Level, Funding, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 7, 173, 'Biomaterial Synthesis', 'Chemical Analysis', 'Medium', 'No', 5, 'Pending', TO_DATE('2024-02-20', 'YYYY-MM-DD'), NULL);
INSERT INTO Experimental_Projects (Experimental_ID, RD_ID, Team_Leader_ID, Project_Name, Experiment_Type, Risk_Level, Funding, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 7, 173, 'Quantum Computing', 'Prototype Development', 'High', 'Yes', 5, 'Active', TO_DATE('2024-03-25', 'YYYY-MM-DD'), TO_DATE('2025-03-25', 'YYYY-MM-DD'));
INSERT INTO Experimental_Projects (Experimental_ID, RD_ID, Team_Leader_ID, Project_Name, Experiment_Type, Risk_Level, Funding, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 7, 173, 'Eco-friendly Packaging', 'Material Testing', 'Low', 'Yes', 5, 'Inactive', TO_DATE('2024-04-30', 'YYYY-MM-DD'), TO_DATE('2024-10-30', 'YYYY-MM-DD'));
INSERT INTO Experimental_Projects (Experimental_ID, RD_ID, Team_Leader_ID, Project_Name, Experiment_Type, Risk_Level, Funding, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 7, 173, 'Nanotech Sensors', 'Field Trials', 'Medium', 'No', 5, 'Active', TO_DATE('2023-12-10', 'YYYY-MM-DD'), TO_DATE('2024-06-10', 'YYYY-MM-DD'));

INSERT INTO Testing_Validation (Testing_ID, RD_ID, Team_Leader_ID, Prototype, Test_Type, Validated, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 7, 178, 'AI Optimizer v1', 'Functional', 'Yes', 5, 'Active', TO_DATE('2024-01-10', 'YYYY-MM-DD'), TO_DATE('2024-02-15', 'YYYY-MM-DD'));
INSERT INTO Testing_Validation (Testing_ID, RD_ID, Team_Leader_ID, Prototype, Test_Type, Validated, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 7, 178, 'BioMaterial Sample A', 'Durability', 'No', 5, 'Pending', TO_DATE('2024-03-05', 'YYYY-MM-DD'), NULL);
INSERT INTO Testing_Validation (Testing_ID, RD_ID, Team_Leader_ID, Prototype, Test_Type, Validated, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 7, 178, 'Quantum Chip Prototype', 'Stress', 'Yes', 5, 'Active', TO_DATE('2024-02-20', 'YYYY-MM-DD'), TO_DATE('2024-04-20', 'YYYY-MM-DD'));
INSERT INTO Testing_Validation (Testing_ID, RD_ID, Team_Leader_ID, Prototype, Test_Type, Validated, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 7, 178, 'EcoPack v2', 'Environmental', 'No', 5, 'Inactive', TO_DATE('2023-11-15', 'YYYY-MM-DD'), TO_DATE('2024-01-15', 'YYYY-MM-DD'));
INSERT INTO Testing_Validation (Testing_ID, RD_ID, Team_Leader_ID, Prototype, Test_Type, Validated, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 7, 178, 'Nano Sensor Alpha', 'Field', 'Yes', 5, 'Active', TO_DATE('2024-04-01', 'YYYY-MM-DD'), NULL);

INSERT INTO Product_Management (Product_ID, Description, Team_Leader_ID, Area, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (8, 'New mobile app development', 179, 'Mobile Applications', 5, 'Active', TO_DATE('2024-05-01', 'YYYY-MM-DD'), TO_DATE('2024-12-31', 'YYYY-MM-DD'));

INSERT INTO Product_Strategy_Planning (PSP_ID, Product_ID, Team_Leader_ID, Strategy, Market_Analysis, Roadmap_Goals, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 8, 180, 'Expand user base', 'High demand in mobile sector', 'Launch new features Q4', 5, 'Active', TO_DATE('2024-06-01', 'YYYY-MM-DD'), TO_DATE('2024-12-31', 'YYYY-MM-DD'));
INSERT INTO Product_Strategy_Planning (PSP_ID, Product_ID, Team_Leader_ID, Strategy, Market_Analysis, Roadmap_Goals, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 8, 180, 'Improve UX/UI', 'User feedback highlights ease of use issues', 'Redesign interface by Q3', 5, 'Pending', TO_DATE('2024-04-15', 'YYYY-MM-DD'), TO_DATE('2024-09-30', 'YYYY-MM-DD'));
INSERT INTO Product_Strategy_Planning (PSP_ID, Product_ID, Team_Leader_ID, Strategy, Market_Analysis, Roadmap_Goals, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 8, 180, 'Increase market share', 'Competitors releasing similar products', 'Aggressive marketing campaign', 5, 'Active', TO_DATE('2024-03-01', 'YYYY-MM-DD'), TO_DATE('2024-11-30', 'YYYY-MM-DD'));
INSERT INTO Product_Strategy_Planning (PSP_ID, Product_ID, Team_Leader_ID, Strategy, Market_Analysis, Roadmap_Goals, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 8, 180, 'Optimize performance', 'Customers report slow response times', 'Improve backend infrastructure', 5, 'Inactive', TO_DATE('2024-01-15', 'YYYY-MM-DD'), TO_DATE('2024-08-31', 'YYYY-MM-DD'));
INSERT INTO Product_Strategy_Planning (PSP_ID, Product_ID, Team_Leader_ID, Strategy, Market_Analysis, Roadmap_Goals, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 8, 180, 'Expand to new markets', 'Emerging markets show potential growth', 'Localize product features', 5, 'Pending', TO_DATE('2024-07-01', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD'));

INSERT INTO Product_Ownership (PO_ID, Product_ID, Team_Leader_ID, Product_Name, Backlog_Items, Priorities, Sprint_Goals, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 8, 185, 'SmartApp', 'User authentication, Notifications', 'High, Medium', 'Implement auth module', 5, 'Active', TO_DATE('2024-05-01', 'YYYY-MM-DD'), TO_DATE('2024-10-31', 'YYYY-MM-DD'));
INSERT INTO Product_Ownership (PO_ID, Product_ID, Team_Leader_ID, Product_Name, Backlog_Items, Priorities, Sprint_Goals, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 8, 185, 'CloudSuite', 'API integration, Dashboard', 'Medium, High', 'Finish dashboard UI', 5, 'Pending', TO_DATE('2024-06-15', 'YYYY-MM-DD'), TO_DATE('2024-12-15', 'YYYY-MM-DD'));
INSERT INTO Product_Ownership (PO_ID, Product_ID, Team_Leader_ID, Product_Name, Backlog_Items, Priorities, Sprint_Goals, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 8, 185, 'DataSecure', 'Encryption, Backup', 'High, High', 'Complete encryption module', 5, 'Active', TO_DATE('2024-04-10', 'YYYY-MM-DD'), TO_DATE('2024-09-30', 'YYYY-MM-DD'));
INSERT INTO Product_Ownership (PO_ID, Product_ID, Team_Leader_ID, Product_Name, Backlog_Items, Priorities, Sprint_Goals, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 8, 185, 'SmartApp', 'Bug fixes, Performance', 'Low, Medium', 'Resolve reported bugs', 5, 'Inactive', TO_DATE('2024-03-01', 'YYYY-MM-DD'), TO_DATE('2024-08-31', 'YYYY-MM-DD'));
INSERT INTO Product_Ownership (PO_ID, Product_ID, Team_Leader_ID, Product_Name, Backlog_Items, Priorities, Sprint_Goals, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 8, 185, 'CloudSuite', 'Security audit, Logging', 'High, Low', 'Conduct security review', 5, 'Pending', TO_DATE('2024-07-01', 'YYYY-MM-DD'), TO_DATE('2024-12-31', 'YYYY-MM-DD'));

INSERT INTO Technical_Product_Management (TPM_ID, Product_ID, Team_Leader_ID, Product_Name, Requirements, Development_Approach, Technology_Used, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 8, 190, 'SmartApp', 'Mobile compatibility, High performance', 'Agile', 'React Native, Node.js', 5, 'Active', TO_DATE('2024-05-01', 'YYYY-MM-DD'), TO_DATE('2024-11-01', 'YYYY-MM-DD'));
INSERT INTO Technical_Product_Management (TPM_ID, Product_ID, Team_Leader_ID, Product_Name, Requirements, Development_Approach, Technology_Used, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 8, 190, 'CloudSuite', 'Scalability, Secure API', 'Scrum', 'AWS, Python Flask', 5, 'Pending', TO_DATE('2024-06-15', 'YYYY-MM-DD'), TO_DATE('2024-12-15', 'YYYY-MM-DD'));
INSERT INTO Technical_Product_Management (TPM_ID, Product_ID, Team_Leader_ID, Product_Name, Requirements, Development_Approach, Technology_Used, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 8, 190, 'DataSecure', 'Data encryption, Backup automation', 'Kanban', 'Java, PostgreSQL', 5, 'Active', TO_DATE('2024-04-10', 'YYYY-MM-DD'), TO_DATE('2024-09-30', 'YYYY-MM-DD'));
INSERT INTO Technical_Product_Management (TPM_ID, Product_ID, Team_Leader_ID, Product_Name, Requirements, Development_Approach, Technology_Used, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 8, 190, 'SmartApp', 'Bug fixing, UX improvements', 'Agile', 'React Native', 5, 'Inactive', TO_DATE('2024-03-01', 'YYYY-MM-DD'), TO_DATE('2024-08-31', 'YYYY-MM-DD'));
INSERT INTO Technical_Product_Management (TPM_ID, Product_ID, Team_Leader_ID, Product_Name, Requirements, Development_Approach, Technology_Used, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 8, 190, 'CloudSuite', 'Logging, Monitoring', 'Scrum', 'AWS CloudWatch, Python', 5, 'Pending', TO_DATE('2024-07-01', 'YYYY-MM-DD'), TO_DATE('2024-12-31', 'YYYY-MM-DD'));

INSERT INTO Growth_Product_Management (GPM_ID, Product_ID, Team_Leader_ID, Product_Name, Strategy, KPI, User_Segmentation, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 8, 195, 'SmartApp', 'Increase user retention', 'Monthly Active Users', 'Age 18-35, Urban', 5, 'Active', TO_DATE('2024-01-15', 'YYYY-MM-DD'), TO_DATE('2024-07-15', 'YYYY-MM-DD'));
INSERT INTO Growth_Product_Management (GPM_ID, Product_ID, Team_Leader_ID, Product_Name, Strategy, KPI, User_Segmentation, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 8, 195, 'CloudSuite', 'Expand market share', 'Customer Acquisition Rate', 'SMBs, North America', 5, 'Pending', TO_DATE('2024-03-01', 'YYYY-MM-DD'), TO_DATE('2024-09-01', 'YYYY-MM-DD'));
INSERT INTO Growth_Product_Management (GPM_ID, Product_ID, Team_Leader_ID, Product_Name, Strategy, KPI, User_Segmentation, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 8, 195, 'DataSecure', 'Boost upsell revenue', 'Average Revenue per User', 'Enterprise clients', 5, 'Active', TO_DATE('2024-02-10', 'YYYY-MM-DD'), TO_DATE('2024-08-10', 'YYYY-MM-DD'));
INSERT INTO Growth_Product_Management (GPM_ID, Product_ID, Team_Leader_ID, Product_Name, Strategy, KPI, User_Segmentation, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 8, 195, 'SmartApp', 'Improve user engagement', 'Session Length', 'Age 18-35, Urban', 5, 'Inactive', TO_DATE('2023-12-01', 'YYYY-MM-DD'), TO_DATE('2024-06-01', 'YYYY-MM-DD'));
INSERT INTO Growth_Product_Management (GPM_ID, Product_ID, Team_Leader_ID, Product_Name, Strategy, KPI, User_Segmentation, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 8, 195, 'CloudSuite', 'Reduce churn rate', 'Customer Retention Rate', 'SMBs, Europe', 5, 'Pending', TO_DATE('2024-04-15', 'YYYY-MM-DD'), TO_DATE('2024-10-15', 'YYYY-MM-DD'));

INSERT INTO Platform_Product_Management (PPM_ID, Product_ID, Team_Leader_ID, Platform_Name, Platform_Description, API_Documentation, Internal_Tools, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 8, 200, 'SmartPlatform', 'Platform for SmartApp integration', 'api.smartplatform.docs', 'ToolX, ToolY', 5, 'Active', TO_DATE('2024-01-10', 'YYYY-MM-DD'), TO_DATE('2024-07-10', 'YYYY-MM-DD'));
INSERT INTO Platform_Product_Management (PPM_ID, Product_ID, Team_Leader_ID, Platform_Name, Platform_Description, API_Documentation, Internal_Tools, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 8, 200, 'CloudPlatform', 'CloudSuite platform for SaaS', 'api.cloudplatform.docs', 'ToolA, ToolB', 5, 'Pending', TO_DATE('2024-02-15', 'YYYY-MM-DD'), TO_DATE('2024-08-15', 'YYYY-MM-DD'));
INSERT INTO Platform_Product_Management (PPM_ID, Product_ID, Team_Leader_ID, Platform_Name, Platform_Description, API_Documentation, Internal_Tools, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 8, 200, 'SecurePlatform', 'DataSecure platform backend', 'api.secureplatform.docs', 'ToolC, ToolD', 5, 'Active', TO_DATE('2024-03-01', 'YYYY-MM-DD'), TO_DATE('2024-09-01', 'YYYY-MM-DD'));
INSERT INTO Platform_Product_Management (PPM_ID, Product_ID, Team_Leader_ID, Platform_Name, Platform_Description, API_Documentation, Internal_Tools, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 8, 200, 'SmartPlatform', 'Extensions for SmartApp', 'api.smartplatform.ext.docs', 'ToolX, ToolZ', 5, 'Inactive', TO_DATE('2023-12-01', 'YYYY-MM-DD'), TO_DATE('2024-06-01', 'YYYY-MM-DD'));
INSERT INTO Platform_Product_Management (PPM_ID, Product_ID, Team_Leader_ID, Platform_Name, Platform_Description, API_Documentation, Internal_Tools, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 8, 200, 'CloudPlatform', 'Platform enhancements', 'api.cloudplatform.enhance.docs', 'ToolA, ToolE', 5, 'Pending', TO_DATE('2024-04-20', 'YYYY-MM-DD'), TO_DATE('2024-10-20', 'YYYY-MM-DD'));

INSERT INTO CEF (CEF_ID, Product_ID, Team_Leader_ID, Feedback_Type, Customer_Feedback, Feedback_Source, Customer_Rating, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 8, 205, 'Feature Request', 'Add dark mode', 'Email', 4, 5, 'Active', TO_DATE('2024-01-05', 'YYYY-MM-DD'), TO_DATE('2024-06-05', 'YYYY-MM-DD'));
INSERT INTO CEF (CEF_ID, Product_ID, Team_Leader_ID, Feedback_Type, Customer_Feedback, Feedback_Source, Customer_Rating, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 8, 205, 'Bug Report', 'App crashes on login', 'Support Ticket', 2, 5, 'Pending', TO_DATE('2024-02-10', 'YYYY-MM-DD'), TO_DATE('2024-07-10', 'YYYY-MM-DD'));
INSERT INTO CEF (CEF_ID, Product_ID, Team_Leader_ID, Feedback_Type, Customer_Feedback, Feedback_Source, Customer_Rating, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 8, 205, 'Praise', 'Excellent UX design', 'Survey', 5, 5, 'Active', TO_DATE('2024-03-15', 'YYYY-MM-DD'), TO_DATE('2024-08-15', 'YYYY-MM-DD'));
INSERT INTO CEF (CEF_ID, Product_ID, Team_Leader_ID, Feedback_Type, Customer_Feedback, Feedback_Source, Customer_Rating, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 8, 205, 'Feature Request', 'Improve loading speed', 'Phone Call', 3, 5, 'Inactive', TO_DATE('2023-12-20', 'YYYY-MM-DD'), TO_DATE('2024-05-20', 'YYYY-MM-DD'));
INSERT INTO CEF (CEF_ID, Product_ID, Team_Leader_ID, Feedback_Type, Customer_Feedback, Feedback_Source, Customer_Rating, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 8, 205, 'Suggestion', 'Add multi-language support', 'Email', 4, 5, 'Pending', TO_DATE('2024-04-01', 'YYYY-MM-DD'), TO_DATE('2024-09-01', 'YYYY-MM-DD'));

INSERT INTO Data_BI_Analytics (DAB_ID, Description, Team_Leader_ID, Status, Project_Start_Date, Project_End_Date) 
VALUES (9, 'Implementare dashboard pentru analiza vanzarilor', 206, 'Active', TO_DATE('2024-01-10', 'YYYY-MM-DD'), TO_DATE('2024-06-10', 'YYYY-MM-DD'));

INSERT INTO Data_Engineering (DE_ID, DAB_ID, Team_Leader_ID, Pipeline_Technologies, Warehouse_Platform, Data_Formats, Realtime_Capable, Engineers, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 9, 207, 'Apache Airflow', 'Snowflake', 'Parquet, JSON', 'Yes', 8, 5, 'Active', TO_DATE('2024-02-01', 'YYYY-MM-DD'), TO_DATE('2024-08-01', 'YYYY-MM-DD'));
INSERT INTO Data_Engineering (DE_ID, DAB_ID, Team_Leader_ID, Pipeline_Technologies, Warehouse_Platform, Data_Formats, Realtime_Capable, Engineers, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 9, 207, 'AWS Glue', 'Redshift', 'CSV, Avro', 'No', 5, 5, 'Active', TO_DATE('2024-03-15', 'YYYY-MM-DD'), TO_DATE('2024-09-15', 'YYYY-MM-DD'));
INSERT INTO Data_Engineering (DE_ID, DAB_ID, Team_Leader_ID, Pipeline_Technologies, Warehouse_Platform, Data_Formats, Realtime_Capable, Engineers, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 9, 207, 'Google Dataflow', 'BigQuery', 'JSON, Parquet', 'Yes', 7, 5, 'Pending', TO_DATE('2024-04-01', 'YYYY-MM-DD'), TO_DATE('2024-10-01', 'YYYY-MM-DD'));
INSERT INTO Data_Engineering (DE_ID, DAB_ID, Team_Leader_ID, Pipeline_Technologies, Warehouse_Platform, Data_Formats, Realtime_Capable, Engineers, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 9, 207, 'Apache NiFi', 'Azure Synapse', 'ORC, CSV', 'No', 6, 5, 'Inactive', TO_DATE('2024-05-10', 'YYYY-MM-DD'), TO_DATE('2024-11-10', 'YYYY-MM-DD'));
INSERT INTO Data_Engineering (DE_ID, DAB_ID, Team_Leader_ID, Pipeline_Technologies, Warehouse_Platform, Data_Formats, Realtime_Capable, Engineers, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 9, 207, 'Talend', 'Snowflake', 'XML, JSON', 'Yes', 9, 5, 'Active', TO_DATE('2024-06-01', 'YYYY-MM-DD'), TO_DATE('2024-12-01', 'YYYY-MM-DD'));

INSERT INTO BI_Development (BI_ID, DAB_ID, Team_Leader_ID, BI_Tools, Dashboards, Reporting_Frequency, Data_Sources_Integrated, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 9, 212, 'Tableau', 12, 'Weekly', 'Sales, Marketing', 5, 'Active', TO_DATE('2024-01-15', 'YYYY-MM-DD'), TO_DATE('2024-07-15', 'YYYY-MM-DD'));
INSERT INTO BI_Development (BI_ID, DAB_ID, Team_Leader_ID, BI_Tools, Dashboards, Reporting_Frequency, Data_Sources_Integrated, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 9, 212, 'Power BI', 8, 'Monthly', 'Finance, HR', 5, 'Active', TO_DATE('2024-02-01', 'YYYY-MM-DD'), TO_DATE('2024-08-01', 'YYYY-MM-DD'));
INSERT INTO BI_Development (BI_ID, DAB_ID, Team_Leader_ID, BI_Tools, Dashboards, Reporting_Frequency, Data_Sources_Integrated, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 9, 212, 'QlikView', 15, 'Daily', 'Operations, Logistics', 5, 'Pending', TO_DATE('2024-03-10', 'YYYY-MM-DD'), TO_DATE('2024-09-10', 'YYYY-MM-DD'));
INSERT INTO BI_Development (BI_ID, DAB_ID, Team_Leader_ID, BI_Tools, Dashboards, Reporting_Frequency, Data_Sources_Integrated, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 9, 212, 'Looker', 10, 'Weekly', 'Customer Support, Marketing', 5, 'Inactive', TO_DATE('2024-04-05', 'YYYY-MM-DD'), TO_DATE('2024-10-05', 'YYYY-MM-DD'));
INSERT INTO BI_Development (BI_ID, DAB_ID, Team_Leader_ID, BI_Tools, Dashboards, Reporting_Frequency, Data_Sources_Integrated, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 9, 212, 'Sisense', 7, 'Monthly', 'Product, Sales', 5, 'Active', TO_DATE('2024-05-01', 'YYYY-MM-DD'), TO_DATE('2024-11-01', 'YYYY-MM-DD'));

INSERT INTO Data_Analysis (DA_ID, DAB_ID, Team_Leader_ID, Analysis_Tools, Analysis_Type, Business_Areas_Covered, Insight_Reports, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 9, 217, 'Python, R', 'Predictive', 'Finance, Marketing', 15, 5, 'Active', TO_DATE('2024-01-10', 'YYYY-MM-DD'), TO_DATE('2024-06-10', 'YYYY-MM-DD'));
INSERT INTO Data_Analysis (DA_ID, DAB_ID, Team_Leader_ID, Analysis_Tools, Analysis_Type, Business_Areas_Covered, Insight_Reports, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 9, 217, 'Tableau', 'Descriptive', 'Sales, HR', 12, 5, 'Active', TO_DATE('2024-02-15', 'YYYY-MM-DD'), TO_DATE('2024-07-15', 'YYYY-MM-DD'));
INSERT INTO Data_Analysis (DA_ID, DAB_ID, Team_Leader_ID, Analysis_Tools, Analysis_Type, Business_Areas_Covered, Insight_Reports, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 9, 217, 'Power BI', 'Diagnostic', 'Operations, Logistics', 10, 5, 'Pending', TO_DATE('2024-03-20', 'YYYY-MM-DD'), TO_DATE('2024-08-20', 'YYYY-MM-DD'));
INSERT INTO Data_Analysis (DA_ID, DAB_ID, Team_Leader_ID, Analysis_Tools, Analysis_Type, Business_Areas_Covered, Insight_Reports, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 9, 217, 'Excel, SQL', 'Prescriptive', 'Customer Support, Marketing', 8, 5, 'Inactive', TO_DATE('2024-04-25', 'YYYY-MM-DD'), TO_DATE('2024-09-25', 'YYYY-MM-DD'));
INSERT INTO Data_Analysis (DA_ID, DAB_ID, Team_Leader_ID, Analysis_Tools, Analysis_Type, Business_Areas_Covered, Insight_Reports, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 9, 217, 'SAS, SPSS', 'Exploratory', 'Product, Sales', 14, 5, 'Active', TO_DATE('2024-05-05', 'YYYY-MM-DD'), TO_DATE('2024-10-05', 'YYYY-MM-DD'));

INSERT INTO Data_Science (DS_ID, DAB_ID, Team_Leader_ID, ML_Frameworks, Models_In_Production, Model_Types, Data_Scientists, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 9, 222, 'TensorFlow, PyTorch', 5, 'Classification, Regression', 8, 5, 'Active', TO_DATE('2024-01-01', 'YYYY-MM-DD'), TO_DATE('2024-06-30', 'YYYY-MM-DD')),
INSERT INTO Data_Science (DS_ID, DAB_ID, Team_Leader_ID, ML_Frameworks, Models_In_Production, Model_Types, Data_Scientists, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 9, 222, 'Scikit-learn', 3, 'Clustering', 6, 5, 'Active', TO_DATE('2024-02-15', 'YYYY-MM-DD'), TO_DATE('2024-07-15', 'YYYY-MM-DD'));
INSERT INTO Data_Science (DS_ID, DAB_ID, Team_Leader_ID, ML_Frameworks, Models_In_Production, Model_Types, Data_Scientists, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 9, 222, 'Keras', 7, 'Neural Networks', 10, 5, 'Pending', TO_DATE('2024-03-01', 'YYYY-MM-DD'), TO_DATE('2024-08-31', 'YYYY-MM-DD'));
INSERT INTO Data_Science (DS_ID, DAB_ID, Team_Leader_ID, ML_Frameworks, Models_In_Production, Model_Types, Data_Scientists, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 9, 222, 'XGBoost, LightGBM', 4, 'Boosting', 7, 5, 'Inactive', TO_DATE('2024-04-10', 'YYYY-MM-DD'), TO_DATE('2024-09-30', 'YYYY-MM-DD'));
INSERT INTO Data_Science (DS_ID, DAB_ID, Team_Leader_ID, ML_Frameworks, Models_In_Production, Model_Types, Data_Scientists, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 9, 222, 'TensorFlow', 6, 'Deep Learning', 9, 5, 'Active', TO_DATE('2024-05-05', 'YYYY-MM-DD'), TO_DATE('2024-10-05', 'YYYY-MM-DD'));

INSERT INTO MLOps (MLOps_ID, DAB_ID, Team_Leader_ID, Deployment_Tools, Monitoring_Enabled, Models_Deployed, CI_CD_Pipelines, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 9, 227, 'Kubeflow, Jenkins', 'Yes', 10, 3, 5, 'Active', TO_DATE('2024-01-10', 'YYYY-MM-DD'), TO_DATE('2024-06-10', 'YYYY-MM-DD'));
INSERT INTO MLOps (MLOps_ID, DAB_ID, Team_Leader_ID, Deployment_Tools, Monitoring_Enabled, Models_Deployed, CI_CD_Pipelines, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 9, 227, 'MLflow, GitLab CI', 'Yes', 7, 2, 5, 'Active', TO_DATE('2024-02-15', 'YYYY-MM-DD'), TO_DATE('2024-07-15', 'YYYY-MM-DD'));
INSERT INTO MLOps (MLOps_ID, DAB_ID, Team_Leader_ID, Deployment_Tools, Monitoring_Enabled, Models_Deployed, CI_CD_Pipelines, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 9, 227, 'SageMaker, CircleCI', 'No', 5, 1, 5, 'Pending', TO_DATE('2024-03-20', 'YYYY-MM-DD'), TO_DATE('2024-08-20', 'YYYY-MM-DD'));
INSERT INTO MLOps (MLOps_ID, DAB_ID, Team_Leader_ID, Deployment_Tools, Monitoring_Enabled, Models_Deployed, CI_CD_Pipelines, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 9, 227, 'TensorFlow Serving, Travis CI', 'Yes', 8, 4, 5, 'Inactive', TO_DATE('2024-04-25', 'YYYY-MM-DD'), TO_DATE('2024-09-25', 'YYYY-MM-DD'));
INSERT INTO MLOps (MLOps_ID, DAB_ID, Team_Leader_ID, Deployment_Tools, Monitoring_Enabled, Models_Deployed, CI_CD_Pipelines, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 9, 227, 'Azure ML, Jenkins', 'No', 6, 2, 5, 'Active', TO_DATE('2024-05-30', 'YYYY-MM-DD'), TO_DATE('2024-10-30', 'YYYY-MM-DD'));

INSERT INTO DGDQ (DGDQ_ID, DAB_ID, Team_Leader_ID, Data_Policies_Defined, Data_Quality_Framework, Compliance_Regulations, Audit_Frequency, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 9, 232, 15, 'DQF v1.2', 'GDPR, HIPAA', 'Monthly', 5, 'Active', TO_DATE('2024-01-05', 'YYYY-MM-DD'), TO_DATE('2024-06-05', 'YYYY-MM-DD'));
INSERT INTO DGDQ (DGDQ_ID, DAB_ID, Team_Leader_ID, Data_Policies_Defined, Data_Quality_Framework, Compliance_Regulations, Audit_Frequency, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 9, 232, 10, 'DQF v1.3', 'CCPA, GDPR', 'Quarterly', 5, 'Pending', TO_DATE('2024-02-10', 'YYYY-MM-DD'), TO_DATE('2024-07-10', 'YYYY-MM-DD'));
INSERT INTO DGDQ (DGDQ_ID, DAB_ID, Team_Leader_ID, Data_Policies_Defined, Data_Quality_Framework, Compliance_Regulations, Audit_Frequency, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 9, 232, 12, 'DQF v1.1', 'HIPAA', 'Monthly', 5, 'Active', TO_DATE('2024-03-15', 'YYYY-MM-DD'), TO_DATE('2024-08-15', 'YYYY-MM-DD'));
INSERT INTO DGDQ (DGDQ_ID, DAB_ID, Team_Leader_ID, Data_Policies_Defined, Data_Quality_Framework, Compliance_Regulations, Audit_Frequency, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 9, 232, 18, 'DQF v1.4', 'GDPR', 'Biannual', 5, 'Inactive', TO_DATE('2024-04-20', 'YYYY-MM-DD'), TO_DATE('2024-09-20', 'YYYY-MM-DD'));
INSERT INTO DGDQ (DGDQ_ID, DAB_ID, Team_Leader_ID, Data_Policies_Defined, Data_Quality_Framework, Compliance_Regulations, Audit_Frequency, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 9, 232, 20, 'DQF v1.5', 'CCPA', 'Monthly', 5, 'Active', TO_DATE('2024-05-25', 'YYYY-MM-DD'), TO_DATE('2024-10-25', 'YYYY-MM-DD'));

INSERT INTO Security_Cybersecurity (SC_ID, Description, Team_Leader_ID, Members, Security_Framework, Incident_Response_Plan, Status, Project_Start_Date, Project_End_Date) 
VALUES (10, 'Implementare măsuri de securitate cibernetică pentru infrastructura cloud', 233, 5, 'NIST Cybersecurity Framework', 'Yes', 'Active', TO_DATE('2024-03-01', 'YYYY-MM-DD'), TO_DATE('2024-12-01', 'YYYY-MM-DD'));

INSERT INTO Network_Security (NS_ID, SC_ID, Team_Leader_ID, Firewall_Brands, IDS_IPS_Deployed, VPN_Type, Network_Segmentation, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 10, 234, 'Cisco ASA, Fortinet', 'Yes', 'IPSec', 'Yes', 5, 'Active', TO_DATE('2024-04-15', 'YYYY-MM-DD'), TO_DATE('2024-11-15', 'YYYY-MM-DD'));
INSERT INTO Network_Security (NS_ID, SC_ID, Team_Leader_ID, Firewall_Brands, IDS_IPS_Deployed, VPN_Type, Network_Segmentation, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 10, 234, 'Palo Alto', 'No', 'SSL', 'No', 5, 'Pending', TO_DATE('2024-05-01', 'YYYY-MM-DD'), TO_DATE('2024-12-01', 'YYYY-MM-DD'));
INSERT INTO Network_Security (NS_ID, SC_ID, Team_Leader_ID, Firewall_Brands, IDS_IPS_Deployed, VPN_Type, Network_Segmentation, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 10, 234, 'Juniper SRX', 'Yes', 'L2TP', 'Yes', 5, 'Inactive', TO_DATE('2024-03-10', 'YYYY-MM-DD'), TO_DATE('2024-09-10', 'YYYY-MM-DD'));
INSERT INTO Network_Security (NS_ID, SC_ID, Team_Leader_ID, Firewall_Brands, IDS_IPS_Deployed, VPN_Type, Network_Segmentation, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 10, 234, 'Sophos UTM', 'Yes', 'OpenVPN', 'Yes', 5, 'Active', TO_DATE('2024-06-01', 'YYYY-MM-DD'), TO_DATE('2024-12-31', 'YYYY-MM-DD'));
INSERT INTO Network_Security (NS_ID, SC_ID, Team_Leader_ID, Firewall_Brands, IDS_IPS_Deployed, VPN_Type, Network_Segmentation, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 10, 234, 'Check Point', 'No', 'WireGuard', 'No', 5, 'Pending', TO_DATE('2024-07-01', 'YYYY-MM-DD'), TO_DATE('2025-01-01', 'YYYY-MM-DD'));

INSERT INTO Application_Security (AppSec_ID, SC_ID, Team_Leader_ID, Static_Analysis_Tools, Dynamic_Analysis, Secure_Coding_Guidelines, OWASP_Compliance_Level, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 10, 239, 'SonarQube, Fortify', 'Yes', 'Yes', 'Advanced', 5, 'Active', TO_DATE('2024-04-01', 'YYYY-MM-DD'), TO_DATE('2024-10-01', 'YYYY-MM-DD'));
INSERT INTO Application_Security (AppSec_ID, SC_ID, Team_Leader_ID, Static_Analysis_Tools, Dynamic_Analysis, Secure_Coding_Guidelines, OWASP_Compliance_Level, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 10, 239, 'Veracode', 'No', 'Yes', 'Intermediate', 5, 'Pending', TO_DATE('2024-05-10', 'YYYY-MM-DD'), TO_DATE('2024-12-10', 'YYYY-MM-DD'));
INSERT INTO Application_Security (AppSec_ID, SC_ID, Team_Leader_ID, Static_Analysis_Tools, Dynamic_Analysis, Secure_Coding_Guidelines, OWASP_Compliance_Level, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 10, 239, 'Checkmarx', 'Yes', 'No', 'Basic', 5, 'Inactive', TO_DATE('2024-03-15', 'YYYY-MM-DD'), TO_DATE('2024-09-15', 'YYYY-MM-DD'));
INSERT INTO Application_Security (AppSec_ID, SC_ID, Team_Leader_ID, Static_Analysis_Tools, Dynamic_Analysis, Secure_Coding_Guidelines, OWASP_Compliance_Level, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 10, 239, 'AppScan', 'Yes', 'Yes', 'Advanced', 5, 'Active', TO_DATE('2024-06-01', 'YYYY-MM-DD'), TO_DATE('2024-12-31', 'YYYY-MM-DD'));
INSERT INTO Application_Security (AppSec_ID, SC_ID, Team_Leader_ID, Static_Analysis_Tools, Dynamic_Analysis, Secure_Coding_Guidelines, OWASP_Compliance_Level, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 10, 239, 'CodeSonar', 'No', 'No', 'Intermediate', 5, 'Pending', TO_DATE('2024-07-01', 'YYYY-MM-DD'), TO_DATE('2025-01-01', 'YYYY-MM-DD'));

INSERT INTO Endpoint_Security (ES_ID, SC_ID, Team_Leader_ID, Endpoint_Protection_Platform, Device_Encryption, Patch_Management_Automated, Allowed_OS_List, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 10, 244, 'Microsoft Defender ATP', 'Yes', 'Yes', 'Windows 10, macOS', 5, 'Active', TO_DATE('2024-04-01', 'YYYY-MM-DD'), TO_DATE('2024-09-01', 'YYYY-MM-DD'));
INSERT INTO Endpoint_Security (ES_ID, SC_ID, Team_Leader_ID, Endpoint_Protection_Platform, Device_Encryption, Patch_Management_Automated, Allowed_OS_List, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 10, 244, 'CrowdStrike Falcon', 'Yes', 'No', 'Windows 11, Ubuntu 22.04', 5, 'Pending', TO_DATE('2024-05-15', 'YYYY-MM-DD'), TO_DATE('2024-11-15', 'YYYY-MM-DD'));
INSERT INTO Endpoint_Security (ES_ID, SC_ID, Team_Leader_ID, Endpoint_Protection_Platform, Device_Encryption, Patch_Management_Automated, Allowed_OS_List, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 10, 244, 'Sophos Intercept X', 'No', 'Yes', 'macOS Ventura, Windows 10', 5, 'Inactive', TO_DATE('2024-06-01', 'YYYY-MM-DD'), TO_DATE('2024-12-01', 'YYYY-MM-DD'));
INSERT INTO Endpoint_Security (ES_ID, SC_ID, Team_Leader_ID, Endpoint_Protection_Platform, Device_Encryption, Patch_Management_Automated, Allowed_OS_List, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 10, 244, 'Symantec Endpoint Protection', 'Yes', 'Yes', 'Windows 10, RHEL 9', 5, 'Active', TO_DATE('2024-07-01', 'YYYY-MM-DD'), TO_DATE('2025-01-01', 'YYYY-MM-DD'));
INSERT INTO Endpoint_Security (ES_ID, SC_ID, Team_Leader_ID, Endpoint_Protection_Platform, Device_Encryption, Patch_Management_Automated, Allowed_OS_List, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 10, 244, 'Trend Micro Apex One', 'No', 'No', 'Windows 11, Ubuntu 20.04', 5, 'Pending', TO_DATE('2024-08-01', 'YYYY-MM-DD'), TO_DATE('2025-02-01', 'YYYY-MM-DD'));

INSERT INTO IAM (IAM_ID, SC_ID, Team_Leader_ID, SSO_Implemented, MFA_Enforced, IAM_Platform, Roles_Defined, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 10, 249, 'Yes', 'Yes', 'Okta', 10, 5, 'Active', TO_DATE('2024-03-01', 'YYYY-MM-DD'), TO_DATE('2024-09-01', 'YYYY-MM-DD'));
INSERT INTO IAM (IAM_ID, SC_ID, Team_Leader_ID, SSO_Implemented, MFA_Enforced, IAM_Platform, Roles_Defined, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 10, 249, 'No', 'Yes', 'Azure AD', 8, 5, 'Pending', TO_DATE('2024-04-15', 'YYYY-MM-DD'), TO_DATE('2024-10-15', 'YYYY-MM-DD'));
INSERT INTO IAM (IAM_ID, SC_ID, Team_Leader_ID, SSO_Implemented, MFA_Enforced, IAM_Platform, Roles_Defined, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 10, 249, 'Yes', 'No', 'Auth0', 12, 5, 'Inactive', TO_DATE('2024-05-01', 'YYYY-MM-DD'), TO_DATE('2024-11-01', 'YYYY-MM-DD'));
INSERT INTO IAM (IAM_ID, SC_ID, Team_Leader_ID, SSO_Implemented, MFA_Enforced, IAM_Platform, Roles_Defined, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 10, 249, 'Yes', 'Yes', 'ForgeRock', 15, 5, 'Active', TO_DATE('2024-06-01', 'YYYY-MM-DD'), TO_DATE('2024-12-01', 'YYYY-MM-DD'));
INSERT INTO IAM (IAM_ID, SC_ID, Team_Leader_ID, SSO_Implemented, MFA_Enforced, IAM_Platform, Roles_Defined, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 10, 249, 'No', 'No', 'AWS IAM', 6, 5, 'Pending', TO_DATE('2024-07-01', 'YYYY-MM-DD'), TO_DATE('2025-01-01', 'YYYY-MM-DD'));

INSERT INTO TIA (TIA_ID, SC_ID, Team_Leader_ID, Intel_Feeds, Threat_Report_Count, SIEM_Integrated, External_Threat_Sources, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 10, 254, 'FireEye, Anomali', 25, 'Yes', 'Dark Web, Threat Forums', 5, 'Active', TO_DATE('2024-03-01', 'YYYY-MM-DD'), TO_DATE('2024-08-01', 'YYYY-MM-DD'));
INSERT INTO TIA (TIA_ID, SC_ID, Team_Leader_ID, Intel_Feeds, Threat_Report_Count, SIEM_Integrated, External_Threat_Sources, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 10, 254, 'Recorded Future, IBM X-Force', 30, 'No', 'Open Source Feeds', 5, 'Pending', TO_DATE('2024-04-10', 'YYYY-MM-DD'), TO_DATE('2024-09-10', 'YYYY-MM-DD'));
INSERT INTO TIA (TIA_ID, SC_ID, Team_Leader_ID, Intel_Feeds, Threat_Report_Count, SIEM_Integrated, External_Threat_Sources, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 10, 254, 'Cisco Talos', 15, 'Yes', 'Government Databases', 5, 'Inactive', TO_DATE('2024-05-15', 'YYYY-MM-DD'), TO_DATE('2024-10-15', 'YYYY-MM-DD'));
INSERT INTO TIA (TIA_ID, SC_ID, Team_Leader_ID, Intel_Feeds, Threat_Report_Count, SIEM_Integrated, External_Threat_Sources, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 10, 254, 'Mandiant, Kaspersky', 40, 'Yes', 'Industry Reports', 5, 'Active', TO_DATE('2024-06-01', 'YYYY-MM-DD'), TO_DATE('2024-12-01', 'YYYY-MM-DD'));
INSERT INTO TIA (TIA_ID, SC_ID, Team_Leader_ID, Intel_Feeds, Threat_Report_Count, SIEM_Integrated, External_Threat_Sources, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 10, 254, 'CrowdStrike, Proofpoint', 20, 'No', 'Honeypot Logs', 5, 'Pending', TO_DATE('2024-07-01', 'YYYY-MM-DD'), TO_DATE('2025-01-01', 'YYYY-MM-DD'));

INSERT INTO DevOps_SRE (DS_ID, Description, Team_Leader_ID, Mission, Status, Project_Start_Date, Project_End_Date) 
VALUES (11, 'Stabilirea și menținerea fiabilității infrastructurii CI/CD', 255, 'Automatizare și observabilitate', 'Active', TO_DATE('2024-01-10', 'YYYY-MM-DD'), TO_DATE('2024-07-10', 'YYYY-MM-DD'));

INSERT INTO CICD_Pipeline_Management (CPipeM_ID, DS_ID, Team_Leader_ID, Pipeline_Name, Tool, Stages, Last_Deployment, Auto_Rollback_Enabled, Notification_Channels, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 11, 256, 'Frontend Deployment', 'Jenkins', 'Build,Test,Deploy', TO_DATE('2024-05-10','YYYY-MM-DD'), 'Yes', 'Slack,Email', 5, 'Active', TO_DATE('2024-01-01','YYYY-MM-DD'), TO_DATE('2024-12-31','YYYY-MM-DD'));
INSERT INTO CICD_Pipeline_Management (CPipeM_ID, DS_ID, Team_Leader_ID, Pipeline_Name, Tool, Stages, Last_Deployment, Auto_Rollback_Enabled, Notification_Channels, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 11, 256, 'Backend Microservices', 'GitLab CI', 'Build,UnitTest,IntegrationTest,Deploy', TO_DATE('2024-05-15','YYYY-MM-DD'), 'No', 'Teams', 5, 'Active', TO_DATE('2024-02-01','YYYY-MM-DD'), TO_DATE('2024-10-31','YYYY-MM-DD'));
INSERT INTO CICD_Pipeline_Management (CPipeM_ID, DS_ID, Team_Leader_ID, Pipeline_Name, Tool, Stages, Last_Deployment, Auto_Rollback_Enabled, Notification_Channels, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 11, 256, 'Data Pipeline CI/CD', 'CircleCI', 'Extract,Transform,Load', TO_DATE('2024-06-01','YYYY-MM-DD'), 'Yes', 'Slack', 5, 'Pending', TO_DATE('2024-03-01','YYYY-MM-DD'), TO_DATE('2024-11-01','YYYY-MM-DD'));
INSERT INTO CICD_Pipeline_Management (CPipeM_ID, DS_ID, Team_Leader_ID, Pipeline_Name, Tool, Stages, Last_Deployment, Auto_Rollback_Enabled, Notification_Channels, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 11, 256, 'Mobile App Pipeline', 'Azure DevOps', 'Build,Test,Deploy', TO_DATE('2024-06-10','YYYY-MM-DD'), 'No', 'Email', 5, 'Inactive', TO_DATE('2024-04-01','YYYY-MM-DD'), TO_DATE('2024-09-01','YYYY-MM-DD'));
INSERT INTO CICD_Pipeline_Management (CPipeM_ID, DS_ID, Team_Leader_ID, Pipeline_Name, Tool, Stages, Last_Deployment, Auto_Rollback_Enabled, Notification_Channels, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 11, 256, 'API Gateway Deployments', 'GitHub Actions', 'Build,SecurityScan,Deploy', TO_DATE('2024-05-28','YYYY-MM-DD'), 'Yes', 'Slack,PagerDuty', 5, 'Active', TO_DATE('2024-01-15','YYYY-MM-DD'), TO_DATE('2024-08-15','YYYY-MM-DD'));

INSERT INTO Infrastructure_as_Code (IaC_ID, DS_ID, Team_Leader_ID, Tool, Code_Repository, Environment_Target, Version_Control, Last_Applied_Date, Auto_Approve_Changes, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (1, 11, 261, 'Terraform', 'https://repo.company.com/iac/terraform-networking', 'Production', 'Git', TO_DATE('2024-06-01','YYYY-MM-DD'), 'Yes', 5, 'Active', TO_DATE('2024-01-01','YYYY-MM-DD'), TO_DATE('2024-12-31','YYYY-MM-DD'));
INSERT INTO Infrastructure_as_Code (IaC_ID, DS_ID, Team_Leader_ID, Tool, Code_Repository, Environment_Target, Version_Control, Last_Applied_Date, Auto_Approve_Changes, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (2, 11, 261, 'Pulumi', 'https://repo.company.com/iac/pulumi-cloud', 'Staging', 'Git', TO_DATE('2024-05-25','YYYY-MM-DD'), 'No', 5, 'Active', TO_DATE('2024-02-01','YYYY-MM-DD'), TO_DATE('2024-10-31','YYYY-MM-DD'));
INSERT INTO Infrastructure_as_Code (IaC_ID, DS_ID, Team_Leader_ID, Tool, Code_Repository, Environment_Target, Version_Control, Last_Applied_Date, Auto_Approve_Changes, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (3, 11, 261, 'AWS CloudFormation', 'https://repo.company.com/iac/cloudformation', 'Dev', 'SVN', TO_DATE('2024-06-10','YYYY-MM-DD'), 'No', 5, 'Pending', TO_DATE('2024-03-01','YYYY-MM-DD'), TO_DATE('2024-11-01','YYYY-MM-DD'));
INSERT INTO Infrastructure_as_Code (IaC_ID, DS_ID, Team_Leader_ID, Tool, Code_Repository, Environment_Target, Version_Control, Last_Applied_Date, Auto_Approve_Changes, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (4, 11, 261, 'Ansible', 'https://repo.company.com/iac/ansible-provisioning', 'QA', 'Git', TO_DATE('2024-06-15','YYYY-MM-DD'), 'Yes', 5, 'Inactive', TO_DATE('2024-04-01','YYYY-MM-DD'), TO_DATE('2024-09-01','YYYY-MM-DD'));
INSERT INTO Infrastructure_as_Code (IaC_ID, DS_ID, Team_Leader_ID, Tool, Code_Repository, Environment_Target, Version_Control, Last_Applied_Date, Auto_Approve_Changes, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (5, 11, 261, 'Chef', 'https://repo.company.com/iac/chef-setup', 'Production', 'Git', TO_DATE('2024-06-05','YYYY-MM-DD'), 'Yes', 5, 'Active', TO_DATE('2024-01-15','YYYY-MM-DD'), TO_DATE('2024-08-15','YYYY-MM-DD'));

INSERT INTO Observability_Monitoring (ObsMon_ID, DS_ID, Team_Leader_ID, Tool, Monitoring_Scope, Dashboard_URL, Alerting_Enabled, Incident_Integration, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (1, 11, 266, 'Prometheus', 'Infrastructure', 'https://dash.company.com/prometheus/infra', 'Yes', 'PagerDuty', 5, 'Active', TO_DATE('2024-01-01','YYYY-MM-DD'), TO_DATE('2024-12-31','YYYY-MM-DD'));
INSERT INTO Observability_Monitoring (ObsMon_ID, DS_ID, Team_Leader_ID, Tool, Monitoring_Scope, Dashboard_URL, Alerting_Enabled, Incident_Integration, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (2, 11, 266, 'Grafana', 'Applications', 'https://dash.company.com/grafana/apps', 'Yes', 'OpsGenie', 5, 'Active', TO_DATE('2024-02-01','YYYY-MM-DD'), TO_DATE('2024-11-30','YYYY-MM-DD'));
INSERT INTO Observability_Monitoring (ObsMon_ID, DS_ID, Team_Leader_ID, Tool, Monitoring_Scope, Dashboard_URL, Alerting_Enabled, Incident_Integration, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (3, 11, 266, 'Datadog', 'Full Stack', 'https://dash.company.com/datadog/full', 'Yes', 'Slack', 5, 'Pending', TO_DATE('2024-03-15','YYYY-MM-DD'), TO_DATE('2024-09-15','YYYY-MM-DD'));
INSERT INTO Observability_Monitoring (ObsMon_ID, DS_ID, Team_Leader_ID, Tool, Monitoring_Scope, Dashboard_URL, Alerting_Enabled, Incident_Integration, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (4, 11, 266, 'New Relic', 'APM', 'https://dash.company.com/newrelic/apm', 'No', 'Email', 5, 'Inactive', TO_DATE('2024-04-10','YYYY-MM-DD'), TO_DATE('2024-10-10','YYYY-MM-DD'));
INSERT INTO Observability_Monitoring (ObsMon_ID, DS_ID, Team_Leader_ID, Tool, Monitoring_Scope, Dashboard_URL, Alerting_Enabled, Incident_Integration, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (5, 11, 266, 'Elastic Stack', 'Logs and Metrics', 'https://dash.company.com/elastic/logs', 'Yes', 'ServiceNow', 5, 'Active', TO_DATE('2024-05-01','YYYY-MM-DD'), TO_DATE('2024-12-01','YYYY-MM-DD'));

INSERT INTO Incident_Response_Reliability (IRRE_ID, DS_ID, Team_Leader_ID, Incident_Process_Name, On_Call_Rotation_Model, Incident_Tracking_Tool, Last_Major_Incident, PostMortem_Required, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (1, 11, 271, 'Critical Path Monitoring', 'Follow-the-sun', 'PagerDuty', TO_DATE('2024-02-15', 'YYYY-MM-DD'), 'Yes', 5, 'Active', TO_DATE('2024-01-01', 'YYYY-MM-DD'), TO_DATE('2024-12-31', 'YYYY-MM-DD'));
INSERT INTO Incident_Response_Reliability (IRRE_ID, DS_ID, Team_Leader_ID, Incident_Process_Name, On_Call_Rotation_Model, Incident_Tracking_Tool, Last_Major_Incident, PostMortem_Required, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (2, 11, 271, 'Service Escalation', 'Week-On/Off', 'OpsGenie', TO_DATE('2024-03-20', 'YYYY-MM-DD'), 'Yes', 5, 'Active', TO_DATE('2024-02-01', 'YYYY-MM-DD'), TO_DATE('2024-10-31', 'YYYY-MM-DD'));
INSERT INTO Incident_Response_Reliability (IRRE_ID, DS_ID, Team_Leader_ID, Incident_Process_Name, On_Call_Rotation_Model, Incident_Tracking_Tool, Last_Major_Incident, PostMortem_Required, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (3, 11, 271, 'Root Cause Audit', 'Weekend Duty', 'ServiceNow', TO_DATE('2024-04-05', 'YYYY-MM-DD'), 'No', 5, 'Pending', TO_DATE('2024-03-10', 'YYYY-MM-DD'), TO_DATE('2024-11-15', 'YYYY-MM-DD'));
INSERT INTO Incident_Response_Reliability (IRRE_ID, DS_ID, Team_Leader_ID, Incident_Process_Name, On_Call_Rotation_Model, Incident_Tracking_Tool, Last_Major_Incident, PostMortem_Required, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (4, 11, 271, 'Alert Escalation Flow', 'Daily Rotation', 'Jira', TO_DATE('2024-05-01', 'YYYY-MM-DD'), 'Yes', 5, 'Active', TO_DATE('2024-04-01', 'YYYY-MM-DD'), TO_DATE('2024-12-01', 'YYYY-MM-DD'));
INSERT INTO Incident_Response_Reliability (IRRE_ID, DS_ID, Team_Leader_ID, Incident_Process_Name, On_Call_Rotation_Model, Incident_Tracking_Tool, Last_Major_Incident, PostMortem_Required, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (5, 11, 271, 'SLA Violation Handling', '24/7 Fixed Team', 'Zendesk', TO_DATE('2024-06-01', 'YYYY-MM-DD'), 'No', 5, 'Inactive', TO_DATE('2024-05-10', 'YYYY-MM-DD'), TO_DATE('2024-12-31', 'YYYY-MM-DD'));

INSERT INTO Platform_Engineering (PE_ID, DS_ID, Team_Leader_ID, Platform_Name, Technologies_Used, Self_Service_Portal, Documentation_URL, Onboarding_Required, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (1, 11, 276, 'Internal Dev Platform', 'Kubernetes, Terraform', 'Yes', 'https://docs.devplatform.local', 'Yes', 5, 'Active', TO_DATE('2024-01-15', 'YYYY-MM-DD'), TO_DATE('2024-12-15', 'YYYY-MM-DD'));
INSERT INTO Platform_Engineering (PE_ID, DS_ID, Team_Leader_ID, Platform_Name, Technologies_Used, Self_Service_Portal, Documentation_URL, Onboarding_Required, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (2, 11, 276, 'DataOps Hub', 'Docker, GitLab CI', 'No', 'https://wiki.company.com/dataops', 'Yes', 5, 'Pending', TO_DATE('2024-02-01', 'YYYY-MM-DD'), TO_DATE('2024-10-31', 'YYYY-MM-DD'));
INSERT INTO Platform_Engineering (PE_ID, DS_ID, Team_Leader_ID, Platform_Name, Technologies_Used, Self_Service_Portal, Documentation_URL, Onboarding_Required, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (3, 11, 276, 'Infra Management Portal', 'Ansible, Jenkins', 'Yes', 'https://infraportal.io/docs', 'No', 5, 'Active', TO_DATE('2024-03-10', 'YYYY-MM-DD'), TO_DATE('2024-11-30', 'YYYY-MM-DD'));
INSERT INTO Platform_Engineering (PE_ID, DS_ID, Team_Leader_ID, Platform_Name, Technologies_Used, Self_Service_Portal, Documentation_URL, Onboarding_Required, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (4, 11, 276, 'App Delivery Platform', 'Helm, ArgoCD', 'No', 'https://docs.deliveryplatform.com', 'Yes', 5, 'Inactive', TO_DATE('2024-04-05', 'YYYY-MM-DD'), TO_DATE('2024-12-01', 'YYYY-MM-DD'));
INSERT INTO Platform_Engineering (PE_ID, DS_ID, Team_Leader_ID, Platform_Name, Technologies_Used, Self_Service_Portal, Documentation_URL, Onboarding_Required, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (5, 11, 276, 'Developer Experience Hub', 'Backstage, GitHub Actions', 'Yes', 'https://devhub.internal/docs', 'Yes', 5, 'Active', TO_DATE('2024-05-01', 'YYYY-MM-DD'), TO_DATE('2024-12-31', 'YYYY-MM-DD'));

INSERT INTO Cloud_Automation (CA_ID, DS_ID, Team_Leader_ID, Cloud_Provider, Automation_Tool, Resource_Type, Auto_Scaling_Enabled, Scheduled_Automation, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (1, 11, 281, 'AWS', 'Terraform', 'EC2 Instances', 'Yes', 'Nightly Scale-Down', 5, 'Active', TO_DATE('2024-01-10', 'YYYY-MM-DD'), TO_DATE('2024-12-10', 'YYYY-MM-DD'));
INSERT INTO Cloud_Automation (CA_ID, DS_ID, Team_Leader_ID, Cloud_Provider, Automation_Tool, Resource_Type, Auto_Scaling_Enabled, Scheduled_Automation, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (2, 11, 281, 'Azure', 'Bicep', 'Virtual Machines', 'No', 'Weekly Patching', 5, 'Pending', TO_DATE('2024-02-01', 'YYYY-MM-DD'), TO_DATE('2024-11-30', 'YYYY-MM-DD'));
INSERT INTO Cloud_Automation (CA_ID, DS_ID, Team_Leader_ID, Cloud_Provider, Automation_Tool, Resource_Type, Auto_Scaling_Enabled, Scheduled_Automation, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (3, 11, 281, 'GCP', 'Pulumi', 'Kubernetes Clusters', 'Yes', 'Daily Metrics Sync', 5, 'Active', TO_DATE('2024-03-15', 'YYYY-MM-DD'), TO_DATE('2024-12-31', 'YYYY-MM-DD'));
INSERT INTO Cloud_Automation (CA_ID, DS_ID, Team_Leader_ID, Cloud_Provider, Automation_Tool, Resource_Type, Auto_Scaling_Enabled, Scheduled_Automation, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (4, 11, 281, 'AWS', 'CloudFormation', 'S3 Buckets', 'No', 'Monthly Cleanup', 5, 'Inactive', TO_DATE('2024-04-01', 'YYYY-MM-DD'), TO_DATE('2024-10-01', 'YYYY-MM-DD'));
INSERT INTO Cloud_Automation (CA_ID, DS_ID, Team_Leader_ID, Cloud_Provider, Automation_Tool, Resource_Type, Auto_Scaling_Enabled, Scheduled_Automation, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (5, 11, 281, 'Azure', 'Ansible', 'App Services', 'Yes', 'Auto-Restart Weekly', 5, 'Active', TO_DATE('2024-05-10', 'YYYY-MM-DD'), TO_DATE('2024-12-20', 'YYYY-MM-DD'));

INSERT INTO CS_ClientSupport_IT (CSCSIT_ID, Description, Team_Leader_ID, Status, Project_Start_Date, Project_End_Date)
VALUES (12, 'Support for internal IT client requests and troubleshooting', 282, 'Active', TO_DATE('2024-01-15', 'YYYY-MM-DD'), TO_DATE('2024-12-15', 'YYYY-MM-DD'));

INSERT INTO Desktop_Support (Desktop_Support_ID, CSCSIT_ID, Team_Leader_ID, Support_Level, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (1, 12, 283, 'L1', 5, 'Active', TO_DATE('2024-01-01', 'YYYY-MM-DD'), TO_DATE('2024-06-30', 'YYYY-MM-DD'));
INSERT INTO Desktop_Support (Desktop_Support_ID, CSCSIT_ID, Team_Leader_ID, Support_Level, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (2, 12, 283, 'L2', 5, 'Active', TO_DATE('2024-02-01', 'YYYY-MM-DD'), TO_DATE('2024-07-31', 'YYYY-MM-DD'));
INSERT INTO Desktop_Support (Desktop_Support_ID, CSCSIT_ID, Team_Leader_ID, Support_Level, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (3, 12, 283, 'L3', 5, 'Pending', TO_DATE('2024-03-01', 'YYYY-MM-DD'), TO_DATE('2024-08-31', 'YYYY-MM-DD'));
INSERT INTO Desktop_Support (Desktop_Support_ID, CSCSIT_ID, Team_Leader_ID, Support_Level, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (4, 12, 283, 'L1', 5, 'Inactive', TO_DATE('2024-04-01', 'YYYY-MM-DD'), TO_DATE('2024-09-30', 'YYYY-MM-DD'));
INSERT INTO Desktop_Support (Desktop_Support_ID, CSCSIT_ID, Team_Leader_ID, Support_Level, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (5, 12, 283, 'L2', 5, 'Active', TO_DATE('2024-05-01', 'YYYY-MM-DD'), TO_DATE('2024-12-31', 'YYYY-MM-DD'));

INSERT INTO Remote_Support (RS_ID, CSCSIT_ID, Team_Leader_ID, Support_Level, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (1, 12, 288, 'L1', 5, 'Active', TO_DATE('2024-01-10', 'YYYY-MM-DD'), TO_DATE('2024-06-10', 'YYYY-MM-DD'));
INSERT INTO Remote_Support (RS_ID, CSCSIT_ID, Team_Leader_ID, Support_Level, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (2, 12, 288, 'L2', 5, 'Pending', TO_DATE('2024-02-15', 'YYYY-MM-DD'), TO_DATE('2024-07-15', 'YYYY-MM-DD'));
INSERT INTO Remote_Support (RS_ID, CSCSIT_ID, Team_Leader_ID, Support_Level, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (3, 12, 288, 'L3', 5, 'Inactive', TO_DATE('2024-03-20', 'YYYY-MM-DD'), TO_DATE('2024-08-20', 'YYYY-MM-DD'));
INSERT INTO Remote_Support (RS_ID, CSCSIT_ID, Team_Leader_ID, Support_Level, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (4, 12, 288, 'L2', 5, 'Active', TO_DATE('2024-04-25', 'YYYY-MM-DD'), TO_DATE('2024-09-25', 'YYYY-MM-DD'));
INSERT INTO Remote_Support (RS_ID, CSCSIT_ID, Team_Leader_ID, Support_Level, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (5, 12, 288, 'L1', 5, 'Active', TO_DATE('2024-05-30', 'YYYY-MM-DD'), TO_DATE('2024-12-30', 'YYYY-MM-DD'));

INSERT INTO Knowledge_Management (KM_ID, CSCSIT_ID, Team_Leader_ID, Documentation_Type, Documentation_Status, Last_Updated, Access_Level, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (1, 12, 293, 'User Guides', 'Completed', TO_DATE('2024-01-05', 'YYYY-MM-DD'), 'Public', 5, 'Active', TO_DATE('2024-01-01', 'YYYY-MM-DD'), TO_DATE('2024-12-31', 'YYYY-MM-DD'));
INSERT INTO Knowledge_Management (KM_ID, CSCSIT_ID, Team_Leader_ID, Documentation_Type, Documentation_Status, Last_Updated, Access_Level, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (2, 12, 293, 'API Documentation', 'In Progress', TO_DATE('2024-02-15', 'YYYY-MM-DD'), 'Restricted', 5, 'Pending', TO_DATE('2024-02-01', 'YYYY-MM-DD'), TO_DATE('2024-08-31', 'YYYY-MM-DD'));
INSERT INTO Knowledge_Management (KM_ID, CSCSIT_ID, Team_Leader_ID, Documentation_Type, Documentation_Status, Last_Updated, Access_Level, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (3, 12, 293, 'System Architecture', 'Draft', TO_DATE('2024-03-20', 'YYYY-MM-DD'), 'Internal', 5, 'Inactive', TO_DATE('2024-03-01', 'YYYY-MM-DD'), TO_DATE('2024-10-30', 'YYYY-MM-DD'));
INSERT INTO Knowledge_Management (KM_ID, CSCSIT_ID, Team_Leader_ID, Documentation_Type, Documentation_Status, Last_Updated, Access_Level, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (4, 12, 293, 'Security Policies', 'Reviewed', TO_DATE('2024-04-25', 'YYYY-MM-DD'), 'Confidential', 5, 'Active', TO_DATE('2024-04-01', 'YYYY-MM-DD'), TO_DATE('2024-11-30', 'YYYY-MM-DD'));
INSERT INTO Knowledge_Management (KM_ID, CSCSIT_ID, Team_Leader_ID, Documentation_Type, Documentation_Status, Last_Updated, Access_Level, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (5, 12, 293, 'Troubleshooting Guides', 'Completed', TO_DATE('2024-05-10', 'YYYY-MM-DD'), 'Public', 5, 'Active', TO_DATE('2024-05-01', 'YYYY-MM-DD'), TO_DATE('2024-12-31', 'YYYY-MM-DD'));

INSERT INTO VIP_Executive_Support (VIPES_ID, CSCSIT_ID, Team_Leader_ID, Support_Level, VIP_Client_ID, Support_Request_Description, Request_Date, Resolution_Date, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (1, 12, 298, 'High', 1001, 'Urgent issue with data sync', TO_DATE('2025-05-01', 'YYYY-MM-DD'), TO_DATE('2025-05-02', 'YYYY-MM-DD'), 5, 'Active', TO_DATE('2025-04-25', 'YYYY-MM-DD'), TO_DATE('2025-06-30', 'YYYY-MM-DD'));
INSERT INTO VIP_Executive_Support (VIPES_ID, CSCSIT_ID, Team_Leader_ID, Support_Level, VIP_Client_ID, Support_Request_Description, Request_Date, Resolution_Date, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (2, 12, 298, 'Med', 1002, 'Request for performance report', TO_DATE('2025-04-15', 'YYYY-MM-DD'), TO_DATE('2025-04-20', 'YYYY-MM-DD'), 5, 'Active', TO_DATE('2025-04-10', 'YYYY-MM-DD'), TO_DATE('2025-09-30', 'YYYY-MM-DD'));
INSERT INTO VIP_Executive_Support (VIPES_ID, CSCSIT_ID, Team_Leader_ID, Support_Level, VIP_Client_ID, Support_Request_Description, Request_Date, Resolution_Date, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (3, 12, 298, 'Low', 1003, 'Assistance with software installation', TO_DATE('2025-03-05', 'YYYY-MM-DD'), TO_DATE('2025-03-06', 'YYYY-MM-DD'), 5, 'Inactive', TO_DATE('2025-03-01', 'YYYY-MM-DD'), TO_DATE('2025-08-31', 'YYYY-MM-DD'));
INSERT INTO VIP_Executive_Support (VIPES_ID, CSCSIT_ID, Team_Leader_ID, Support_Level, VIP_Client_ID, Support_Request_Description, Request_Date, Resolution_Date, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (4, 12, 298, 'High', 1004, 'Critical security patch deployment', TO_DATE('2025-02-10', 'YYYY-MM-DD'), TO_DATE('2025-02-11', 'YYYY-MM-DD'), 5, 'Active', TO_DATE('2025-02-01', 'YYYY-MM-DD'), TO_DATE('2025-07-31', 'YYYY-MM-DD'));
INSERT INTO VIP_Executive_Support (VIPES_ID, CSCSIT_ID, Team_Leader_ID, Support_Level, VIP_Client_ID, Support_Request_Description, Request_Date, Resolution_Date, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (5, 12, 298, 'Med', 1005, 'Configuration support for new app rollout', TO_DATE('2025-01-20', 'YYYY-MM-DD'), TO_DATE('2025-01-22', 'YYYY-MM-DD'), 5, 'Pending', TO_DATE('2025-01-15', 'YYYY-MM-DD'), TO_DATE('2025-06-30', 'YYYY-MM-DD'));

INSERT INTO Service_Desk_Coordination (SDC_ID, CSCSIT_ID, Team_Leader_ID, Request_Description, Request_Date, Assigned_To_ID, Priority_Request, Resolution_Date, Solution_Description, Escalation_Level, Status_Update_Date, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (1, 12, 303, 'User unable to access email', TO_DATE('2025-06-01', 'YYYY-MM-DD'), 801, 'High', TO_DATE('2025-06-02', 'YYYY-MM-DD'), 'Reset user password', 'L1', TO_DATE('2025-06-02', 'YYYY-MM-DD'), 5, 'Active', TO_DATE('2025-05-25', 'YYYY-MM-DD'), TO_DATE('2025-12-31', 'YYYY-MM-DD'));
INSERT INTO Service_Desk_Coordination (SDC_ID, CSCSIT_ID, Team_Leader_ID, Request_Description, Request_Date, Assigned_To_ID, Priority_Request, Resolution_Date, Solution_Description, Escalation_Level, Status_Update_Date, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (2, 12, 303, 'Software installation request', TO_DATE('2025-06-05', 'YYYY-MM-DD'), 802, 'Medium', TO_DATE('2025-06-07', 'YYYY-MM-DD'), 'Installed requested software', 'L2', TO_DATE('2025-06-07', 'YYYY-MM-DD'), 5, 'Active', TO_DATE('2025-06-01', 'YYYY-MM-DD'), TO_DATE('2025-11-30', 'YYYY-MM-DD'));
INSERT INTO Service_Desk_Coordination (SDC_ID, CSCSIT_ID, Team_Leader_ID, Request_Description, Request_Date, Assigned_To_ID, Priority_Request, Resolution_Date, Solution_Description, Escalation_Level, Status_Update_Date, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (3, 12, 303, 'Network connectivity issue', TO_DATE('2025-06-10', 'YYYY-MM-DD'), 803, 'High', TO_DATE('2025-06-11', 'YYYY-MM-DD'), 'Reconfigured network settings', 'L1', TO_DATE('2025-06-11', 'YYYY-MM-DD'), 5, 'Pending', TO_DATE('2025-06-05', 'YYYY-MM-DD'), TO_DATE('2025-12-15', 'YYYY-MM-DD'));
INSERT INTO Service_Desk_Coordination (SDC_ID, CSCSIT_ID, Team_Leader_ID, Request_Description, Request_Date, Assigned_To_ID, Priority_Request, Resolution_Date, Solution_Description, Escalation_Level, Status_Update_Date, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (4, 12, 303, 'Password reset request', TO_DATE('2025-06-12', 'YYYY-MM-DD'), 804, 'Low', TO_DATE('2025-06-13', 'YYYY-MM-DD'), 'Reset password via admin console', 'L1', TO_DATE('2025-06-13', 'YYYY-MM-DD'), 5, 'Active', TO_DATE('2025-06-10', 'YYYY-MM-DD'), TO_DATE('2025-10-31', 'YYYY-MM-DD'));
INSERT INTO Service_Desk_Coordination (SDC_ID, CSCSIT_ID, Team_Leader_ID, Request_Description, Request_Date, Assigned_To_ID, Priority_Request, Resolution_Date, Solution_Description, Escalation_Level, Status_Update_Date, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (5, 12, 303, 'Printer not working', TO_DATE('2025-06-15', 'YYYY-MM-DD'), 805, 'Medium', TO_DATE('2025-06-16', 'YYYY-MM-DD'), 'Reinstalled printer drivers', 'L2', TO_DATE('2025-06-16', 'YYYY-MM-DD'), 5, 'Inactive', TO_DATE('2025-06-14', 'YYYY-MM-DD'), TO_DATE('2025-11-30', 'YYYY-MM-DD'));

INSERT INTO HR_Department (HR_ID, Team_Leader_ID, Department_Location, Focus_Area, Status, Project_Start_Date, Project_End_Date)
VALUES (13, 308, 'Bucuresti, Romania', 'Talent Acquisition and Employee Engagement', 'Active', TO_DATE('2025-01-10', 'YYYY-MM-DD'), TO_DATE('2025-12-31', 'YYYY-MM-DD'));

INSERT INTO Tech_Talent_Acquisition (TTA_ID, HR_ID, Team_Leader_ID, Role_Type, Open_Positions, Filled_Positions, Recruitment_Stage, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 13, 309, 'Software Engineer', 10, 4, 'Interviewing', 5, 'Active', TO_DATE('2025-01-01', 'YYYY-MM-DD'), TO_DATE('2025-06-30', 'YYYY-MM-DD'));
INSERT INTO Tech_Talent_Acquisition (TTA_ID, HR_ID, Team_Leader_ID, Role_Type, Open_Positions, Filled_Positions, Recruitment_Stage, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 13, 309, 'Data Scientist', 5, 2, 'Sourcing', 5, 'Pending', TO_DATE('2025-02-15', 'YYYY-MM-DD'), TO_DATE('2025-08-31', 'YYYY-MM-DD'));
INSERT INTO Tech_Talent_Acquisition (TTA_ID, HR_ID, Team_Leader_ID, Role_Type, Open_Positions, Filled_Positions, Recruitment_Stage, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 13, 309, 'DevOps Engineer', 7, 5, 'Offer Extended', 5, 'Active', TO_DATE('2025-03-01', 'YYYY-MM-DD'), TO_DATE('2025-09-30', 'YYYY-MM-DD'));
INSERT INTO Tech_Talent_Acquisition (TTA_ID, HR_ID, Team_Leader_ID, Role_Type, Open_Positions, Filled_Positions, Recruitment_Stage, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 13, 309, 'QA Analyst', 6, 3, 'Screening', 5, 'Active', TO_DATE('2025-01-20', 'YYYY-MM-DD'), TO_DATE('2025-07-31', 'YYYY-MM-DD'));
INSERT INTO Tech_Talent_Acquisition (TTA_ID, HR_ID, Team_Leader_ID, Role_Type, Open_Positions, Filled_Positions, Recruitment_Stage, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 13, 309, 'Product Manager', 2, 1, 'Offer Accepted', 5, 'Pending', TO_DATE('2025-04-01', 'YYYY-MM-DD'), TO_DATE('2025-10-31', 'YYYY-MM-DD'));

INSERT INTO Employer_Branding (EB_ID, HR_ID, Team_Leader_ID, Campaign_Name, Channels_Used, Target_Audience, Campaign_Start_Date, Campaign_End_Date, Budget, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 13, 314, 'Tech Talent Drive', 'LinkedIn, Twitter, Facebook', 'Software Engineers, Developers', TO_DATE('2025-01-10', 'YYYY-MM-DD'), TO_DATE('2025-03-10', 'YYYY-MM-DD'), 15000, 5, 'Active', TO_DATE('2025-01-01', 'YYYY-MM-DD'), TO_DATE('2025-04-01', 'YYYY-MM-DD'));
INSERT INTO Employer_Branding (EB_ID, HR_ID, Team_Leader_ID, Campaign_Name, Channels_Used, Target_Audience, Campaign_Start_Date, Campaign_End_Date, Budget, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 13, 314, 'Diversity Hiring Campaign', 'Instagram, LinkedIn', 'Underrepresented Groups in Tech', TO_DATE('2025-02-01', 'YYYY-MM-DD'), TO_DATE('2025-05-01', 'YYYY-MM-DD'), 12000, 5, 'Pending', TO_DATE('2025-01-20', 'YYYY-MM-DD'), TO_DATE('2025-05-15', 'YYYY-MM-DD'));
INSERT INTO Employer_Branding (EB_ID, HR_ID, Team_Leader_ID, Campaign_Name, Channels_Used, Target_Audience, Campaign_Start_Date, Campaign_End_Date, Budget, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 13, 314, 'University Outreach', 'Campus Events, Facebook', 'Students and Graduates', TO_DATE('2025-03-15', 'YYYY-MM-DD'), TO_DATE('2025-06-15', 'YYYY-MM-DD'), 8000, 5, 'Active', TO_DATE('2025-03-01', 'YYYY-MM-DD'), TO_DATE('2025-07-01', 'YYYY-MM-DD'));
INSERT INTO Employer_Branding (EB_ID, HR_ID, Team_Leader_ID, Campaign_Name, Channels_Used, Target_Audience, Campaign_Start_Date, Campaign_End_Date, Budget, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 13, 314, 'Remote Work Benefits', 'LinkedIn, Company Blog', 'Remote Job Seekers', TO_DATE('2025-04-01', 'YYYY-MM-DD'), TO_DATE('2025-07-01', 'YYYY-MM-DD'), 10000, 5, 'Active', TO_DATE('2025-03-20', 'YYYY-MM-DD'), TO_DATE('2025-07-15', 'YYYY-MM-DD'));
INSERT INTO Employer_Branding (EB_ID, HR_ID, Team_Leader_ID, Campaign_Name, Channels_Used, Target_Audience, Campaign_Start_Date, Campaign_End_Date, Budget, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 13, 314, 'Tech Conference Sponsorship', 'Conferences, Twitter', 'IT Professionals, Developers', TO_DATE('2025-05-01', 'YYYY-MM-DD'), TO_DATE('2025-08-01', 'YYYY-MM-DD'), 20000, 5, 'Pending', TO_DATE('2025-04-25', 'YYYY-MM-DD'), TO_DATE('2025-08-30', 'YYYY-MM-DD'));

INSERT INTO HR_Analytics (HR_Analytics_ID, HR_ID, Team_Leader_ID, Metric_Name, Metric_Value, Measured_Period, Last_Updated, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 13, 319, 'Employee Retention Rate', 85, 'Q1 2025', TO_DATE('2025-03-31', 'YYYY-MM-DD'), 5, 'Active', TO_DATE('2025-01-01', 'YYYY-MM-DD'), TO_DATE('2025-06-30', 'YYYY-MM-DD'));
INSERT INTO HR_Analytics (HR_Analytics_ID, HR_ID, Team_Leader_ID, Metric_Name, Metric_Value, Measured_Period, Last_Updated, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 13, 319, 'Time to Hire', 30, 'Q1 2025', TO_DATE('2025-03-31', 'YYYY-MM-DD'), 4, 'Active', TO_DATE('2025-01-01', 'YYYY-MM-DD'), TO_DATE('2025-06-30', 'YYYY-MM-DD'));
INSERT INTO HR_Analytics (HR_Analytics_ID, HR_ID, Team_Leader_ID, Metric_Name, Metric_Value, Measured_Period, Last_Updated, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 13, 319, 'Training Completion Rate', 90, 'Q1 2025', TO_DATE('2025-03-31', 'YYYY-MM-DD'), 6, 'Active', TO_DATE('2025-01-01', 'YYYY-MM-DD'), TO_DATE('2025-06-30', 'YYYY-MM-DD'));
INSERT INTO HR_Analytics (HR_Analytics_ID, HR_ID, Team_Leader_ID, Metric_Name, Metric_Value, Measured_Period, Last_Updated, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 13, 319, 'Offer Acceptance Rate', 75, 'Q1 2025', TO_DATE('2025-03-31', 'YYYY-MM-DD'), 3, 'Pending', TO_DATE('2025-01-01', 'YYYY-MM-DD'), TO_DATE('2025-06-30', 'YYYY-MM-DD'));
INSERT INTO HR_Analytics (HR_Analytics_ID, HR_ID, Team_Leader_ID, Metric_Name, Metric_Value, Measured_Period, Last_Updated, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 13, 319, 'Diversity Hiring Percentage', 40, 'Q1 2025', TO_DATE('2025-03-31', 'YYYY-MM-DD'), 4, 'Active', TO_DATE('2025-01-01', 'YYYY-MM-DD'), TO_DATE('2025-06-30', 'YYYY-MM-DD'));

INSERT INTO Onboarding_Orientation 
(Onboarding_ID, HR_ID, Team_Leader_ID, New_Employee_ID, Orientation_Completed, Mentor_Assigned, Feedback_Received, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 13, 324, 801, 'Yes', 'John Smith', 'Positive', 5, 'Active', TO_DATE('2025-01-05', 'YYYY-MM-DD'), TO_DATE('2025-01-20', 'YYYY-MM-DD'));
INSERT INTO Onboarding_Orientation 
(Onboarding_ID, HR_ID, Team_Leader_ID, New_Employee_ID, Orientation_Completed, Mentor_Assigned, Feedback_Received, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 13, 324, 802, 'No', 'Lisa Brown', 'Pending', 5, 'Pending', TO_DATE('2025-02-01', 'YYYY-MM-DD'), TO_DATE('2025-02-15', 'YYYY-MM-DD'));
INSERT INTO Onboarding_Orientation 
(Onboarding_ID, HR_ID, Team_Leader_ID, New_Employee_ID, Orientation_Completed, Mentor_Assigned, Feedback_Received, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 13, 324, 803, 'Yes', 'Michael Lee', 'Very helpful', 5, 'Active', TO_DATE('2025-03-10', 'YYYY-MM-DD'), TO_DATE('2025-03-25', 'YYYY-MM-DD'));
INSERT INTO Onboarding_Orientation 
(Onboarding_ID, HR_ID, Team_Leader_ID, New_Employee_ID, Orientation_Completed, Mentor_Assigned, Feedback_Received, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 13, 324, 804, 'No', 'Anna Davis', 'No feedback yet', 5, 'Inactive', TO_DATE('2025-04-01', 'YYYY-MM-DD'), TO_DATE('2025-04-20', 'YYYY-MM-DD'));
INSERT INTO Onboarding_Orientation 
(Onboarding_ID, HR_ID, Team_Leader_ID, New_Employee_ID, Orientation_Completed, Mentor_Assigned, Feedback_Received, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 13, 324, 805, 'Yes', 'James Wilson', 'Excellent orientation', 5, 'Active', TO_DATE('2025-05-10', 'YYYY-MM-DD'), TO_DATE('2025-05-25', 'YYYY-MM-DD'));

INSERT INTO Learning_Development
(LD_ID, HR_ID, Team_Leader_ID, Training_Name, Target_Group, Trainer_Name, Training_End_Date, Training_Type, Participants, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 13, 329, 'Leadership Essentials', 'Managers', 'Susan Clark', TO_DATE('2025-07-15', 'YYYY-MM-DD'), 'Workshop', 20, 5, 'Active', TO_DATE('2025-06-01', 'YYYY-MM-DD'), TO_DATE('2025-07-15', 'YYYY-MM-DD'));
INSERT INTO Learning_Development
(LD_ID, HR_ID, Team_Leader_ID, Training_Name, Target_Group, Trainer_Name, Training_End_Date, Training_Type, Participants, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 13, 329, 'Effective Communication', 'All Employees', 'Mark Thompson', TO_DATE('2025-08-10', 'YYYY-MM-DD'), 'Online Course', 50, 5, 'Pending', TO_DATE('2025-07-01', 'YYYY-MM-DD'), TO_DATE('2025-08-10', 'YYYY-MM-DD'));
INSERT INTO Learning_Development
(LD_ID, HR_ID, Team_Leader_ID, Training_Name, Target_Group, Trainer_Name, Training_End_Date, Training_Type, Participants, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 13, 329, 'Time Management', 'Team Leads', 'Emily Johnson', TO_DATE('2025-09-05', 'YYYY-MM-DD'), 'Seminar', 15, 5, 'Inactive', TO_DATE('2025-08-01', 'YYYY-MM-DD'), TO_DATE('2025-09-05', 'YYYY-MM-DD'));
INSERT INTO Learning_Development
(LD_ID, HR_ID, Team_Leader_ID, Training_Name, Target_Group, Trainer_Name, Training_End_Date, Training_Type, Participants, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 13, 329, 'Technical Skills Upgrade', 'Developers', 'James Lee', TO_DATE('2025-10-20', 'YYYY-MM-DD'), 'Bootcamp', 30, 5, 'Active', TO_DATE('2025-09-01', 'YYYY-MM-DD'), TO_DATE('2025-10-20', 'YYYY-MM-DD'));
INSERT INTO Learning_Development
(LD_ID, HR_ID, Team_Leader_ID, Training_Name, Target_Group, Trainer_Name, Training_End_Date, Training_Type, Participants, Team_Size, Status, Project_Start_Date, Project_End_Date)
VALUES (5, 13, 329, 'Customer Service Excellence', 'Support Staff', 'Laura Smith', TO_DATE('2025-11-15', 'YYYY-MM-DD'), 'Workshop', 25, 5, 'Active', TO_DATE('2025-10-01', 'YYYY-MM-DD'), TO_DATE('2025-11-15', 'YYYY-MM-DD'));

INSERT INTO Performance_Management
(PM_ID, HR_ID, Team_Leader_ID, Employee_ID, Review_Period, Score, Reviewer_ID, Feedback_Summary, Next_Steps, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 13, 334, 335, '2024 Q4', 85, 901, 'Consistent performance with strong teamwork.', 'Focus on leadership skills', 5, 'Active', TO_DATE('2025-01-01', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD'));
INSERT INTO Performance_Management
(PM_ID, HR_ID, Team_Leader_ID, Employee_ID, Review_Period, Score, Reviewer_ID, Feedback_Summary, Next_Steps, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 13, 334, 336, '2025 Q1', 90, 902, 'Exceeded expectations in project delivery.', 'Lead upcoming projects', 5, 'Active', TO_DATE('2025-04-01', 'YYYY-MM-DD'), TO_DATE('2025-04-30', 'YYYY-MM-DD'));
INSERT INTO Performance_Management
(PM_ID, HR_ID, Team_Leader_ID, Employee_ID, Review_Period, Score, Reviewer_ID, Feedback_Summary, Next_Steps, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 13, 334, 337, '2024 Q3', 78, 903, 'Needs improvement in time management.', 'Attend time management training', 5, 'Pending', TO_DATE('2024-10-01', 'YYYY-MM-DD'), TO_DATE('2024-10-31', 'YYYY-MM-DD'));
INSERT INTO Performance_Management
(PM_ID, HR_ID, Team_Leader_ID, Employee_ID, Review_Period, Score, Reviewer_ID, Feedback_Summary, Next_Steps, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 13, 334, 338, '2025 Q2', 92, 904, 'Outstanding contribution to team goals.', 'Mentor junior staff', 5, 'Active', TO_DATE('2025-07-01', 'YYYY-MM-DD'), TO_DATE('2025-07-31', 'YYYY-MM-DD'));
INSERT INTO Performance_Management
(PM_ID, HR_ID, Team_Leader_ID, Employee_ID, Review_Period, Score, Reviewer_ID, Feedback_Summary, Next_Steps, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 13, 334, 339, '2024 Q4', 80, 905, 'Good performance but needs more initiative.', 'Increase proactive involvement', 5, 'Inactive', TO_DATE('2025-01-01', 'YYYY-MM-DD'), TO_DATE('2025-01-31', 'YYYY-MM-DD'));

INSERT INTO Sales_Presales_IT (SP_IT_ID, Team_Leader_ID, Region, Status, Project_Start_Date, Project_End_Date) 
VALUES (14, 335, 'Europe', 'Active', TO_DATE('2025-05-01', 'YYYY-MM-DD'), TO_DATE('2026-04-30', 'YYYY-MM-DD'));

INSERT INTO Presales_Engineering (
    PE_ID, SP_IT_ID, Team_Leader_ID, Engineer_Name, Domain_Expertise, Certifications, Demo_Environment_Used, POC_Involvement_Level, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES(1, 14, 336, 'Andrei Popescu', 'Cloud Solutions', 'AWS Certified Solutions Architect', 'AWS Console', 'High', 5, 'Active', TO_DATE('2025-05-10', 'YYYY-MM-DD'), TO_DATE('2026-05-09', 'YYYY-MM-DD'));
INSERT INTO Presales_Engineering (
    PE_ID, SP_IT_ID, Team_Leader_ID, Engineer_Name, Domain_Expertise, Certifications, Demo_Environment_Used, POC_Involvement_Level, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES(2, 14, 336, 'Maria Ionescu', 'Cybersecurity', 'CISSP, CEH', 'Kali Linux', 'Medium', 5, 'Active', TO_DATE('2025-06-01', 'YYYY-MM-DD'), TO_DATE('2026-06-01', 'YYYY-MM-DD'));
INSERT INTO Presales_Engineering (
    PE_ID, SP_IT_ID, Team_Leader_ID, Engineer_Name, Domain_Expertise, Certifications, Demo_Environment_Used, POC_Involvement_Level, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES(3, 14, 336, 'George Stan', 'DevOps', 'Docker Certified Associate', 'Jenkins', 'High', 5, 'Pending', TO_DATE('2025-07-01', 'YYYY-MM-DD'), TO_DATE('2026-07-01', 'YYYY-MM-DD'));
INSERT INTO Presales_Engineering (
    PE_ID, SP_IT_ID, Team_Leader_ID, Engineer_Name, Domain_Expertise, Certifications, Demo_Environment_Used, POC_Involvement_Level, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES(4, 14, 336, 'Elena Vasilescu', 'Data Analytics', 'Google Data Analytics Certificate', 'Tableau', 'Low', 5, 'Inactive', TO_DATE('2025-08-01', 'YYYY-MM-DD'), TO_DATE('2026-08-01', 'YYYY-MM-DD'));
INSERT INTO Presales_Engineering (
    PE_ID, SP_IT_ID, Team_Leader_ID, Engineer_Name, Domain_Expertise, Certifications, Demo_Environment_Used, POC_Involvement_Level, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES(5, 14, 336, 'Radu Marinescu', 'Networking', 'CCNA, CCNP', 'Cisco Packet Tracer', 'Medium', 5, 'Active', TO_DATE('2025-09-01', 'YYYY-MM-DD'), TO_DATE('2026-09-01', 'YYYY-MM-DD'));

INSERT INTO Technical_Account_Management (
    TAM_ID, SP_IT_ID, Team_Leader_ID, Account_Manager_Name, Client_Name, Engagement_Level, Contract_Term, Support_Coverage, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES(1, 14, 341, 'Ioana Popa', 'TechCorp Solutions', 'High', '12 months', '24/7 Global Support', 5, 'Active', TO_DATE('2025-04-15', 'YYYY-MM-DD'), TO_DATE('2026-04-14', 'YYYY-MM-DD'));
INSERT INTO Technical_Account_Management (
    TAM_ID, SP_IT_ID, Team_Leader_ID, Account_Manager_Name, Client_Name, Engagement_Level, Contract_Term, Support_Coverage, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES(2, 14, 341, 'Mihai Radu', 'DataAnalytics Inc.', 'Medium', '6 months', 'Business Hours Support', 5, 'Active', TO_DATE('2025-05-01', 'YYYY-MM-DD'), TO_DATE('2025-10-31', 'YYYY-MM-DD'));
INSERT INTO Technical_Account_Management (
    TAM_ID, SP_IT_ID, Team_Leader_ID, Account_Manager_Name, Client_Name, Engagement_Level, Contract_Term, Support_Coverage, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES(3, 14, 341, 'Adriana Georgescu', 'NetSecure Ltd.', 'High', '24 months', '24/7 Priority Support', 5, 'Pending', TO_DATE('2025-06-10', 'YYYY-MM-DD'), TO_DATE('2027-06-09', 'YYYY-MM-DD'));
INSERT INTO Technical_Account_Management (
    TAM_ID, SP_IT_ID, Team_Leader_ID, Account_Manager_Name, Client_Name, Engagement_Level, Contract_Term, Support_Coverage, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES(4, 14, 341, 'Cristian Matei', 'CloudWave', 'Low', '3 months', 'Email Support', 5, 'Inactive', TO_DATE('2025-07-01', 'YYYY-MM-DD'), TO_DATE('2025-09-30', 'YYYY-MM-DD'));
INSERT INTO Technical_Account_Management (
    TAM_ID, SP_IT_ID, Team_Leader_ID, Account_Manager_Name, Client_Name, Engagement_Level, Contract_Term, Support_Coverage, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES(5, 14, 341, 'Simona Ene', 'Innovatech', 'Medium', '12 months', 'Business Hours Support', 5, 'Active', TO_DATE('2025-08-15', 'YYYY-MM-DD'), TO_DATE('2026-08-14', 'YYYY-MM-DD'));

INSERT INTO Bid_Proposal_Management (
    BM_PM_ID, SP_IT_ID, Team_Leader_ID, Bid_Name, Client_Name, Deadline, Document_Link, Bid_Status, Estimated_Value, Team_Involved, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES(1, 14, 351, 'Cloud Migration Project', 'TechCorp Solutions', TO_DATE('2025-07-15', 'YYYY-MM-DD'), 'http://docs.techcorp.com/bids/cloud_migration.pdf', 'Submitted', 500000, 'Cloud Team, Sales Team', 5, 'Active', TO_DATE('2025-05-01', 'YYYY-MM-DD'), TO_DATE('2025-07-20', 'YYYY-MM-DD'));
INSERT INTO Bid_Proposal_Management (
    BM_PM_ID, SP_IT_ID, Team_Leader_ID, Bid_Name, Client_Name, Deadline, Document_Link, Bid_Status, Estimated_Value, Team_Involved, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES(2, 14, 351, 'AI Integration Proposal', 'DataAnalytics Inc.', TO_DATE('2025-08-01', 'YYYY-MM-DD'), 'http://docs.dataanalytics.com/bids/ai_integration.pdf', 'Draft', 350000, 'AI Team, Engineering', 5, 'Pending', TO_DATE('2025-06-01', 'YYYY-MM-DD'), TO_DATE('2025-08-05', 'YYYY-MM-DD'));
INSERT INTO Bid_Proposal_Management (
    BM_PM_ID, SP_IT_ID, Team_Leader_ID, Bid_Name, Client_Name, Deadline, Document_Link, Bid_Status, Estimated_Value, Team_Involved, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES(3, 14, 351, 'Network Security Upgrade', 'NetSecure Ltd.', TO_DATE('2025-09-10', 'YYYY-MM-DD'), 'http://docs.netsecure.com/bids/security_upgrade.pdf', 'Approved', 450000, 'Security Team, Sales Team', 5, 'Active', TO_DATE('2025-07-15', 'YYYY-MM-DD'), TO_DATE('2025-09-15', 'YYYY-MM-DD'));
INSERT INTO Bid_Proposal_Management (
    BM_PM_ID, SP_IT_ID, Team_Leader_ID, Bid_Name, Client_Name, Deadline, Document_Link, Bid_Status, Estimated_Value, Team_Involved, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES(4, 14, 351, 'Cloud Cost Optimization', 'CloudWave', TO_DATE('2025-06-20', 'YYYY-MM-DD'), 'http://docs.cloudwave.com/bids/cost_optimization.pdf', 'Rejected', 200000, 'Finance Team, Cloud Team', 5, 'Inactive', TO_DATE('2025-04-15', 'YYYY-MM-DD'), TO_DATE('2025-06-25', 'YYYY-MM-DD'));
INSERT INTO Bid_Proposal_Management (
    BM_PM_ID, SP_IT_ID, Team_Leader_ID, Bid_Name, Client_Name, Deadline, Document_Link, Bid_Status, Estimated_Value, Team_Involved, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES(5, 14, 351, 'Innovative Tech Solutions', 'Innovatech', TO_DATE('2025-10-05', 'YYYY-MM-DD'), 'http://docs.innovatech.com/bids/innovative_solutions.pdf', 'Submitted', 600000, 'Engineering, Sales', 5, 'Active', TO_DATE('2025-08-01', 'YYYY-MM-DD'), TO_DATE('2025-10-10', 'YYYY-MM-DD'));

INSERT INTO Sales_Training (
    SETrain_ID, SP_IT_ID, Team_Leader_ID, Training_Name, Target_Audience, Training_Date, Duration_Hours, Trainer_Name, Materials_Link, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES(1, 14, 356, 'Advanced Sales Techniques', 'Sales Team', TO_DATE('2025-07-10', 'YYYY-MM-DD'), 6, 'John Smith', 'http://training.techcorp.com/sales/adv_tech.pdf', 5, 'Active', TO_DATE('2025-06-01', 'YYYY-MM-DD'), TO_DATE('2025-07-11', 'YYYY-MM-DD'));
INSERT INTO Sales_Training (
    SETrain_ID, SP_IT_ID, Team_Leader_ID, Training_Name, Target_Audience, Training_Date, Duration_Hours, Trainer_Name, Materials_Link, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES(2, 14, 356, 'Cloud Solutions Selling', 'Presales Engineers', TO_DATE('2025-08-15', 'YYYY-MM-DD'), 8, 'Alice Johnson', 'http://training.techcorp.com/sales/cloud_selling.pdf', 5, 'Pending', TO_DATE('2025-07-01', 'YYYY-MM-DD'), TO_DATE('2025-08-16', 'YYYY-MM-DD'));
INSERT INTO Sales_Training (
    SETrain_ID, SP_IT_ID, Team_Leader_ID, Training_Name, Target_Audience, Training_Date, Duration_Hours, Trainer_Name, Materials_Link, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES(3, 14, 356, 'Customer Relationship Management', 'Account Managers', TO_DATE('2025-09-05', 'YYYY-MM-DD'), 4, 'David Lee', 'http://training.techcorp.com/sales/crm.pdf', 5, 'Active', TO_DATE('2025-08-01', 'YYYY-MM-DD'), TO_DATE('2025-09-06', 'YYYY-MM-DD'));
INSERT INTO Sales_Training (
    SETrain_ID, SP_IT_ID, Team_Leader_ID, Training_Name, Target_Audience, Training_Date, Duration_Hours, Trainer_Name, Materials_Link, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES(4, 14, 356, 'Negotiation Skills', 'Sales & Presales Teams', TO_DATE('2025-06-20', 'YYYY-MM-DD'), 5, 'Emma Brown', 'http://training.techcorp.com/sales/negotiation.pdf', 5, 'Inactive', TO_DATE('2025-05-01', 'YYYY-MM-DD'), TO_DATE('2025-06-21', 'YYYY-MM-DD'));
INSERT INTO Sales_Training (
    SETrain_ID, SP_IT_ID, Team_Leader_ID, Training_Name, Target_Audience, Training_Date, Duration_Hours, Trainer_Name, Materials_Link, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES(5, 14, 356, 'Product Knowledge Workshop', 'Sales Team', TO_DATE('2025-10-10', 'YYYY-MM-DD'), 7, 'Michael Green', 'http://training.techcorp.com/sales/product_knowledge.pdf', 5, 'Active', TO_DATE('2025-09-01', 'YYYY-MM-DD'), TO_DATE('2025-10-11', 'YYYY-MM-DD'));

INSERT INTO Key_Account_Management (
    KAM_ID, SP_IT_ID, Team_Leader_ID, Client_Name, Account_Manager_ID, Contract_Value, Contract_Date, Partnership_Status, Notes, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES(1, 14, 361, 'Acme Corporation', 805, 1500000, TO_DATE('2025-01-15', 'YYYY-MM-DD'), 'Active', 'Priority client', 5, 'Active', TO_DATE('2025-01-01', 'YYYY-MM-DD'), TO_DATE('2025-12-31', 'YYYY-MM-DD'));
INSERT INTO Key_Account_Management (
    KAM_ID, SP_IT_ID, Team_Leader_ID, Client_Name, Account_Manager_ID, Contract_Value, Contract_Date, Partnership_Status, Notes, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES(2, 14, 361, 'Beta Industries', 804, 1200000, TO_DATE('2025-02-20', 'YYYY-MM-DD'), 'Pending', 'Contract under review', 5, 'Pending', TO_DATE('2025-02-01', 'YYYY-MM-DD'), TO_DATE('2025-11-30', 'YYYY-MM-DD'));
INSERT INTO Key_Account_Management (
    KAM_ID, SP_IT_ID, Team_Leader_ID, Client_Name, Account_Manager_ID, Contract_Value, Contract_Date, Partnership_Status, Notes, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES(3, 14, 361, 'Gamma Solutions', 803, 1800000, TO_DATE('2025-03-10', 'YYYY-MM-DD'), 'Active', 'Long-term partner', 5, 'Active', TO_DATE('2025-03-01', 'YYYY-MM-DD'), TO_DATE('2026-02-28', 'YYYY-MM-DD'));
INSERT INTO Key_Account_Management (
    KAM_ID, SP_IT_ID, Team_Leader_ID, Client_Name, Account_Manager_ID, Contract_Value, Contract_Date, Partnership_Status, Notes, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES(4, 14, 361, 'Delta Enterprises', 802, 900000, TO_DATE('2025-04-05', 'YYYY-MM-DD'), 'Inactive', 'Awaiting renewal', 5, 'Inactive', TO_DATE('2025-04-01', 'YYYY-MM-DD'), TO_DATE('2025-09-30', 'YYYY-MM-DD'));
INSERT INTO Key_Account_Management (
    KAM_ID, SP_IT_ID, Team_Leader_ID, Client_Name, Account_Manager_ID, Contract_Value, Contract_Date, Partnership_Status, Notes, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES(5, 14, 361, 'Epsilon Ltd.', 801, 1350000, TO_DATE('2025-05-25', 'YYYY-MM-DD'), 'Active', 'Expanding contract', 5, 'Active', TO_DATE('2025-05-01', 'YYYY-MM-DD'), TO_DATE('2026-04-30', 'YYYY-MM-DD'));

INSERT INTO Inside_Sales (
    Inside_Sales_ID, SP_IT_ID, Team_Leader_ID, Region, Sales_Target_QTR, Current_Performance, Contacts_Handled, Partnership_Status, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES(1, 14, 366, 'North America', 500000, 450000, 120, 'Active', 5, 'Active', TO_DATE('2025-01-01', 'YYYY-MM-DD'), TO_DATE('2025-03-31', 'YYYY-MM-DD'));
INSERT INTO Inside_Sales (
    Inside_Sales_ID, SP_IT_ID, Team_Leader_ID, Region, Sales_Target_QTR, Current_Performance, Contacts_Handled, Partnership_Status, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES(2, 14, 366, 'Europe', 400000, 380000, 110, 'Pending', 5, 'Pending', TO_DATE('2025-01-01', 'YYYY-MM-DD'), TO_DATE('2025-03-31', 'YYYY-MM-DD'));
INSERT INTO Inside_Sales (
    Inside_Sales_ID, SP_IT_ID, Team_Leader_ID, Region, Sales_Target_QTR, Current_Performance, Contacts_Handled, Partnership_Status, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES(3, 14, 366, 'Asia-Pacific', 600000, 590000, 150, 'Active', 5, 'Active', TO_DATE('2025-01-01', 'YYYY-MM-DD'), TO_DATE('2025-03-31', 'YYYY-MM-DD'));
INSERT INTO Inside_Sales (
    Inside_Sales_ID, SP_IT_ID, Team_Leader_ID, Region, Sales_Target_QTR, Current_Performance, Contacts_Handled, Partnership_Status, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES(4, 14, 366, 'Latin America', 300000, 250000, 90, 'Inactive', 5, 'Inactive', TO_DATE('2025-01-01', 'YYYY-MM-DD'), TO_DATE('2025-03-31', 'YYYY-MM-DD'));
INSERT INTO Inside_Sales (
    Inside_Sales_ID, SP_IT_ID, Team_Leader_ID, Region, Sales_Target_QTR, Current_Performance, Contacts_Handled, Partnership_Status, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES(5, 14, 366, 'Middle East', 350000, 340000, 100, 'Active', 5, 'Active', TO_DATE('2025-01-01', 'YYYY-MM-DD'), TO_DATE('2025-03-31', 'YYYY-MM-DD'));

INSERT INTO Marketing_Tech_Digital_Marketing (MTDM_ID, Team_Leader_ID, Status, Project_Start_Date, Project_End_Date) 
VALUES (15, 367, 'Active', TO_DATE('2025-06-01', 'YYYY-MM-DD'), TO_DATE('2025-12-31', 'YYYY-MM-DD'));

INSERT INTO Digital_Advertising (DA_ID, MTDM_ID, Team_Leader_ID, Platform, Ad_Type, Budget_Allocated, Campaign_Start_Date, Campaign_End_Date, Ad_Views, Clicks, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 15, 368, 'Google Ads', 'Search', 15000, TO_DATE('2025-01-01', 'YYYY-MM-DD'), TO_DATE('2025-03-31', 'YYYY-MM-DD'), 1200000, 50000, 5, 'Active', TO_DATE('2025-01-01', 'YYYY-MM-DD'), TO_DATE('2025-03-31', 'YYYY-MM-DD'));
INSERT INTO Digital_Advertising (DA_ID, MTDM_ID, Team_Leader_ID, Platform, Ad_Type, Budget_Allocated, Campaign_Start_Date, Campaign_End_Date, Ad_Views, Clicks, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 15, 368, 'Facebook Ads', 'Social Media', 10000, TO_DATE('2025-02-01', 'YYYY-MM-DD'), TO_DATE('2025-04-30', 'YYYY-MM-DD'), 900000, 40000, 5, 'Active', TO_DATE('2025-02-01', 'YYYY-MM-DD'), TO_DATE('2025-04-30', 'YYYY-MM-DD'));
INSERT INTO Digital_Advertising (DA_ID, MTDM_ID, Team_Leader_ID, Platform, Ad_Type, Budget_Allocated, Campaign_Start_Date, Campaign_End_Date, Ad_Views, Clicks, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 15, 368, 'LinkedIn Ads', 'B2B', 12000, TO_DATE('2025-03-01', 'YYYY-MM-DD'), TO_DATE('2025-05-31', 'YYYY-MM-DD'), 500000, 20000, 5, 'Pending', TO_DATE('2025-03-01', 'YYYY-MM-DD'), TO_DATE('2025-05-31', 'YYYY-MM-DD'));
INSERT INTO Digital_Advertising (DA_ID, MTDM_ID, Team_Leader_ID, Platform, Ad_Type, Budget_Allocated, Campaign_Start_Date, Campaign_End_Date, Ad_Views, Clicks, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 15, 368, 'Instagram Ads', 'Social Media', 8000, TO_DATE('2025-04-01', 'YYYY-MM-DD'), TO_DATE('2025-06-30', 'YYYY-MM-DD'), 700000, 25000, 5, 'Active', TO_DATE('2025-04-01', 'YYYY-MM-DD'), TO_DATE('2025-06-30', 'YYYY-MM-DD'));
INSERT INTO Digital_Advertising (DA_ID, MTDM_ID, Team_Leader_ID, Platform, Ad_Type, Budget_Allocated, Campaign_Start_Date, Campaign_End_Date, Ad_Views, Clicks, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 15, 368, 'YouTube Ads', 'Video', 20000, TO_DATE('2025-05-01', 'YYYY-MM-DD'), TO_DATE('2025-07-31', 'YYYY-MM-DD'), 1300000, 60000, 5, 'Inactive', TO_DATE('2025-05-01', 'YYYY-MM-DD'), TO_DATE('2025-07-31', 'YYYY-MM-DD'));

INSERT INTO SEO (SEO_ID, MTDM_ID, Team_Leader_ID, Target_Keywords, Organic_Traffic, Backlinks, Domain_Authority, Last_Audit_Date, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 15, 373, 'cloud computing, SaaS, AI', 50000, 150, 70, TO_DATE('2025-05-01', 'YYYY-MM-DD'), 5, 'Active', TO_DATE('2025-01-01', 'YYYY-MM-DD'), TO_DATE('2025-12-31', 'YYYY-MM-DD'));
INSERT INTO SEO (SEO_ID, MTDM_ID, Team_Leader_ID, Target_Keywords, Organic_Traffic, Backlinks, Domain_Authority, Last_Audit_Date, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 15, 373, 'cybersecurity, network security', 40000, 120, 65, TO_DATE('2025-04-15', 'YYYY-MM-DD'), 5, 'Pending', TO_DATE('2025-02-01', 'YYYY-MM-DD'), TO_DATE('2025-11-30', 'YYYY-MM-DD'));
INSERT INTO SEO (SEO_ID, MTDM_ID, Team_Leader_ID, Target_Keywords, Organic_Traffic, Backlinks, Domain_Authority, Last_Audit_Date, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 15, 373, 'big data, analytics, machine learning', 55000, 180, 75, TO_DATE('2025-06-10', 'YYYY-MM-DD'), 5, 'Active', TO_DATE('2025-03-01', 'YYYY-MM-DD'), TO_DATE('2025-12-01', 'YYYY-MM-DD'));
INSERT INTO SEO (SEO_ID, MTDM_ID, Team_Leader_ID, Target_Keywords, Organic_Traffic, Backlinks, Domain_Authority, Last_Audit_Date, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 15, 373, 'digital marketing, SEO, PPC', 30000, 100, 60, TO_DATE('2025-05-20', 'YYYY-MM-DD'), 5, 'Inactive', TO_DATE('2025-01-15', 'YYYY-MM-DD'), TO_DATE('2025-09-30', 'YYYY-MM-DD'));
INSERT INTO SEO (SEO_ID, MTDM_ID, Team_Leader_ID, Target_Keywords, Organic_Traffic, Backlinks, Domain_Authority, Last_Audit_Date, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 15, 373, 'mobile apps, UX design, UI', 45000, 130, 68, TO_DATE('2025-06-01', 'YYYY-MM-DD'), 5, 'Active', TO_DATE('2025-04-01', 'YYYY-MM-DD'), TO_DATE('2025-10-31', 'YYYY-MM-DD'));

INSERT INTO Social_Media_Marketing (Social_Media_Marketing_ID, MTDM_ID, Team_Leader_ID, Platform, Campaign_Name, Post_Frequency, Engagement_Rate, Followers_Growth, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 15, 378, 'Facebook', 'Spring Product Launch', 'Daily', 5.6, 2000, 5, 'Active', TO_DATE('2025-02-01', 'YYYY-MM-DD'), TO_DATE('2025-05-31', 'YYYY-MM-DD'));
INSERT INTO Social_Media_Marketing (Social_Media_Marketing_ID, MTDM_ID, Team_Leader_ID, Platform, Campaign_Name, Post_Frequency, Engagement_Rate, Followers_Growth, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 15, 378, 'Instagram', 'Summer Deals Campaign', 'Weekly', 7.2, 1800, 5, 'Pending', TO_DATE('2025-03-01', 'YYYY-MM-DD'), TO_DATE('2025-06-30', 'YYYY-MM-DD'));
INSERT INTO Social_Media_Marketing (Social_Media_Marketing_ID, MTDM_ID, Team_Leader_ID, Platform, Campaign_Name, Post_Frequency, Engagement_Rate, Followers_Growth, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 15, 378, 'LinkedIn', 'B2B Awareness Drive', 'Twice a week', 6.5, 1500, 5, 'Active', TO_DATE('2025-01-15', 'YYYY-MM-DD'), TO_DATE('2025-07-15', 'YYYY-MM-DD'));
INSERT INTO Social_Media_Marketing (Social_Media_Marketing_ID, MTDM_ID, Team_Leader_ID, Platform, Campaign_Name, Post_Frequency, Engagement_Rate, Followers_Growth, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 15, 378, 'Twitter', 'Tech Trends Discussion', 'Daily', 4.8, 1200, 5, 'Inactive', TO_DATE('2025-04-01', 'YYYY-MM-DD'), TO_DATE('2025-09-30', 'YYYY-MM-DD'));
INSERT INTO Social_Media_Marketing (Social_Media_Marketing_ID, MTDM_ID, Team_Leader_ID, Platform, Campaign_Name, Post_Frequency, Engagement_Rate, Followers_Growth, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 15, 378, 'TikTok', 'Youth Engagement Campaign', 'Weekly', 8.1, 2500, 5, 'Active', TO_DATE('2025-05-01', 'YYYY-MM-DD'), TO_DATE('2025-10-31', 'YYYY-MM-DD'));

INSERT INTO Email_Marketing (Email_Marketing_ID, MTDM_ID, Team_Leader_ID, Campaign_Name, Email_Subject, Send_Date, Number_of_Recipients, Open_Rate, Click_Through_Rate, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 15, 383, 'New Product Announcement', 'Introducing Our Latest Innovation', TO_DATE('2025-03-10', 'YYYY-MM-DD'), 5000, 45.2, 10.5, 5, 'Active', TO_DATE('2025-03-01', 'YYYY-MM-DD'), TO_DATE('2025-03-31', 'YYYY-MM-DD'));
INSERT INTO Email_Marketing (Email_Marketing_ID, MTDM_ID, Team_Leader_ID, Campaign_Name, Email_Subject, Send_Date, Number_of_Recipients, Open_Rate, Click_Through_Rate, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 15, 383, 'Spring Sale', 'Spring Discounts Just for You!', TO_DATE('2025-04-15', 'YYYY-MM-DD'), 7000, 48.1, 12.3, 5, 'Pending', TO_DATE('2025-04-01', 'YYYY-MM-DD'), TO_DATE('2025-04-30', 'YYYY-MM-DD'));
INSERT INTO Email_Marketing (Email_Marketing_ID, MTDM_ID, Team_Leader_ID, Campaign_Name, Email_Subject, Send_Date, Number_of_Recipients, Open_Rate, Click_Through_Rate, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 15, 383, 'Customer Feedback Request', 'Help Us Improve Our Service', TO_DATE('2025-05-05', 'YYYY-MM-DD'), 3000, 40.7, 8.9, 5, 'Active', TO_DATE('2025-05-01', 'YYYY-MM-DD'), TO_DATE('2025-05-31', 'YYYY-MM-DD'));
INSERT INTO Email_Marketing (Email_Marketing_ID, MTDM_ID, Team_Leader_ID, Campaign_Name, Email_Subject, Send_Date, Number_of_Recipients, Open_Rate, Click_Through_Rate, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 15, 383, 'Webinar Invitation', 'Join Our Exclusive Webinar', TO_DATE('2025-06-20', 'YYYY-MM-DD'), 4000, 50.4, 15.2, 5, 'Inactive', TO_DATE('2025-06-01', 'YYYY-MM-DD'), TO_DATE('2025-06-30', 'YYYY-MM-DD'));
INSERT INTO Email_Marketing (Email_Marketing_ID, MTDM_ID, Team_Leader_ID, Campaign_Name, Email_Subject, Send_Date, Number_of_Recipients, Open_Rate, Click_Through_Rate, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 15, 383, 'End of Quarter Review', 'Q2 Highlights and Updates', TO_DATE('2025-07-10', 'YYYY-MM-DD'), 6000, 46.9, 11.7, 5, 'Active', TO_DATE('2025-07-01', 'YYYY-MM-DD'), TO_DATE('2025-07-31', 'YYYY-MM-DD'));

INSERT INTO Affiliate_Marketing (AM_ID, MTDM_ID, Team_Leader_ID, Affiliate_Name, Platform_Used, Commission_Rate, Total_Conversions, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 15, 388, 'AffiliateOne', 'YouTube', 7.5, 1200, 5, 'Active', TO_DATE('2025-02-01', 'YYYY-MM-DD'), TO_DATE('2025-08-01', 'YYYY-MM-DD'));
INSERT INTO Affiliate_Marketing (AM_ID, MTDM_ID, Team_Leader_ID, Affiliate_Name, Platform_Used, Commission_Rate, Total_Conversions, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 15, 388, 'BestPartners', 'Instagram', 8.0, 950, 5, 'Pending', TO_DATE('2025-03-15', 'YYYY-MM-DD'), TO_DATE('2025-09-15', 'YYYY-MM-DD'));
INSERT INTO Affiliate_Marketing (AM_ID, MTDM_ID, Team_Leader_ID, Affiliate_Name, Platform_Used, Commission_Rate, Total_Conversions, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 15, 388, 'TopAffiliates', 'Facebook', 6.5, 1100, 5, 'Active', TO_DATE('2025-04-10', 'YYYY-MM-DD'), TO_DATE('2025-10-10', 'YYYY-MM-DD'));
INSERT INTO Affiliate_Marketing (AM_ID, MTDM_ID, Team_Leader_ID, Affiliate_Name, Platform_Used, Commission_Rate, Total_Conversions, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 15, 388, 'SalesBoosters', 'TikTok', 9.0, 800, 5, 'Inactive', TO_DATE('2025-05-05', 'YYYY-MM-DD'), TO_DATE('2025-11-05', 'YYYY-MM-DD'));
INSERT INTO Affiliate_Marketing (AM_ID, MTDM_ID, Team_Leader_ID, Affiliate_Name, Platform_Used, Commission_Rate, Total_Conversions, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 15, 388, 'MarketGurus', 'Twitter', 7.8, 1300, 5, 'Active', TO_DATE('2025-06-20', 'YYYY-MM-DD'), TO_DATE('2025-12-20', 'YYYY-MM-DD'));

INSERT INTO Marketing_Automation (MA_ID, MTDM_ID, Team_Leader_ID, Platform_Used, Automated_Campaigns, Leads_Generated, Last_Updated_Date, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (1, 15, 393, 'HubSpot', 12, 850, TO_DATE('2025-05-01', 'YYYY-MM-DD'), 5, 'Active', TO_DATE('2025-01-01', 'YYYY-MM-DD'), TO_DATE('2025-12-31', 'YYYY-MM-DD'));
INSERT INTO Marketing_Automation (MA_ID, MTDM_ID, Team_Leader_ID, Platform_Used, Automated_Campaigns, Leads_Generated, Last_Updated_Date, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (2, 15, 393, 'Marketo', 8, 600, TO_DATE('2025-04-15', 'YYYY-MM-DD'), 5, 'Pending', TO_DATE('2025-02-01', 'YYYY-MM-DD'), TO_DATE('2025-11-30', 'YYYY-MM-DD'));
INSERT INTO Marketing_Automation (MA_ID, MTDM_ID, Team_Leader_ID, Platform_Used, Automated_Campaigns, Leads_Generated, Last_Updated_Date, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (3, 15, 393, 'Pardot', 10, 750, TO_DATE('2025-03-20', 'YYYY-MM-DD'), 5, 'Active', TO_DATE('2025-03-01', 'YYYY-MM-DD'), TO_DATE('2025-09-30', 'YYYY-MM-DD'));
INSERT INTO Marketing_Automation (MA_ID, MTDM_ID, Team_Leader_ID, Platform_Used, Automated_Campaigns, Leads_Generated, Last_Updated_Date, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (4, 15, 393, 'ActiveCampaign', 7, 500, TO_DATE('2025-06-10', 'YYYY-MM-DD'), 5, 'Inactive', TO_DATE('2025-04-01', 'YYYY-MM-DD'), TO_DATE('2025-10-31', 'YYYY-MM-DD'));
INSERT INTO Marketing_Automation (MA_ID, MTDM_ID, Team_Leader_ID, Platform_Used, Automated_Campaigns, Leads_Generated, Last_Updated_Date, Team_Size, Status, Project_Start_Date, Project_End_Date) 
VALUES (5, 15, 393, 'Mailchimp', 15, 900, TO_DATE('2025-05-25', 'YYYY-MM-DD'), 5, 'Active', TO_DATE('2025-01-15', 'YYYY-MM-DD'), TO_DATE('2025-12-15', 'YYYY-MM-DD'));