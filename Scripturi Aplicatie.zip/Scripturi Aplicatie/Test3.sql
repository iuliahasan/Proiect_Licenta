CREATE OR REPLACE VIEW Project_Management_Calendar AS
SELECT 
    PJ_ID AS Project_ID,
    'General Project' AS Project_Type,
    Description AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Project_Management

UNION ALL

SELECT 
    Agile_ID,
    'Agile Project',
    Framework || ' / Scrum Teams: ' || Scrum_Teams AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Agile

UNION ALL

SELECT 
    Waterfall_ID,
    'Waterfall Project',
    Current_Phase || ' / Phases: ' || Number_Of_Phases AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Waterfall

UNION ALL

SELECT 
    Hybrid_ID,
    'Hybrid Project',
    Main_Methodology || ' / Integration: ' || Methodology_Integration AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Hybrid_PM

UNION ALL

SELECT 
    Program_ID,
    'Program Management',
    Program_Name || ' / Projects: ' || Total_Projects AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Program_Management

UNION ALL

SELECT 
    Coordination_ID,
    'Project Coordination',
    Admin_Tools || ' / Templates: ' || Standardized_Templates AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Project_Coordination;

CREATE OR REPLACE VIEW Project_Management_Teams_View AS
SELECT
    'Agile' AS Team_Type,
    a.Agile_ID AS Team_ID,
    a.PJ_ID,
    a.Team_Leader_ID,
    a.Framework || ', ' || a.Tools AS Method_Description,
    a.Status,
    a.Team_Size,
    a.Project_Start_Date,
    a.Project_End_Date
FROM Agile a

UNION ALL

SELECT
    'Waterfall',
    w.Waterfall_ID,
    w.PJ_ID,
    w.Team_Leader_ID,
    w.Current_Phase || ', ' || w.Tools,
    w.Status,
    w.Team_Size,
    w.Project_Start_Date,
    w.Project_End_Date
FROM Waterfall w

UNION ALL

SELECT
    'Hybrid',
    h.Hybrid_ID,
    h.PJ_ID,
    h.Team_Leader_ID,
    h.Main_Methodology || ', ' || h.Methodology_Integration,
    h.Status,
    h.Team_Size,
    h.Project_Start_Date,
    h.Project_End_Date
FROM Hybrid_PM h

UNION ALL

SELECT
    'Program Management',
    p.Program_ID,
    p.PJ_ID,
    p.Team_Leader_ID,
    p.Program_Name || ', Budget: ' || TO_CHAR(p.Budget),
    p.Status,
    p.Team_Size,
    p.Project_Start_Date,
    p.Project_End_Date
FROM Program_Management p

UNION ALL

SELECT
    'Project Coordination',
    c.Coordination_ID,
    c.PJ_ID,
    c.Team_Leader_ID,
    'Tools: ' || c.Admin_Tools || ', Templates: ' || TO_CHAR(c.Standardized_Templates),
    c.Status,
    c.Team_Size,
    c.Project_Start_Date,
    c.Project_End_Date
FROM Project_Coordination c;
