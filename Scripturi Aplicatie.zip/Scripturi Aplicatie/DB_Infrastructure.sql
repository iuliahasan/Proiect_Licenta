--Oracle APEX 23.2.4 SQL
--Schema: Aplicatie management firma IT
--ANDREEA.HASAN@STUDENT.UPT.RO

--			Infrastructure / SysAdmin / Network

--System Administration
--Network Engineering
--Cloud Infrastructure
--Virtualization & Storage
--Data Center Operations
--Infrastructure Security
--Monitoring & Alerting
--Backup & Disaster Recovery
--Configuration Management (CMDB)
--Email & Communication Systems

--Main table for the Infrastructure / SysAdmin / Network Department
CREATE TABLE Infrastructure (
    Infrastructure_ID     INT NOT NULL,
    Description           VARCHAR2(200),
    Team_Leader_ID        INT NOT NULL,
    Team_Size             INT NOT NULL,
    Status                VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date    DATE,
    Project_End_Date      DATE,

    CONSTRAINT PK_Infrastructure PRIMARY KEY (Infrastructure_ID),
    CONSTRAINT FK_Infra_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Infra_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

-- System Administration Team Table
CREATE TABLE System_Administration (
    Administration_ID         INT NOT NULL,
    Infrastructure_ID         INT NOT NULL,
    Team_Leader_ID            INT NOT NULL,
    Operating_Systems         VARCHAR2(100),
    Server_Count              INT NOT NULL,
    Tools                     VARCHAR2(100),
    Monthly_Issues_Resolved   INT NOT NULL,
    Team_Size                 INT NOT NULL,
    Status                    VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date        DATE,
    Project_End_Date          DATE,

    CONSTRAINT PK_System_Admin PRIMARY KEY (Administration_ID),
    CONSTRAINT FK_SA_Infrastructure FOREIGN KEY (Infrastructure_ID) REFERENCES Infrastructure(Infrastructure_ID),
    CONSTRAINT FK_SA_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_SA_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

-- Network Engineering Team Table
CREATE TABLE Network_Engineering (
    Network_ID               INT NOT NULL,
    Infrastructure_ID        INT NOT NULL,
    Team_Leader_ID           INT NOT NULL,
    Network_Devices          VARCHAR2(100),
    Topology                 VARCHAR2(100),
    Monitoring_Tools         VARCHAR2(100),
    Active_VPN_Connections   INT NOT NULL,
    Bandwidth_Usage          NUMBER,
    Team_Size                INT NOT NULL,
    Status                   VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date       DATE,
    Project_End_Date         DATE,

    CONSTRAINT PK_Network_Eng PRIMARY KEY (Network_ID),
    CONSTRAINT FK_NE_Infrastructure FOREIGN KEY (Infrastructure_ID) REFERENCES Infrastructure(Infrastructure_ID),
    CONSTRAINT FK_NE_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_NE_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

-- Cloud Infrastructure Team Table
CREATE TABLE Cloud_Infrastructure (
    Cloud_ID                INT NOT NULL,
    Infrastructure_ID       INT NOT NULL,
    Team_Leader_ID          INT NOT NULL,
    Cloud_Providers         VARCHAR2(100),
    IAAS_Resources          INT NOT NULL,
    Container_Technologies  VARCHAR2(100),
    IaC_Tools               VARCHAR2(100),
    Monthly_Cloud_Spend     NUMBER,
    Team_Size               INT NOT NULL,
    Status                  VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date      DATE,
    Project_End_Date        DATE,

    CONSTRAINT PK_Cloud_Infra PRIMARY KEY (Cloud_ID),
    CONSTRAINT FK_CI_Infrastructure FOREIGN KEY (Infrastructure_ID) REFERENCES Infrastructure(Infrastructure_ID),
    CONSTRAINT FK_CI_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_CI_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

-- Virtualization & Storage Team Table
CREATE TABLE Virtualization_Storage (
    VS_ID                    INT NOT NULL,
    Infrastructure_ID        INT NOT NULL,
    Team_Leader_ID           INT NOT NULL,
    Virtualization_Tech      VARCHAR2(100),
    Virtual_Machines         INT NOT NULL,
    Storage_Tech             VARCHAR2(100),
    Storage_Capacity_GB      INT NOT NULL,
    Storage_Usage_Percent    NUMBER,
    Team_Size                INT NOT NULL,
    Status                   VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date       DATE,
    Project_End_Date         DATE,

    CONSTRAINT PK_VS PRIMARY KEY (VS_ID),
    CONSTRAINT FK_VS_Infrastructure FOREIGN KEY (Infrastructure_ID) REFERENCES Infrastructure(Infrastructure_ID),
    CONSTRAINT FK_VS_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_VS_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

-- Data Center Operations Team Table
CREATE TABLE Data_Center_Operations (
    Data_Center_ID         INT NOT NULL,
    Infrastructure_ID      INT NOT NULL,
    Team_Leader_ID         INT NOT NULL,
    Physical_Servers       INT NOT NULL,
    Locations              VARCHAR2(100),
    Power_Usage_KW         NUMBER,
    Cooling_System         VARCHAR2(100),
    Security_Measures      VARCHAR2(100),
    Team_Size              INT NOT NULL,
    Status                 VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date     DATE,
    Project_End_Date       DATE,

    CONSTRAINT PK_DCO PRIMARY KEY (Data_Center_ID),
    CONSTRAINT FK_DCO_Infrastructure FOREIGN KEY (Infrastructure_ID) REFERENCES Infrastructure(Infrastructure_ID),
    CONSTRAINT FK_DCO_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_DCO_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

-- Infrastructure Security Team Table
CREATE TABLE Infrastructure_Security (
    Infrastructure_Security_ID  INT NOT NULL,
    Infrastructure_ID           INT NOT NULL,
    Team_Leader_ID              INT NOT NULL,
    Firewalls                   INT NOT NULL,
    IDS_IPS_Systems             VARCHAR2(100),
    Patch_Management            VARCHAR2(100),
    Annual_Audits               INT NOT NULL,
    Compliance_Frameworks       VARCHAR2(100),
    Team_Size                   INT NOT NULL,
    Status                      VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date          DATE,
    Project_End_Date            DATE,

    CONSTRAINT PK_Infra_Sec PRIMARY KEY (Infrastructure_Security_ID),
    CONSTRAINT FK_IS_Infrastructure FOREIGN KEY (Infrastructure_ID) REFERENCES Infrastructure(Infrastructure_ID),
    CONSTRAINT FK_IS_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_IS_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

-- Monitoring & Alerting Team Table
CREATE TABLE Monitoring_Alerting (
    Monitoring_Alerting_ID     INT NOT NULL,
    Infrastructure_ID          INT NOT NULL,
    Team_Leader_ID             INT NOT NULL,
    Monitoring_Tools           VARCHAR2(100),
    Alerting_Systems           VARCHAR2(100),
    Nodes_Monitored            INT NOT NULL,
    Daily_Alerts_Generated     NUMBER,
    SLA_Response_Time          NUMBER,
    Team_Size                  INT NOT NULL,
    Status                     VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date         DATE,
    Project_End_Date           DATE,

    CONSTRAINT PK_Monitoring_Alerting PRIMARY KEY (Monitoring_Alerting_ID),
    CONSTRAINT FK_MA_Infrastructure FOREIGN KEY (Infrastructure_ID) REFERENCES Infrastructure(Infrastructure_ID),
    CONSTRAINT FK_MA_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_MA_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

-- Backup & Disaster Recovery Team Table
CREATE TABLE Backup_Disaster_Recovery (
    Backup_DR_ID            INT NOT NULL,
    Infrastructure_ID       INT NOT NULL,
    Team_Leader_ID          INT NOT NULL,
    Backup_Solutions        VARCHAR2(100),
    Backup_Storage_GB       INT NOT NULL,
    Backup_Frequency        VARCHAR2(100),
    Restore_Success_Rate    NUMBER,
    DR_Tests_Conducted      INT NOT NULL,
    Team_Size               INT NOT NULL,
    Status                  VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date      DATE,
    Project_End_Date        DATE,

    CONSTRAINT PK_Backup_DR PRIMARY KEY (Backup_DR_ID),
    CONSTRAINT FK_BDR_Infrastructure FOREIGN KEY (Infrastructure_ID) REFERENCES Infrastructure(Infrastructure_ID),
    CONSTRAINT FK_BDR_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_BDR_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

-- Configuration Management Team Table
CREATE TABLE Configuration_Management (
    CMDB_ID                INT NOT NULL,
    Infrastructure_ID      INT NOT NULL,
    Team_Leader_ID         INT NOT NULL,
    Tool                   VARCHAR2(100),
    Config_Items_Tracked   INT NOT NULL,
    Auto_Discovery         VARCHAR2(3) CHECK (Auto_Discovery IN ('Yes', 'No')),
    Sync_Frequency         NUMBER,
    Last_Audit_Date        DATE,
    Team_Size              INT NOT NULL,
    Status                 VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date     DATE,
    Project_End_Date       DATE,

    CONSTRAINT PK_CMDB PRIMARY KEY (CMDB_ID),
    CONSTRAINT FK_CM_Infrastructure FOREIGN KEY (Infrastructure_ID) REFERENCES Infrastructure(Infrastructure_ID),
    CONSTRAINT FK_CM_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_CM_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

-- Email & Communication Systems Team Table
CREATE TABLE Email_Communication (
    EC_ID                  INT NOT NULL,
    Infrastructure_ID      INT NOT NULL,
    Team_Leader_ID         INT NOT NULL,
    Email_Platform         VARCHAR2(100),
    Users_Managed          INT NOT NULL,
    Communication_Tools    VARCHAR2(100),
    Uptime                 NUMBER,
    Archiving_Policy       VARCHAR2(100),
    Team_Size              INT NOT NULL,
    Status                 VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date     DATE,
    Project_End_Date       DATE,

    CONSTRAINT PK_EC PRIMARY KEY (EC_ID),
    CONSTRAINT FK_EC_Infrastructure FOREIGN KEY (Infrastructure_ID) REFERENCES Infrastructure(Infrastructure_ID),
    CONSTRAINT FK_EC_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_EC_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);