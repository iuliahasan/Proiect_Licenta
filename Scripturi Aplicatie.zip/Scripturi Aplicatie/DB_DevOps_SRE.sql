--Oracle APEX 23.2.4 SQL
--Schema: Aplicatie management firma IT
--ANDREEA.HASAN@STUDENT.UPT.RO

--		Departamentul DevOps / SRE (Site Reliability Engineering)

--CI/CD Pipeline Management
--Infrastructure as Code (IaC)
--Observability & Monitoring
--Incident Response & Reliability Engineering
--Platform Engineering
--Cloud Automation
--Release Engineering
--Capacity & Performance Management
--SLA/SLO Management
--Toolchain Integration
--Cost Optimization & Billing Visibility
--Secrets Management
--Container Orchestration
--Change Management & Approvals
--Deployment Strategies

--Main table for the DevOps / Site Reliability Engineering (SRE) Department
CREATE TABLE DevOps_SRE (
    DS_ID                INT PRIMARY KEY,
    Description          VARCHAR2(200),
    Team_Leader_ID       INT NOT NULL,
    Mission              VARCHAR2(100),
    Status               VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date   DATE,
    Project_End_Date     DATE,

    CONSTRAINT FK_DevOpsSRE_TeamLeader FOREIGN KEY (Team_Leader_ID)
        REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_DevOpsSRE_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--CI/CD Pipeline Management Team Table
CREATE TABLE CICD_Pipeline_Management (
    CPipeM_ID INT PRIMARY KEY,
    DS_ID INT NOT NULL,
    Team_Leader_ID INT NOT NULL,
    Pipeline_Name VARCHAR2(100),
    Tool VARCHAR2(100),
    Stages VARCHAR2(100),
    Last_Deployment DATE,
    Auto_Rollback_Enabled VARCHAR2(3) CHECK (Auto_Rollback_Enabled IN ('Yes', 'No')),
    Notification_Channels VARCHAR2(100),
    Team_Size INT NOT NULL,
    Status VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date DATE,
    Project_End_Date DATE,

    CONSTRAINT FK_DS_CICD FOREIGN KEY (DS_ID) REFERENCES DevOps_SRE(DS_ID),
    CONSTRAINT FK_TL_CICD FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Status_CICD CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Infrastructure as Code (IaC) Team Table
CREATE TABLE Infrastructure_as_Code (
    IaC_ID INT PRIMARY KEY,
    DS_ID INT NOT NULL,
    Team_Leader_ID INT NOT NULL,
    Tool VARCHAR2(100),
    Code_Repository VARCHAR2(200),
    Environment_Target VARCHAR2(50),
    Version_Control VARCHAR2(50),
    Last_Applied_Date DATE,
    Auto_Approve_Changes VARCHAR2(3) CHECK (Auto_Approve_Changes IN ('Yes', 'No')),
    Team_Size INT NOT NULL,
    Status VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date DATE,
    Project_End_Date DATE,

    CONSTRAINT FK_DS_IAC FOREIGN KEY (DS_ID) REFERENCES DevOps_SRE(DS_ID),
    CONSTRAINT FK_TL_IAC FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Status_IAC CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Observability & Monitoring Team Table
CREATE TABLE Observability_Monitoring (
    ObsMon_ID INT PRIMARY KEY,
    DS_ID INT NOT NULL,
    Team_Leader_ID INT NOT NULL,
    Tool VARCHAR2(100),
    Monitoring_Scope VARCHAR2(100),
    Dashboard_URL VARCHAR2(200),
    Alerting_Enabled VARCHAR2(3) CHECK (Alerting_Enabled IN ('Yes', 'No')),
    Incident_Integration VARCHAR2(100),
    Team_Size INT NOT NULL,
    Status VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date DATE,
    Project_End_Date DATE,

    CONSTRAINT FK_DS_OBSM FOREIGN KEY (DS_ID) REFERENCES DevOps_SRE(DS_ID),
    CONSTRAINT FK_TL_OBSM FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Status_OBSM CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Incident Response & Reliability Engineering Team Table
CREATE TABLE Incident_Response_Reliability (
    IRRE_ID INT PRIMARY KEY,
    DS_ID INT NOT NULL,
    Team_Leader_ID INT NOT NULL,
    Incident_Process_Name VARCHAR2(100),
    On_Call_Rotation_Model VARCHAR2(100),
    Incident_Tracking_Tool VARCHAR2(100),
    Last_Major_Incident DATE,
    PostMortem_Required VARCHAR2(3) CHECK (PostMortem_Required IN ('Yes', 'No')),
    Team_Size INT NOT NULL,
    Status VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date DATE,
    Project_End_Date DATE,

    CONSTRAINT FK_DS_IRRE FOREIGN KEY (DS_ID) REFERENCES DevOps_SRE(DS_ID),
    CONSTRAINT FK_TL_IRRE FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Status_IRRE CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Platform Engineering Team Table
CREATE TABLE Platform_Engineering (
    PE_ID INT PRIMARY KEY,
    DS_ID INT NOT NULL,
    Team_Leader_ID INT NOT NULL,
    Platform_Name VARCHAR2(100),
    Technologies_Used VARCHAR2(100),
    Self_Service_Portal VARCHAR2(3) CHECK (Self_Service_Portal IN ('Yes', 'No')),
    Documentation_URL VARCHAR2(100),
    Onboarding_Required VARCHAR2(3) CHECK (Onboarding_Required IN ('Yes', 'No')),
    Team_Size INT NOT NULL,
    Status VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date DATE,
    Project_End_Date DATE,

    CONSTRAINT FK_DS_PE FOREIGN KEY (DS_ID) REFERENCES DevOps_SRE(DS_ID),
    CONSTRAINT FK_TL_PE FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Status_PE CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Cloud Automation Team Table
CREATE TABLE Cloud_Automation (
    CA_ID INT PRIMARY KEY,
    DS_ID INT NOT NULL,
    Team_Leader_ID INT NOT NULL,
    Cloud_Provider VARCHAR2(50),
    Automation_Tool VARCHAR2(100),
    Resource_Type VARCHAR2(100),
    Auto_Scaling_Enabled VARCHAR2(3) CHECK (Auto_Scaling_Enabled IN ('Yes', 'No')),
    Scheduled_Automation VARCHAR2(100),
    Team_Size INT NOT NULL,
    Status VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date DATE,
    Project_End_Date DATE,

    CONSTRAINT FK_DS_CA FOREIGN KEY (DS_ID) REFERENCES DevOps_SRE(DS_ID),
    CONSTRAINT FK_TL_CA FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Status_CA CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Release Engineering Team Table
CREATE TABLE Release_Engineering (
    RE_ID INT PRIMARY KEY,
    DS_ID INT NOT NULL,
    Team_Leader_ID INT NOT NULL,
    Release_Pipeline_Name VARCHAR2(100),
    Versioning_Strategy VARCHAR2(50),
    Release_Tool VARCHAR2(100),
    Rollback_Supported VARCHAR2(3) CHECK (Rollback_Supported IN ('Yes', 'No')),
    Last_Deploy DATE,
    Team_Size INT NOT NULL,
    Status VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date DATE,
    Project_End_Date DATE,

    CONSTRAINT FK_DS_RE FOREIGN KEY (DS_ID) REFERENCES DevOps_SRE(DS_ID),
    CONSTRAINT FK_TL_RE FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Status_RE CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Capacity & Performance Management Team Table
CREATE TABLE Capacity_Performance_Management (
    CPM_ID INT PRIMARY KEY,
    DS_ID INT NOT NULL,
    Team_Leader_ID INT NOT NULL,
    Resource_Type VARCHAR2(100),
    Capacity_Limit NUMBER,
    Performance_Metrics VARCHAR2(100),
    Auto_Scaling_Enabled VARCHAR2(3) CHECK (Auto_Scaling_Enabled IN ('Yes', 'No')),
    Monitoring_Tool VARCHAR2(100),
    Team_Size INT NOT NULL,
    Status VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date DATE,
    Project_End_Date DATE,

    CONSTRAINT FK_DS_CPM FOREIGN KEY (DS_ID) REFERENCES DevOps_SRE(DS_ID),
    CONSTRAINT FK_TL_CPM FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Status_CPM CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--SLA / SLO Management Team Table
CREATE TABLE SLA_SLO_Management (
    SLA_ID INT PRIMARY KEY,
    DS_ID INT NOT NULL,
    Team_Leader_ID INT NOT NULL,
    Service_Name VARCHAR2(100),
    SLA_Definition VARCHAR2(200),
    SLO_Target VARCHAR2(100),
    SLIs_Used VARCHAR2(100),
    Breach_Response VARCHAR2(100),
    Team_Size INT NOT NULL,
    Status VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date DATE,
    Project_End_Date DATE,
    
    CONSTRAINT FK_DS_SLA FOREIGN KEY (DS_ID) REFERENCES DevOps_SRE(DS_ID),
    CONSTRAINT FK_TL_SLA FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Status_SLA CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Toolchain Integration Team Table
CREATE TABLE Toolchain_Integration (
    TI_ID                       INT NOT NULL,
    DS_ID                       INT NOT NULL,
    Team_Leader_ID              INT NOT NULL,
    Tool                        VARCHAR2(100),
    Integration_Type            VARCHAR2(50),
    Integration_With            VARCHAR2(100),
    Last_Sync                   DATE,
    Automation_Level            VARCHAR2(50),
    Team_Size                   INT NOT NULL,
    Status                      VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date          DATE,
    Project_End_Date            DATE,

    CONSTRAINT PK_TI PRIMARY KEY (TI_ID),
    CONSTRAINT FK_TI_DS FOREIGN KEY (DS_ID) REFERENCES DevOps_SRE(DS_ID),
    CONSTRAINT FK_TI_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_TI_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Cost Optimization & Billing Visibility Team Table
CREATE TABLE Cost_Optimization_Billing_Visibility (
    COBV_ID                     INT PRIMARY KEY,
    DS_ID                       INT NOT NULL,
    Team_Leader_ID              INT NOT NULL,
    Service_Name                VARCHAR2(100),
    Monthly_Cost                NUMBER,
    Cost_Trend                  VARCHAR2(50),
    Optimization_Actions        VARCHAR2(100),
    Billing_Visibility_Level    VARCHAR2(50),
    Last_Reviewed               DATE,
    Team_Size                   INT NOT NULL,
    Status                      VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date          DATE,
    Project_End_Date            DATE,

    CONSTRAINT FK_COBV_DS FOREIGN KEY (DS_ID) REFERENCES DevOps_SRE(DS_ID),
    CONSTRAINT FK_COBV_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_COBV_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Secrets Management Team Table
CREATE TABLE Secrets_Management (
    SM_ID                     INT PRIMARY KEY,
    DS_ID                     INT NOT NULL,
    Team_Leader_ID            INT NOT NULL,
    Secret_Name               VARCHAR2(100),
    Secret_Type               VARCHAR2(50),
    Storage_Location          VARCHAR2(100),
    Rotation_Policy           VARCHAR2(100),
    Encrypted                 VARCHAR2(3) CHECK (Encrypted IN ('Yes', 'No')),
    Last_Rotated              DATE,
    Team_Size                 INT NOT NULL,
    Status                    VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date        DATE,
    Project_End_Date          DATE,

    CONSTRAINT FK_SM_DS FOREIGN KEY (DS_ID) REFERENCES DevOps_SRE(DS_ID),
    CONSTRAINT FK_SM_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_SM_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Container Orchestration Team Table
CREATE TABLE Container_Orchestration (
    CO_ID                      INT PRIMARY KEY,
    DS_ID                      INT NOT NULL,
    Team_Leader_ID             INT NOT NULL,
    Platform_Used              VARCHAR2(100),
    Cluster_Name               VARCHAR2(100),
    Nodes                      INT NOT NULL,
    Deployment_Strategy        VARCHAR2(100),
    Auto_Scaling               VARCHAR2(3) CHECK (Auto_Scaling IN ('Yes', 'No')),
    Team_Size                  INT NOT NULL,
    Status                     VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date         DATE,
    Project_End_Date           DATE,

    CONSTRAINT FK_CO_DS FOREIGN KEY (DS_ID) REFERENCES DevOps_SRE(DS_ID),
    CONSTRAINT FK_CO_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_CO_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Change Management & Approvals Team Table
CREATE TABLE Change_Management_Approvals (
    CMA_ID                     INT PRIMARY KEY,
    DS_ID                      INT NOT NULL,
    Team_Leader_ID             INT NOT NULL,
    Change_Type                VARCHAR2(100),
    Change_Description         VARCHAR2(100),
    Requested_By               INT NOT NULL,
    Approval_Status            VARCHAR2(50),
    Implementation_Date        DATE,
    Team_Size                  INT NOT NULL,
    Status                     VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date         DATE,
    Project_End_Date           DATE,

    CONSTRAINT FK_CMA_DS FOREIGN KEY (DS_ID) REFERENCES DevOps_SRE(DS_ID),
    CONSTRAINT FK_CMA_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT FK_CMA_Requested_By FOREIGN KEY (Requested_By) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_CMA_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Deployment Strategies Team Table
CREATE TABLE Deployment_Strategies (
    DSTR_ID                    INT PRIMARY KEY,
    DS_ID                      INT NOT NULL,
    Team_Leader_ID             INT NOT NULL,
    Strategy_Name              VARCHAR2(100),
    Strategy_Description       VARCHAR2(100),
    Automated                  VARCHAR2(3) CHECK (Automated IN ('Yes', 'No')),
    Tool                       VARCHAR2(100),
    Team_Size                  INT NOT NULL,
    Status                     VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date         DATE,
    Project_End_Date           DATE,

    CONSTRAINT FK_DSTR_DS FOREIGN KEY (DS_ID) REFERENCES DevOps_SRE(DS_ID),
    CONSTRAINT FK_DSTR_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_DSTR_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);