--Oracle APEX 23.2.4 SQL
--Schema: Aplicatie management firma IT
--ANDREEA.HASAN@STUDENT.UPT.RO

--			Security / Cybersecurity

--Network Security
--Application Security
--Endpoint Security
--Identity & Access Management (IAM)
--Security Operations Center (SOC)
--Threat Intelligence & Analysis
--Penetration Testing / Ethical Hacking
--Governance, Risk & Compliance (GRC)
--Cloud Security
--Incident Response & Forensics
--Security Awareness & Training
--Data Loss Prevention (DLP)
--Zero Trust Architecture
--DevSecOps

--Main table for the Security / Cybersecurity Department
CREATE TABLE Security_Cybersecurity (
    SC_ID                          INT NOT NULL,
    Description                   VARCHAR2(200),
    Team_Leader_ID                INT NOT NULL,
    Members                       INT NOT NULL,
    Security_Framework            VARCHAR2(100),
    Incident_Response_Plan        VARCHAR2(3),
    Status                        VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date            DATE,
    Project_End_Date              DATE,

    CONSTRAINT PK_SC PRIMARY KEY (SC_ID),
    CONSTRAINT FK_SC_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_SC_IRP CHECK (Incident_Response_Plan IN ('Yes', 'No')),
    CONSTRAINT CHK_SC_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Network Security Team Table
CREATE TABLE Network_Security (
    NS_ID                         INT NOT NULL,
    SC_ID                         INT NOT NULL,
    Team_Leader_ID                INT NOT NULL,
    Firewall_Brands               VARCHAR2(100),
    IDS_IPS_Deployed              VARCHAR2(3),
    VPN_Type                      VARCHAR2(50),
    Network_Segmentation          VARCHAR2(3),
    Team_Size                     INT NOT NULL,
    Status                        VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date            DATE,
    Project_End_Date              DATE,

    CONSTRAINT PK_NS PRIMARY KEY (NS_ID),
    CONSTRAINT FK_NS_SC FOREIGN KEY (SC_ID) REFERENCES Security_Cybersecurity(SC_ID),
    CONSTRAINT FK_NS_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_NS_IDS CHECK (IDS_IPS_Deployed IN ('Yes', 'No')),
    CONSTRAINT CHK_NS_Segmentation CHECK (Network_Segmentation IN ('Yes', 'No')),
    CONSTRAINT CHK_NS_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Application Security Team Table
CREATE TABLE Application_Security (
    AppSec_ID                     INT NOT NULL,
    SC_ID                         INT NOT NULL,
    Team_Leader_ID                INT NOT NULL,
    Static_Analysis_Tools         VARCHAR2(100),
    Dynamic_Analysis              VARCHAR2(3),
    Secure_Coding_Guidelines      VARCHAR2(3),
    OWASP_Compliance_Level        VARCHAR2(50),
    Team_Size                     INT NOT NULL,
    Status                        VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date            DATE,
    Project_End_Date              DATE,

    CONSTRAINT PK_AppSec PRIMARY KEY (AppSec_ID),
    CONSTRAINT FK_AppSec_SC FOREIGN KEY (SC_ID) REFERENCES Security_Cybersecurity(SC_ID),
    CONSTRAINT FK_AppSec_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_AppSec_DA CHECK (Dynamic_Analysis IN ('Yes', 'No')),
    CONSTRAINT CHK_AppSec_SCG CHECK (Secure_Coding_Guidelines IN ('Yes', 'No')),
    CONSTRAINT CHK_AppSec_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Endpoint Security Team Table
CREATE TABLE Endpoint_Security (
    ES_ID                         INT NOT NULL,
    SC_ID                         INT NOT NULL,
    Team_Leader_ID                INT NOT NULL,
    Endpoint_Protection_Platform  VARCHAR2(100),
    Device_Encryption             VARCHAR2(3),
    Patch_Management_Automated    VARCHAR2(3),
    Allowed_OS_List               VARCHAR2(100),
    Team_Size                     INT NOT NULL,
    Status                        VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date            DATE,
    Project_End_Date              DATE,

    CONSTRAINT PK_ES PRIMARY KEY (ES_ID),
    CONSTRAINT FK_ES_SC FOREIGN KEY (SC_ID) REFERENCES Security_Cybersecurity(SC_ID),
    CONSTRAINT FK_ES_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_ES_Encrypt CHECK (Device_Encryption IN ('Yes', 'No')),
    CONSTRAINT CHK_ES_Patch CHECK (Patch_Management_Automated IN ('Yes', 'No')),
    CONSTRAINT CHK_ES_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Identity & Access Management (IAM) Team Table
CREATE TABLE IAM (
    IAM_ID                        INT NOT NULL,
    SC_ID                         INT NOT NULL,
    Team_Leader_ID                INT NOT NULL,
    SSO_Implemented               VARCHAR2(3),
    MFA_Enforced                  VARCHAR2(3),
    IAM_Platform                  VARCHAR2(100),
    Roles_Defined                 INT NOT NULL,
    Team_Size                     INT NOT NULL,
    Status                        VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date            DATE,
    Project_End_Date              DATE,

    CONSTRAINT PK_IAM PRIMARY KEY (IAM_ID),
    CONSTRAINT FK_IAM_SC FOREIGN KEY (SC_ID) REFERENCES Security_Cybersecurity(SC_ID),
    CONSTRAINT FK_IAM_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_IAM_SSO CHECK (SSO_Implemented IN ('Yes', 'No')),
    CONSTRAINT CHK_IAM_MFA CHECK (MFA_Enforced IN ('Yes', 'No')),
    CONSTRAINT CHK_IAM_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Threat Intelligence & Analysis Team Table
CREATE TABLE TIA (
    TIA_ID                  		INT PRIMARY KEY,
    SC_ID 				            INT NOT NULL,
    Team_Leader_ID         		    INT NOT NULL,
    Intel_Feeds            		    VARCHAR2(200),
    Threat_Report_Count    		    INT NOT NULL,
    SIEM_Integrated        		    VARCHAR2(3) CHECK (SIEM_Integrated IN ('Yes', 'No')),
    External_Threat_Sources 		VARCHAR2(100),
    Team_Size              		    INT NOT NULL,
    Status                 		    VARCHAR2(30) DEFAULT 'Inactive' NOT NULL CHECK (Status IN ('Inactive', 'Active', 'Pending')),
    Project_Start_Date     		    DATE,
    Project_End_Date          		DATE,

    CONSTRAINT FK_TIA_SC FOREIGN KEY (SC_ID) REFERENCES Security_Cybersecurity(SC_ID),
    CONSTRAINT FK_TIA_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID)
);

--Penetration Testing / Ethical Hacking Team Table
CREATE TABLE Penetration_Testing_Ethical_Hacking (
    PTEH_ID              	    INT PRIMARY KEY,
    SC_ID                	    INT NOT NULL,
    Team_Leader_ID       	    INT NOT NULL,
    Tools_Used           	    VARCHAR2(100),
    Test_Scope           	    VARCHAR2(100),
    Test_Frequency       	    VARCHAR2(100),
    Findings_Reported    	    INT NOT NULL,
    Team_Size            	    INT NOT NULL,
    Status               	    VARCHAR2(30) DEFAULT 'Inactive' NOT NULL CHECK (Status IN ('Inactive', 'Active', 'Pending')),
    Project_Start_Date   	    DATE,
    Project_End_Date          	DATE,

    CONSTRAINT FK_PTEH_SC FOREIGN KEY (SC_ID) REFERENCES Security_Cybersecurity(SC_ID),
    CONSTRAINT FK_PTEH_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID)
);

--Governance, Risk & Compliance (GRC) Team Table
CREATE TABLE Governance_Risk_Compliance (
    GRC_ID                     		INT PRIMARY KEY,
    SC_ID                      		INT NOT NULL,
    Team_Leader_ID             		INT NOT NULL,
    Compliance_Frameworks      		VARCHAR2(100),
    Risk_Assessment_Frequency  		NUMBER,
    Policies_Defined           		INT NOT NULL,
    Audit_Logs_Enabled         		VARCHAR2(3) CHECK (Audit_Logs_Enabled IN ('Yes', 'No')),
    Team_Size                  		INT NOT NULL,
    Status                     		VARCHAR2(30) DEFAULT 'Inactive' NOT NULL CHECK (Status IN ('Inactive', 'Active', 'Pending')),
    Project_Start_Date         		DATE,
    Project_End_Date          		DATE,

    CONSTRAINT FK_GRC_SC FOREIGN KEY (SC_ID) REFERENCES Security_Cybersecurity(SC_ID),
    CONSTRAINT FK_GRC_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID)
);

--Cloud Security Team Table
CREATE TABLE Cloud_Security (
    CS_ID                      		INT PRIMARY KEY,
    SC_ID                      		INT NOT NULL,
    Team_Leader_ID             		INT NOT NULL,
    Cloud_Providers            		VARCHAR2(100),
    Security_Tools             		VARCHAR2(100),
    Multi_Cloud_Strategy       		VARCHAR2(3) CHECK (Multi_Cloud_Strategy IN ('Yes', 'No')),
    Incident_Response_Ready    		VARCHAR2(3) CHECK (Incident_Response_Ready IN ('Yes', 'No')),
    Team_Size                  		INT NOT NULL,
    Status                     		VARCHAR2(30) DEFAULT 'Inactive' NOT NULL CHECK (Status IN ('Inactive', 'Active', 'Pending')),
    Project_Start_Date         		DATE,
    Project_End_Date          		DATE,

    CONSTRAINT FK_CS_SC FOREIGN KEY (SC_ID) REFERENCES Security_Cybersecurity(SC_ID),
    CONSTRAINT FK_CS_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID)
);

--Incident Response & Forensics Team Table
CREATE TABLE Incident_Response_Forensics (
    IRF_ID                        	INT PRIMARY KEY,
    SC_ID                         	INT NOT NULL,
    Team_Leader_ID                	INT NOT NULL,
    Response_Team_Ready           	VARCHAR2(3) CHECK (Response_Team_Ready IN ('Yes', 'No')),
    Average_Response_Time         	NUMBER,
    Incidents                     	INT NOT NULL,
    Digital_Forensics_Enabled     	VARCHAR2(3) CHECK (Digital_Forensics_Enabled IN ('Yes', 'No')),
    Team_Size                     	INT NOT NULL,
    Status                        	VARCHAR2(30) DEFAULT 'Inactive' NOT NULL CHECK (Status IN ('Inactive', 'Active', 'Pending')),
    Project_Start_Date            	DATE,
    Project_End_Date          		DATE,

    CONSTRAINT FK_IRF_SC FOREIGN KEY (SC_ID) REFERENCES Security_Cybersecurity(SC_ID),
    CONSTRAINT FK_IRF_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID)
);

--Security Awareness & Training Team Table
CREATE TABLE Security_Awareness_Training (
    SAT_ID                  	INT PRIMARY KEY,
    SC_ID                   	INT NOT NULL,
    Team_Leader_ID          	INT NOT NULL,
    Training_Program        	VARCHAR2(100),
    Target_Audience         	VARCHAR2(100),
    Training_Frequency      	VARCHAR2(50),
    Attendance_Rate         	NUMBER,
    Team_Size               	INT NOT NULL,
    Status                  	VARCHAR2(30) DEFAULT 'Inactive' NOT NULL CHECK (Status IN ('Inactive', 'Active', 'Pending')),
    Project_Start_Date      	DATE,
    Project_End_Date        	DATE,

    CONSTRAINT FK_SAT_SC FOREIGN KEY (SC_ID) REFERENCES Security_Cybersecurity(SC_ID),
    CONSTRAINT FK_SAT_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID)
);

--Data Loss Prevention (DLP) Team Table
CREATE TABLE Data_Loss_Prevention (
    DLP_ID                  	 INT PRIMARY KEY,
    SC_ID                   	 INT NOT NULL,
    Team_Leader_ID          	 INT NOT NULL,
    DLP_Policies            	 INT NOT NULL,
    Monitoring_Scope        	 VARCHAR2(100),
    Block_Actions_Enabled   	 VARCHAR2(3) CHECK (Block_Actions_Enabled IN ('Yes', 'No')),
    Alerts_Per_Month        	 INT NOT NULL,
    Team_Size               	 INT NOT NULL,
    Status                  	 VARCHAR2(30) DEFAULT 'Inactive' NOT NULL CHECK (Status IN ('Inactive', 'Active', 'Pending')),
    Project_Start_Date      	 DATE,
    Project_End_Date          	 DATE,

    CONSTRAINT FK_DLP_SC FOREIGN KEY (SC_ID) REFERENCES Security_Cybersecurity(SC_ID),
    CONSTRAINT FK_DLP_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID)
);

--Zero Trust Architecture (ZTA) Team Table
CREATE TABLE Zero_Trust_Architecture (
    ZTA_ID                      	INT PRIMARY KEY,
    SC_ID                       	INT NOT NULL,
    Team_Leader_ID              	INT NOT NULL,
    Implementation_Stage        	VARCHAR2(50),
    Identity_Check_Methods      	VARCHAR2(100),
    Microsegmentation_Enabled   	VARCHAR2(3) CHECK (Microsegmentation_Enabled IN ('Yes', 'No')),
    Device_Trust_Evaluation     	VARCHAR2(3) CHECK (Device_Trust_Evaluation IN ('Yes', 'No')),
    Team_Size                   	INT NOT NULL,
    Status                      	VARCHAR2(30) DEFAULT 'Inactive' NOT NULL CHECK (Status IN ('Inactive', 'Active', 'Pending')),
    Project_Start_Date          	DATE,
    Project_End_Date          		DATE,

    CONSTRAINT FK_ZTA_SC FOREIGN KEY (SC_ID) REFERENCES Security_Cybersecurity(SC_ID),
    CONSTRAINT FK_ZTA_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID)
);

--DevSecOps Team Table
CREATE TABLE DevSecOps (
    DevSecOps_ID                	INT PRIMARY KEY,
    SC_ID                       	INT NOT NULL,
    Team_Leader_ID              	INT NOT NULL,
    Integrated_In_Pipeline      	VARCHAR2(3) CHECK (Integrated_In_Pipeline IN ('Yes', 'No')),
    Static_Analysis_Enabled     	VARCHAR2(3) CHECK (Static_Analysis_Enabled IN ('Yes', 'No')),
    Dependency_Scanning         	VARCHAR2(3) CHECK (Dependency_Scanning IN ('Yes', 'No')),
    Automated_Security_Tests    	VARCHAR2(3) CHECK (Automated_Security_Tests IN ('Yes', 'No')),
    Team_Size                   	INT NOT NULL,
    Status                      	VARCHAR2(30) DEFAULT 'Inactive' NOT NULL CHECK (Status IN ('Inactive', 'Active', 'Pending')),
    Project_Start_Date          	DATE,
    Project_End_Date          		DATE,
    
    CONSTRAINT FK_DevSecOps_SC FOREIGN KEY (SC_ID) REFERENCES Security_Cybersecurity(SC_ID),
    CONSTRAINT FK_DevSecOps_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID)
);