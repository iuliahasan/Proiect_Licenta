--Oracle APEX 23.2.4 SQL
--Schema: Aplicatie management firma IT
--ANDREEA.HASAN@STUDENT.UPT.RO

--			Marketing Tech / Digital Marketing

--Digital Advertising (PPC, Display Ads)
--SEO (Search Engine Optimization)
--Content Marketing
--Social Media Marketing
--Email Marketing
--Affiliate Marketing
--Marketing Automation
--Analytics & Reporting
--Conversion Rate Optimization (CRO)
--Branding & Creative Strategy
--Influencer Marketing

--Main table for the Marketing Tech / Digital Marketing Department
CREATE TABLE Marketing_Tech_Digital_Marketing (
    MTDM_ID            		    INT NOT NULL,
    Team_Leader_ID     		    INT NOT NULL,
    Status             		    VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date 		    DATE,
    Project_End_Date          	DATE,

    CONSTRAINT PK_MTDM PRIMARY KEY (MTDM_ID),
    CONSTRAINT FK_MTDM_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_MTDM_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Digital Advertising (PPC, Display Ads) Team Table
CREATE TABLE Digital_Advertising (
    DA_ID               	    INT NOT NULL,
    MTDM_ID             	    INT NOT NULL,
    Team_Leader_ID      	    INT NOT NULL,
    Platform            	    VARCHAR2(100),
    Ad_Type             	    VARCHAR2(100),
    Budget_Allocated    	    NUMBER,
    Campaign_Start_Date 	    DATE,
    Campaign_End_Date   	    DATE,
    Ad_Views            	    INT NOT NULL,
    Clicks              	    INT NOT NULL,
    Team_Size           	    INT NOT NULL,
    Status              	    VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date  	    DATE,
    Project_End_Date          	DATE,

    CONSTRAINT PK_Digital_Advertising PRIMARY KEY (DA_ID),
    CONSTRAINT FK_DA_MTDM FOREIGN KEY (MTDM_ID) REFERENCES Marketing_Tech_Digital_Marketing(MTDM_ID),
    CONSTRAINT FK_DA_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_DA_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Search Engine Optimization (SEO) Team Table
CREATE TABLE SEO_New (
    SEO_ID              	    INT NOT NULL,
    MTDM_ID             	    INT NOT NULL,
    Team_Leader_ID      	    INT NOT NULL,
    Target_Keywords     	    VARCHAR2(100),
    Organic_Traffic     	    INT NOT NULL,
    Backlinks           	    INT NOT NULL,
    Domain_Authority    	    INT NOT NULL,
    Last_Audit_Date     	    DATE,
    Team_Size           	    INT NOT NULL,
    Status              	    VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date  	    DATE,
    Project_End_Date          	DATE,

    CONSTRAINT PK_SEO_NEW PRIMARY KEY (SEO_ID),
    CONSTRAINT FK_MTDM_SEO FOREIGN KEY (MTDM_ID) REFERENCES Marketing_Tech_Digital_Marketing(MTDM_ID),
    CONSTRAINT FK_Team_Leader_SEO FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Status_SEO CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Content Marketing Team Table
CREATE TABLE SEO (
    SEO_ID              	    INT NOT NULL,
    MTDM_ID             	    INT NOT NULL,
    Team_Leader_ID      	    INT NOT NULL,
    Target_Keywords     	    VARCHAR2(100),
    Organic_Traffic     	    INT NOT NULL,
    Backlinks           	    INT NOT NULL,
    Domain_Authority    	    INT NOT NULL,
    Last_Audit_Date     	    DATE,
    Team_Size           	    INT NOT NULL,
    Status              	    VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date  	    DATE,
    Project_End_Date          	DATE,

    CONSTRAINT PK_SEO PRIMARY KEY (SEO_ID),
    CONSTRAINT FK_SEO_MTDM FOREIGN KEY (MTDM_ID) REFERENCES Marketing_Tech_Digital_Marketing(MTDM_ID),
    CONSTRAINT FK_SEO_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_SEO_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Social Media Marketing Team Table
CREATE TABLE Social_Media_Marketing (
    Social_Media_Marketing_ID 		INT NOT NULL,
    MTDM_ID                   		INT NOT NULL,
    Team_Leader_ID            		INT NOT NULL,
    Platform                  		VARCHAR2(100),
    Campaign_Name             		VARCHAR2(150),
    Post_Frequency            		VARCHAR2(50),
    Engagement_Rate           		NUMBER,
    Followers_Growth          		INT NOT NULL,
    Team_Size                 		INT NOT NULL,
    Status                    		VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date        		DATE,
    Project_End_Date          		DATE,
    
    CONSTRAINT PK_SMM PRIMARY KEY (Social_Media_Marketing_ID),
    CONSTRAINT FK_SMM_MTDM FOREIGN KEY (MTDM_ID) REFERENCES Marketing_Tech_Digital_Marketing(MTDM_ID),
    CONSTRAINT FK_SMM_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_SMM_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Email Marketing Team Table
CREATE TABLE Email_Marketing (
    Email_Marketing_ID     	    INT NOT NULL,
    MTDM_ID                	    INT NOT NULL,
    Team_Leader_ID         	    INT NOT NULL,
    Campaign_Name          	    VARCHAR2(150),
    Email_Subject          	    VARCHAR2(100),
    Send_Date              	    DATE,
    Number_of_Recipients   	    INT NOT NULL,
    Open_Rate              	    NUMBER,
    Click_Through_Rate     	    NUMBER,
    Team_Size              	    INT NOT NULL,
    Status                 	    VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date     	    DATE,
    Project_End_Date          	DATE,

    CONSTRAINT PK_Email_Marketing_New PRIMARY KEY (Email_Marketing_ID),
    CONSTRAINT FK_MTDM_EM FOREIGN KEY (MTDM_ID) REFERENCES Marketing_Tech_Digital_Marketing(MTDM_ID),
    CONSTRAINT FK_Team_Leader_EM FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Status_EM CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Affiliate Marketing Team Table
CREATE TABLE Affiliate_Marketing (
    AM_ID                   	INT NOT NULL,
    MTDM_ID                 	INT NOT NULL,
    Team_Leader_ID          	INT NOT NULL,
    Affiliate_Name          	VARCHAR2(100),
    Platform_Used           	VARCHAR2(100),
    Commission_Rate         	NUMBER,
    Total_Conversions       	INT NOT NULL,
    Team_Size               	INT NOT NULL,
    Status                  	VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date      	DATE,
    Project_End_Date          	DATE,

    CONSTRAINT PK_Affiliate_Marketing PRIMARY KEY (AM_ID),
    CONSTRAINT FK_AM_MTDM FOREIGN KEY (MTDM_ID) REFERENCES Marketing_Tech_Digital_Marketing(MTDM_ID),
    CONSTRAINT FK_AM_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_AM_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Marketing Automation Team Table
CREATE TABLE Marketing_Automation (
    MA_ID                   	INT NOT NULL,
    MTDM_ID                 	INT NOT NULL,
    Team_Leader_ID          	INT NOT NULL,
    Platform_Used           	VARCHAR2(100),
    Automated_Campaigns     	INT NOT NULL,
    Leads_Generated         	INT NOT NULL,
    Last_Updated_Date       	DATE,
    Team_Size               	INT NOT NULL,
    Status                  	VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date      	DATE,
    Project_End_Date        	DATE,

    CONSTRAINT PK_MA_NEW PRIMARY KEY (MA_ID),
    CONSTRAINT FK_MTDM_MA FOREIGN KEY (MTDM_ID) REFERENCES Marketing_Tech_Digital_Marketing(MTDM_ID),
    CONSTRAINT FK_Team_Leader_MA FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Status_MA CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Analytics & Reporting Team Table
CREATE TABLE Analytics_Reporting (
    AR_ID                     		INT NOT NULL,
    MTDM_ID                   		INT NOT NULL,
    Team_Leader_ID            		INT NOT NULL,
    Tools_Used                		VARCHAR2(100),
    Monthly_Reports_Generated 		INT NOT NULL,
    KPIs_Tracked              		VARCHAR2(100),
    Last_Updated_Date         		DATE,
    Team_Size                 		INT NOT NULL,
    Status                    		VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date        		DATE,
    Project_End_Date          		DATE,

    CONSTRAINT PK_AR_NEW PRIMARY KEY (AR_ID),
    CONSTRAINT FK_MTDM_AR FOREIGN KEY (MTDM_ID) REFERENCES Marketing_Tech_Digital_Marketing(MTDM_ID),
    CONSTRAINT FK_Team_Leader_AR FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Status_AR CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Conversion Rate Optimization (CRO) Team Table
CREATE TABLE Conversion_Rate_Optimization (
    CRO_ID                   INT NOT NULL,
    MTDM_ID                  INT NOT NULL,
    Team_Leader_ID           INT NOT NULL,
    Tools_Used               VARCHAR2(100),
    AB_Tests_Active          INT NOT NULL,
    Conversion_Rate          NUMBER,
    Improvement_Notes        VARCHAR2(100),
    Team_Size                INT NOT NULL,
    Status                   VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date       DATE,
    Project_End_Date         DATE,

    CONSTRAINT PK_CRO PRIMARY KEY (CRO_ID),
    CONSTRAINT FK_CRO_MTDM FOREIGN KEY (MTDM_ID) REFERENCES Marketing_Tech_Digital_Marketing(MTDM_ID),
    CONSTRAINT FK_CRO_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_CRO_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Branding & Creative Strategy Team Table
CREATE TABLE Branding_Creative_Strategy (
    Branding_Creative_Strategy_ID   	    INT NOT NULL,
    MTDM_ID                          	    INT NOT NULL,
    Team_Leader_ID                   	    INT NOT NULL,
    Brand_Guidelines_Link            	    VARCHAR2(150),
    Active_Campaigns                 	    INT NOT NULL,
    Visual_Style                     	    VARCHAR2(100),
    Tone_Of_Voice                    	    VARCHAR2(100),
    Team_Size                        	    INT NOT NULL,
    Status                           	    VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date               	    DATE,
    Project_End_Date          		        DATE,

    CONSTRAINT PK_BCS PRIMARY KEY (Branding_Creative_Strategy_ID),
    CONSTRAINT FK_BCS_MTDM FOREIGN KEY (MTDM_ID) REFERENCES Marketing_Tech_Digital_Marketing(MTDM_ID),
    CONSTRAINT FK_BCS_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_BCS_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Influencer Marketing Team Table
CREATE TABLE Influencer_Marketing (
    Influencer_Marketing_ID       INT NOT NULL,
    MTDM_ID                      INT NOT NULL,
    Team_Leader_ID               INT NOT NULL,
    Influencer_Name              VARCHAR2(100),
    Platform                    VARCHAR2(100),
    Audience_Size                INT NOT NULL,
    Campaign_Name                VARCHAR2(100),
    Team_Size                   INT NOT NULL,
    Status                      VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date           DATE,
    Project_End_Date             DATE,

    CONSTRAINT PK_Influencer_Marketing PRIMARY KEY (Influencer_Marketing_ID),
    CONSTRAINT FK_Influencer_MTDM FOREIGN KEY (MTDM_ID) REFERENCES Marketing_Tech_Digital_Marketing(MTDM_ID),
    CONSTRAINT FK_Influencer_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Influencer_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);