--Oracle APEX 23.2.4 SQL
--Schema: Aplicatie management firma IT
--ANDREEA.HASAN@STUDENT.UPT.RO

--			Product Management

--Product Strategy & Planning
--Product Ownership
--Technical Product Management
--Growth Product Management
--Platform Product Management
--Customer Experience & Feedback
--Product Analytics & Metrics
--Product Marketing Coordination
--Innovation & Idea Management
--Product Compliance & Risk

--Main table for the Product Management Department
CREATE TABLE Product_Management (
    Product_ID           	INT NOT NULL,
    Description             VARCHAR2(200),
    Team_Leader_ID       	INT NOT NULL,
    Area                 	VARCHAR2(100),
    Team_Size            	INT NOT NULL,
    Status               	VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date   	DATE,
    Project_End_Date        DATE,

    CONSTRAINT PK_Product PRIMARY KEY (Product_ID),
    CONSTRAINT FK_ProductMgmt_TeamLeader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_ProductMgmt_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Product Strategy & Planning Team Table
CREATE TABLE Product_Strategy_Planning (
    PSP_ID               	INT NOT NULL,
    Product_ID           	INT NOT NULL,
    Team_Leader_ID       	INT NOT NULL,
    Strategy             	VARCHAR2(100),
    Market_Analysis      	VARCHAR2(200),
    Roadmap_Goals        	VARCHAR2(100),
    Team_Size            	INT NOT NULL,
    Status               	VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date   	DATE,
    Project_End_Date        DATE,

    CONSTRAINT PK_PSP PRIMARY KEY (PSP_ID),
    CONSTRAINT FK_PSP_Product FOREIGN KEY (Product_ID) REFERENCES Product_Management(Product_ID),
    CONSTRAINT FK_PSP_TeamLeader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_PSP_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Product Ownership Team Table
CREATE TABLE Product_Ownership (
    PO_ID               	INT NOT NULL,
    Product_ID          	INT NOT NULL,
    Team_Leader_ID      	INT NOT NULL,
    Product_Name        	VARCHAR2(100),
    Backlog_Items       	VARCHAR2(100),
    Priorities          	VARCHAR2(100),
    Sprint_Goals        	VARCHAR2(100),
    Team_Size           	INT NOT NULL,
    Status              	VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date  	DATE,
    Project_End_Date        DATE,

    CONSTRAINT PK_PO PRIMARY KEY (PO_ID),
    CONSTRAINT FK_PO_Product FOREIGN KEY (Product_ID) REFERENCES Product_Management(Product_ID),
    CONSTRAINT FK_PO_TeamLeader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_PO_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Technical Product Management Team Table
CREATE TABLE Technical_Product_Management (
    TPM_ID INT NOT NULL,
    Product_ID INT NOT NULL,
    Team_Leader_ID INT NOT NULL,
    Product_Name VARCHAR2(100),
    Requirements VARCHAR2(100),
    Development_Approach VARCHAR2(100),
    Technology_Used VARCHAR2(100),
    Team_Size INT NOT NULL,
    Status VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date DATE,
    Project_End_Date DATE,

    CONSTRAINT PK_TPM PRIMARY KEY (TPM_ID),
    CONSTRAINT FK_TPM_Product FOREIGN KEY (Product_ID) REFERENCES Product_Management(Product_ID),
    CONSTRAINT FK_TPM_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_TPM_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Growth Product Management Team Table
CREATE TABLE Growth_Product_Management (
    GPM_ID INT NOT NULL,
    Product_ID INT NOT NULL,
    Team_Leader_ID INT NOT NULL,
    Product_Name VARCHAR2(100),
    Strategy VARCHAR2(100),
    KPI VARCHAR2(100),
    User_Segmentation VARCHAR2(100),
    Team_Size INT NOT NULL,
    Status VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date DATE,
    Project_End_Date DATE,

    CONSTRAINT PK_GPM PRIMARY KEY (GPM_ID),
    CONSTRAINT FK_GPM_Product FOREIGN KEY (Product_ID) REFERENCES Product_Management(Product_ID),
    CONSTRAINT FK_GPM_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_GPM_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Platform Product Management Team Table
CREATE TABLE Platform_Product_Management (
    PPM_ID INT NOT NULL,
    Product_ID INT NOT NULL,
    Team_Leader_ID INT NOT NULL,
    Platform_Name VARCHAR2(100),
    Platform_Description VARCHAR2(200),
    API_Documentation VARCHAR2(100),
    Internal_Tools VARCHAR2(100),
    Team_Size INT NOT NULL,
    Status VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date DATE,
    Project_End_Date DATE,

    CONSTRAINT PK_PPM PRIMARY KEY (PPM_ID),
    CONSTRAINT FK_PPM_Product FOREIGN KEY (Product_ID) REFERENCES Product_Management(Product_ID),
    CONSTRAINT FK_PPM_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_PPM_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Customer Experience & Feedback Team Table
CREATE TABLE CEF (
    CEF_ID INT NOT NULL,
    Product_ID INT NOT NULL,
    Team_Leader_ID INT NOT NULL,
    Feedback_Type VARCHAR2(100),
    Customer_Feedback VARCHAR2(100),
    Feedback_Source VARCHAR2(100),
    Customer_Rating NUMBER,
    Team_Size INT NOT NULL,
    Status VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date DATE,
    Project_End_Date DATE,

    CONSTRAINT PK_CEF PRIMARY KEY (CEF_ID),
    CONSTRAINT FK_CEF_Product FOREIGN KEY (Product_ID) REFERENCES Product_Management(Product_ID),
    CONSTRAINT FK_CEF_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_CEF_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Product Analytics & Metrics Team Table
CREATE TABLE PAM (
    PAM_ID INT NOT NULL,
    Product_ID INT NOT NULL,
    Team_Leader_ID INT NOT NULL,
    Product_Name VARCHAR2(100),
    Metric_Type VARCHAR2(100),
    Metric_Value INT NOT NULL,
    Data_Collected_Date DATE,
    Analysis VARCHAR2(100),
    Team_Size INT NOT NULL,
    Status VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date DATE,
    Project_End_Date DATE,

    CONSTRAINT PK_PAM PRIMARY KEY (PAM_ID),
    CONSTRAINT FK_PAM_Product FOREIGN KEY (Product_ID) REFERENCES Product_Management(Product_ID),
    CONSTRAINT FK_PAM_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_PAM_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Product Marketing Coordination Team Table
CREATE TABLE PMC (
    PMC_ID INT NOT NULL,
    Product_ID INT NOT NULL,
    Team_Leader_ID INT NOT NULL,
    Product_Name VARCHAR2(100),
    Campaign_Name VARCHAR2(100),
    Channels VARCHAR2(100),
    Launch_Date DATE,
    Target_Audience VARCHAR2(100),
    Team_Size INT NOT NULL,
    Status VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date DATE,
    Project_End_Date DATE,

    CONSTRAINT PK_PMC PRIMARY KEY (PMC_ID),
    CONSTRAINT FK_PMC_Product FOREIGN KEY (Product_ID) REFERENCES Product_Management(Product_ID),
    CONSTRAINT FK_PMC_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_PMC_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Innovation & Idea Management Team Table
CREATE TABLE IIM (
    IIM_ID INT NOT NULL,
    Product_ID INT NOT NULL,
    Team_Leader_ID INT NOT NULL,
    Idea_Title VARCHAR2(100),
    Idea_Description VARCHAR2(100),
    Submission_Date DATE,
    Evaluation_Status VARCHAR2(50) CHECK (Evaluation_Status IN ('Pending', 'Approved', 'Rejected')),
    Implementation_Status VARCHAR2(50) CHECK (Implementation_Status IN ('Not Started', 'In Progress', 'Completed', 'Cancelled')),
    Estimated_Impact VARCHAR2(100),
    Team_Size INT NOT NULL,
    Status VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date DATE,
    Project_End_Date DATE,

    CONSTRAINT PK_IIM PRIMARY KEY (IIM_ID),
    CONSTRAINT FK_IIM_Product FOREIGN KEY (Product_ID) REFERENCES Product_Management(Product_ID),
    CONSTRAINT FK_IIM_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_IIM_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Product Compliance & Risk Team Table
CREATE TABLE PCR (
    PCR_ID INT NOT NULL,
    Product_ID INT NOT NULL,
    Team_Leader_ID INT NOT NULL,
    Product_Name VARCHAR2(100),
    Compliance_Area VARCHAR2(100),
    Compliance_Status VARCHAR2(100) CHECK (Compliance_Status IN ('Pending', 'Compliant', 'Non-Compliant')),
    Risk_Level VARCHAR2(50),
    Risk_Description VARCHAR2(200),
    Audit_Date DATE,
    Team_Size INT NOT NULL,
    Status VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date DATE,
    Project_End_Date DATE,

    CONSTRAINT PK_PCR PRIMARY KEY (PCR_ID),
    CONSTRAINT FK_PCR_Product FOREIGN KEY (Product_ID) REFERENCES Product_Management(Product_ID),
    CONSTRAINT FK_PCR_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_PCR_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);