CREATE OR REPLACE VIEW QA_Testing_Calendar AS
SELECT 
    QA_ID AS Project_ID,
    'General QA Testing' AS Project_Type,
    Description AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM QA_Testing

UNION ALL

SELECT 
    Manual_Testing_ID,
    'Manual Testing',
    Test_Types AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Manual_Testing

UNION ALL

SELECT 
    Automated_Testing_ID,
    'Automated Testing',
    Frameworks || ' / ' || Languages AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Automated_Testing

UNION ALL

SELECT 
    Performance_Testing_ID,
    'Performance Testing',
    Test_Types AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Performance_Testing

UNION ALL

SELECT 
    Security_Testing_ID,
    'Security Testing',
    Methods AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Security_Testing

UNION ALL

SELECT 
    Mobile_Testing_ID,
    'Mobile Testing',
    Tested_Platforms || ' / ' || Devices AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Mobile_Testing

UNION ALL

SELECT 
    UI_UX_Testing_ID,
    'UI/UX Testing',
    Devices_Resolutions AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM UI_UX_Testing;

CREATE OR REPLACE VIEW QA_Teams_View AS
SELECT
    'Manual Testing' AS Team_Type,
    mt.Manual_Testing_ID AS Team_ID,
    mt.QA_ID,
    mt.Team_Leader_ID,
    mt.Test_Types AS Main_Focus,
    mt.Status,
    mt.Team_Size,
    mt.Project_Start_Date,
    mt.Project_End_Date
FROM Manual_Testing mt

UNION ALL

SELECT
    'Automated Testing',
    at.Automated_Testing_ID,
    at.QA_ID,
    at.Team_Leader_ID,
    at.Frameworks || ', ' || at.Languages,
    at.Status,
    at.Team_Size,
    at.Project_Start_Date,
    at.Project_End_Date
FROM Automated_Testing at

UNION ALL

SELECT
    'Performance Testing',
    pt.Performance_Testing_ID,
    pt.QA_ID,
    pt.Team_Leader_ID,
    pt.Test_Types || ', ' || pt.Tools,
    pt.Status,
    pt.Team_Size,
    pt.Project_Start_Date,
    pt.Project_End_Date
FROM Performance_Testing pt

UNION ALL

SELECT
    'Security Testing',
    st.Security_Testing_ID,
    st.QA_ID,
    st.Team_Leader_ID,
    st.Methods || ', ' || st.Tools,
    st.Status,
    st.Team_Size,
    st.Project_Start_Date,
    st.Project_End_Date
FROM Security_Testing st

UNION ALL

SELECT
    'Mobile Testing',
    mt.Mobile_Testing_ID,
    mt.QA_ID,
    mt.Team_Leader_ID,
    mt.Tested_Platforms || ', ' || mt.Devices,
    mt.Status,
    mt.Team_Size,
    mt.Project_Start_Date,
    mt.Project_End_Date
FROM Mobile_Testing mt

UNION ALL

SELECT
    'UI/UX Testing',
    ux.UI_UX_Testing_ID,
    ux.QA_ID,
    ux.Team_Leader_ID,
    ux.Design_Guidelines || ', ' || ux.Tools,
    ux.Status,
    ux.Team_Size,
    ux.Project_Start_Date,
    ux.Project_End_Date
FROM UI_UX_Testing ux;
