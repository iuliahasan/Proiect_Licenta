--Oracle APEX 23.2.4 SQL
--Schema: Aplicatie management firma IT
--ANDREEA.HASAN@STUDENT.UPT.RO

--			Customer Success / Client Support IT

--L1 Support (Level 1 / Frontline Support)
--L2 Support (Technical Support)
--L3 Support (Expert Support / Engineering Support)
--Incident Management
--Service Request Management
--IT Asset Management
--Desktop Support
--Remote Support
--Knowledge Management
--VIP / Executive Support
--Service Desk Coordination

--Main table for the Customer Success / Client Support IT Department
CREATE TABLE CS_ClientSupport_IT (
    CSCSIT_ID               INT NOT NULL,
    Description             VARCHAR2(200),
    Team_Leader_ID          INT NOT NULL,
    Status                  VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date      DATE,
    Project_End_Date        DATE,

    CONSTRAINT PK_CSCSIT PRIMARY KEY (CSCSIT_ID),
    CONSTRAINT FK_CSCSIT_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_CSCSIT_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--L1 Support (Level 1 / Frontline Support) Team Table
CREATE TABLE L1_Support_New (
    L1S_ID              	    INT NOT NULL,
    CSCSIT_ID           	    INT NOT NULL,
    Team_Leader_ID      	    INT NOT NULL,
    Support_Channel     	    VARCHAR2(100),
    Shift_Schedule      	    VARCHAR2(100),
    Ticket_Volume       	    INT NOT NULL,
    Languages_Supported 	    VARCHAR2(100),
    Team_Size           	    INT NOT NULL,
    Status              	    VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date  	    DATE,
    Project_End_Date          	DATE,

    CONSTRAINT PK_L1_Support_New PRIMARY KEY (L1S_ID),
    CONSTRAINT FK_CSCSIT_L1_New FOREIGN KEY (CSCSIT_ID) REFERENCES CS_ClientSupport_IT(CSCSIT_ID),
    CONSTRAINT FK_Team_Leader_L1_New FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Status_L1_New CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--L2 Support (Technical Support) Team Table
CREATE TABLE L2_Support_New (
    L2S_ID               	    INT NOT NULL,
    CSCSIT_ID            	    INT NOT NULL,
    Team_Leader_ID       	    INT NOT NULL,
    Specialization_Area  	    VARCHAR2(100),
    Escalation_Handling  	    VARCHAR2(100),
    Toolsets             	    VARCHAR2(100),
    Resolution_Time      	    NUMBER,
    Team_Size            	    INT NOT NULL,
    Status               	    VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date   	    DATE,
    Project_End_Date          	DATE,

    CONSTRAINT PK_L2_Support_New PRIMARY KEY (L2S_ID),
    CONSTRAINT FK_CSCSIT_L2_New FOREIGN KEY (CSCSIT_ID) REFERENCES CS_ClientSupport_IT(CSCSIT_ID),
    CONSTRAINT FK_Team_Leader_L2_New FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Status_L2_New CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--L3 Support (Expert / Engineering Support) Team Table
CREATE TABLE L3_Support_New (
    L3S_ID               	    INT NOT NULL,
    CSCSIT_ID            	    INT NOT NULL,
    Team_Leader_ID       	    INT NOT NULL,
    Tech_Domain          	    VARCHAR2(100),
    Escalated_From_L2    	    INT NOT NULL,
    Root_Cause_Analysis  	    VARCHAR2(100),
    Collab_Dev_Teams     	    VARCHAR2(100),
    Team_Size            	    INT NOT NULL,
    Status               	    VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date   	    DATE,
    Project_End_Date          	DATE,

    CONSTRAINT PK_L3_Support_New PRIMARY KEY (L3S_ID),
    CONSTRAINT FK_CSCSIT_L3_New FOREIGN KEY (CSCSIT_ID) REFERENCES CS_ClientSupport_IT(CSCSIT_ID),
    CONSTRAINT FK_Team_Leader_L3_New FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Status_L3_New CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Incident Management Team Table
CREATE TABLE Incident_Management_New (
    IM_ID                      		INT NOT NULL,
    CSCSIT_ID                  		INT NOT NULL,
    Team_Leader_ID             		INT NOT NULL,
    Incident_Policy_ID         		INT,
    Incident_Severity_Levels   		VARCHAR2(100),
    Incident_Response_Time     		INT NOT NULL,
    Incident_Resolution_Time   		INT NOT NULL,
    Team_Size                  		INT NOT NULL,
    Status                     		VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date         		DATE,
    Project_End_Date          		DATE,

    CONSTRAINT PK_Incident_Management_New PRIMARY KEY (IM_ID),
    CONSTRAINT FK_CSCSIT_Incident_New FOREIGN KEY (CSCSIT_ID) REFERENCES CS_ClientSupport_IT(CSCSIT_ID),
    CONSTRAINT FK_Team_Leader_Incident_New FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Status_Incident_New CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Service Request Management Team Table
CREATE TABLE Service_Request_Management_New (
    SRM_ID                 	    INT NOT NULL,
    CSCSIT_ID              	    INT NOT NULL,
    Team_Leader_ID         	    INT NOT NULL,
    Request_Types_Handled  	    VARCHAR2(100),
    Completion_Time        	    NUMBER,
    Request_Channels       	    VARCHAR2(100),
    Automation_Used        	    VARCHAR2(100),
    Team_Size              	    INT NOT NULL,
    Status                 	    VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date     	    DATE,
    Project_End_Date          	DATE,

    CONSTRAINT PK_SRM_New PRIMARY KEY (SRM_ID),
    CONSTRAINT FK_CSCSIT_SRM_New FOREIGN KEY (CSCSIT_ID) REFERENCES CS_ClientSupport_IT(CSCSIT_ID),
    CONSTRAINT FK_Team_Leader_SRM_New FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Status_SRM_New CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--IT Asset Management Team Table
CREATE TABLE IT_Asset_Management_New (
    ITAM_ID             	    INT NOT NULL,
    CSCSIT_ID           	    INT NOT NULL,
    Team_Leader_ID      	    INT NOT NULL,
    Asset_Type          	    VARCHAR2(100),
    Asset_Status        	    VARCHAR2(100),
    Asset_Location      	    VARCHAR2(100),
    Asset_Purchase_Date 	    DATE,
    Warranty_Expiry     	    DATE,
    Asset_Value         	    NUMBER,
    Serial_Number       	    VARCHAR2(100),
    Team_Size           	    INT NOT NULL,
    Status              	    VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date  	    DATE,
    Project_End_Date          	DATE,

    CONSTRAINT PK_ITAM_New PRIMARY KEY (ITAM_ID),
    CONSTRAINT FK_CSCSIT_ITAM_New FOREIGN KEY (CSCSIT_ID) REFERENCES CS_ClientSupport_IT(CSCSIT_ID),
    CONSTRAINT FK_Team_Leader_ITAM_New FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Status_ITAM_New CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Desktop Support Team Table
CREATE TABLE Desktop_Support_New (
    Desktop_Support_ID     	    INT NOT NULL,
    CSCSIT_ID              	    INT NOT NULL,
    Team_Leader_ID         	    INT NOT NULL,
    Support_Level          	    VARCHAR2(10),
    Team_Size              	    INT NOT NULL,
    Status                 	    VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date     	    DATE,
    Project_End_Date          	DATE,

    CONSTRAINT PK_Desktop_Support_New PRIMARY KEY (Desktop_Support_ID),
    CONSTRAINT FK_CSCSIT_Desktop_New FOREIGN KEY (CSCSIT_ID) REFERENCES CS_ClientSupport_IT(CSCSIT_ID),
    CONSTRAINT FK_Team_Leader_Desktop_New FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Status_Desktop_New CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Remote Support Team Table
CREATE TABLE Remote_Support_New (
    RS_ID               	    INT NOT NULL,
    CSCSIT_ID           	    INT NOT NULL,
    Team_Leader_ID      	    INT NOT NULL,
    Support_Level       	    VARCHAR2(5),
    Team_Size           	    INT NOT NULL,
    Status              	    VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date  	    DATE,
    Project_End_Date          	DATE,

    CONSTRAINT PK_RS_New PRIMARY KEY (RS_ID),
    CONSTRAINT FK_CSCSIT_RS_New FOREIGN KEY (CSCSIT_ID) REFERENCES CS_ClientSupport_IT(CSCSIT_ID),
    CONSTRAINT FK_Team_Leader_RS_New FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Status_RS_New CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Knowledge Management Team Table
CREATE TABLE Knowledge_Management_New (
    KM_ID               	    INT NOT NULL,
    CSCSIT_ID           	    INT NOT NULL,
    Team_Leader_ID      	    INT NOT NULL,
    Documentation_Type  	    VARCHAR2(100),
    Documentation_Status 	    VARCHAR2(100),
    Last_Updated        	    DATE,
    Access_Level        	    VARCHAR2(50),
    Team_Size           	    INT NOT NULL,
    Status              	    VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date  	    DATE,
    Project_End_Date          	DATE,

    CONSTRAINT PK_KM_New PRIMARY KEY (KM_ID),
    CONSTRAINT FK_CSCSIT_KM_New FOREIGN KEY (CSCSIT_ID) REFERENCES CS_ClientSupport_IT(CSCSIT_ID),
    CONSTRAINT FK_Team_Leader_KM_New FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Status_KM_New CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--VIP / Executive Support Team Table
CREATE TABLE VIP_Executive_Support (
    VIPES_ID                    	    INT NOT NULL,
    CSCSIT_ID                  		    INT NOT NULL,
    Team_Leader_ID             		    INT NOT NULL,
    Support_Level              		    VARCHAR2(5),
    VIP_Client_ID              		    INT NOT NULL,
    Support_Request_Description 	    VARCHAR2(200),
    Request_Date               		    DATE,
    Resolution_Date            		    DATE,
    Team_Size                  		    INT NOT NULL,
    Status                    		    VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date         		    DATE,
    Project_End_Date          		    DATE,

    CONSTRAINT PK_VIPES PRIMARY KEY (VIPES_ID),
    CONSTRAINT FK_VIPES_CSCSIT FOREIGN KEY (CSCSIT_ID) REFERENCES CS_ClientSupport_IT(CSCSIT_ID),
    CONSTRAINT FK_VIPES_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT FK_VIPES_VIP_Client FOREIGN KEY (VIP_Client_ID) REFERENCES VIP_Clients(Client_ID),
    CONSTRAINT CHK_VIPES_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Service Desk Coordination Team Table
CREATE TABLE Service_Desk_Coordination (
    SDC_ID                   	INT NOT NULL,
    CSCSIT_ID                	INT NOT NULL,
    Team_Leader_ID           	INT NOT NULL,
    Request_Description      	VARCHAR2(100),
    Request_Date             	DATE,
    Assigned_To_ID           	INT NOT NULL,
    Priority_Request         	VARCHAR2(50),
    Resolution_Date          	DATE,
    Solution_Description     	VARCHAR2(100),
    Escalation_Level         	VARCHAR2(5),
    Status_Update_Date       	DATE,
    Team_Size                	INT NOT NULL,
    Status                   	VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date       	DATE,
    Project_End_Date          	DATE,

    CONSTRAINT PK_SDC PRIMARY KEY (SDC_ID),
    CONSTRAINT FK_SDC_CSCSIT FOREIGN KEY (CSCSIT_ID) REFERENCES CS_ClientSupport_IT(CSCSIT_ID),
    CONSTRAINT FK_SDC_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT FK_SDC_Assigned_To FOREIGN KEY (Assigned_To_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_SDC_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);