CREATE OR REPLACE VIEW Security_Calendar AS
SELECT 
    SC_ID AS Entry_ID,
    'Cybersecurity Core' AS Team_Type,
    'Framework: ' || Security_Framework || ', IRP: ' || Incident_Response_Plan AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Security_Cybersecurity

UNION ALL

SELECT 
    NS_ID,
    'Network Security',
    'Firewalls: ' || Firewall_Brands || ', IDS/IPS: ' || IDS_IPS_Deployed AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Network_Security

UNION ALL

SELECT 
    AppSec_ID,
    'Application Security',
    'Static Tools: ' || Static_Analysis_Tools || ', OWASP: ' || OWASP_Compliance_Level AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Application_Security

UNION ALL

SELECT 
    ES_ID,
    'Endpoint Security',
    'EPP: ' || Endpoint_Protection_Platform || ', Encryption: ' || Device_Encryption AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Endpoint_Security

UNION ALL

SELECT 
    IAM_ID,
    'IAM',
    'IAM: ' || IAM_Platform || ', MFA: ' || MFA_Enforced || ', SSO: ' || SSO_Implemented AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM IAM

UNION ALL

SELECT 
    TIA_ID,
    'Threat Intelligence',
    'Feeds: ' || Intel_Feeds || ', SIEM: ' || SIEM_Integrated AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM TIA;

CREATE OR REPLACE VIEW Security_Cybersecurity_Teams_View AS
SELECT
    'Network Security' AS Team_Type,
    ns.NS_ID AS Team_ID,
    ns.SC_ID,
    ns.Team_Leader_ID,
    'Firewalls: ' || ns.Firewall_Brands || ', IDS/IPS: ' || ns.IDS_IPS_Deployed || ', VPN: ' || ns.VPN_Type || ', Segmentation: ' || ns.Network_Segmentation AS Description,
    ns.Status,
    ns.Team_Size,
    ns.Project_Start_Date,
    ns.Project_End_Date
FROM Network_Security ns

UNION ALL

SELECT
    'Application Security',
    aps.AppSec_ID,
    aps.SC_ID,
    aps.Team_Leader_ID,
    'Static Tools: ' || aps.Static_Analysis_Tools || ', Dynamic: ' || aps.Dynamic_Analysis || ', Guidelines: ' || aps.Secure_Coding_Guidelines || ', OWASP: ' || aps.OWASP_Compliance_Level,
    aps.Status,
    aps.Team_Size,
    aps.Project_Start_Date,
    aps.Project_End_Date
FROM Application_Security aps

UNION ALL

SELECT
    'Endpoint Security',
    es.ES_ID,
    es.SC_ID,
    es.Team_Leader_ID,
    'Platform: ' || es.Endpoint_Protection_Platform || ', Encryption: ' || es.Device_Encryption || ', Patching: ' || es.Patch_Management_Automated || ', OS List: ' || es.Allowed_OS_List,
    es.Status,
    es.Team_Size,
    es.Project_Start_Date,
    es.Project_End_Date
FROM Endpoint_Security es

UNION ALL

SELECT
    'IAM',
    iam.IAM_ID,
    iam.SC_ID,
    iam.Team_Leader_ID,
    'SSO: ' || iam.SSO_Implemented || ', MFA: ' || iam.MFA_Enforced || ', Platform: ' || iam.IAM_Platform || ', Roles: ' || iam.Roles_Defined,
    iam.Status,
    iam.Team_Size,
    iam.Project_Start_Date,
    iam.Project_End_Date
FROM IAM iam

UNION ALL

SELECT
    'Threat Intelligence',
    tia.TIA_ID,
    tia.SC_ID,
    tia.Team_Leader_ID,
    'Feeds: ' || tia.Intel_Feeds || ', Reports: ' || tia.Threat_Report_Count || ', SIEM: ' || tia.SIEM_Integrated || ', Sources: ' || tia.External_Threat_Sources,
    tia.Status,
    tia.Team_Size,
    tia.Project_Start_Date,
    tia.Project_End_Date
FROM TIA tia;
