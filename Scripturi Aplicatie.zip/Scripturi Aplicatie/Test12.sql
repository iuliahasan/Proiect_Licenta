CREATE OR REPLACE VIEW CSClientSupport_Calendar AS
SELECT 
    CSCSIT_ID AS Entry_ID,
    'Client Support - Core' AS Team_Type,
    'CS Description: ' || Description AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM CS_ClientSupport_IT

UNION ALL

SELECT 
    Desktop_Support_ID,
    'Desktop Support',
    'Support Level: ' || Support_Level || ', Team Size: ' || Team_Size AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Desktop_Support

UNION ALL

SELECT 
    RS_ID,
    'Remote Support',
    'Support Level: ' || Support_Level || ', Team Size: ' || Team_Size AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Remote_Support

UNION ALL

SELECT 
    KM_ID,
    'Knowledge Management',
    'Type: ' || Documentation_Type || ', Access: ' || Access_Level AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Knowledge_Management

UNION ALL

SELECT 
    VIPES_ID,
    'VIP/Executive Support',
    'VIP Support: ' || Support_Request_Description || ', Client ID: ' || VIP_Client_ID AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM VIP_Executive_Support

UNION ALL

SELECT 
    SDC_ID,
    'Service Desk Coordination',
    'Request: ' || Request_Description || ', Priority: ' || Priority_Request AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Service_Desk_Coordination;

CREATE OR REPLACE VIEW ClientSupport_IT_Teams_View AS
SELECT
    'Desktop Support' AS Team_Type,
    ds.Desktop_Support_ID AS Team_ID,
    ds.CSCSIT_ID,
    ds.Team_Leader_ID,
    'Support Level: ' || ds.Support_Level AS Description,
    ds.Status,
    ds.Team_Size,
    ds.Project_Start_Date,
    ds.Project_End_Date
FROM Desktop_Support ds

UNION ALL

SELECT
    'Remote Support',
    rs.RS_ID,
    rs.CSCSIT_ID,
    rs.Team_Leader_ID,
    'Support Level: ' || rs.Support_Level,
    rs.Status,
    rs.Team_Size,
    rs.Project_Start_Date,
    rs.Project_End_Date
FROM Remote_Support rs

UNION ALL

SELECT
    'Knowledge Management',
    km.KM_ID,
    km.CSCSIT_ID,
    km.Team_Leader_ID,
    'Doc Type: ' || km.Documentation_Type || ', Status: ' || km.Documentation_Status || ', Access: ' || km.Access_Level,
    km.Status,
    km.Team_Size,
    km.Project_Start_Date,
    km.Project_End_Date
FROM Knowledge_Management km

UNION ALL

SELECT
    'VIP / Executive Support',
    vip.VIPES_ID,
    vip.CSCSIT_ID,
    vip.Team_Leader_ID,
    'Support Level: ' || vip.Support_Level || ', VIP Client ID: ' || vip.VIP_Client_ID || ', Description: ' || vip.Support_Request_Description,
    vip.Status,
    vip.Team_Size,
    vip.Project_Start_Date,
    vip.Project_End_Date
FROM VIP_Executive_Support vip

UNION ALL

SELECT
    'Service Desk Coordination',
    sdc.SDC_ID,
    sdc.CSCSIT_ID,
    sdc.Team_Leader_ID,
    'Request: ' || sdc.Request_Description || ', Priority: ' || sdc.Priority_Request || ', Escalation: ' || sdc.Escalation_Level,
    sdc.Status,
    sdc.Team_Size,
    sdc.Project_Start_Date,
    sdc.Project_End_Date
FROM Service_Desk_Coordination sdc;
