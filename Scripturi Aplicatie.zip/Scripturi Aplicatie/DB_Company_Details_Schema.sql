--Oracle APEX 23.2.4 SQL
--Schema: Aplicatie management firma IT
--ANDREEA.HASAN@STUDENT.UPT.RO

--Software Development
--QA & Testing (Quality Assurance)
--Project Management
--IT Support / Helpdesk
--Infrastructure / SysAdmin / Network
--UI/UX Design
--Research & Development (R&D)
--Product Management
--Data / BI / Analytics
--Security / Cybersecurity
--DevOps / SRE (Site Reliability Engineering)
--Customer Success / Client Support IT
--HR / Recrutare Tech
--Sales & Presales IT
--Marketing Tech / Digital Marketing

--Employees Table
CREATE TABLE Employees (
    Employee_ID      		    INT NOT NULL,
    First_Name       		    VARCHAR2(50) NOT NULL,
    Last_Name        		    VARCHAR2(50) NOT NULL,
    Email            		    VARCHAR2(100) UNIQUE NOT NULL,
    Phone_Number     		    VARCHAR2(20),
    Hire_Date        		    DATE NOT NULL,
    Job_Title        		    VARCHAR2(100),
    Department       		    VARCHAR2(100),
    Status           		    VARCHAR2(30) DEFAULT 'Active' NOT NULL,
    Username                    VARCHAR2(50) UNIQUE,
    Password_Hash               VARCHAR2(200),
    Role                        VARCHAR2(30),

    CONSTRAINT PK_Employee PRIMARY KEY (Employee_ID),
    CONSTRAINT CHK_Employee_Status CHECK (Status IN ('Active', 'Inactive', 'On Leave'))
);

--VIP Clients Table
CREATE TABLE VIP_Clients (
    Client_ID          		    INT NOT NULL,
    Client_Name        		    VARCHAR2(100) NOT NULL,
    Contact_Person     		    VARCHAR2(100),
    Email              		    VARCHAR2(100),
    Phone_Number       		    VARCHAR2(20),
    Client_Since       		    DATE,
    VIP_Level          		    VARCHAR2(20) CHECK (VIP_Level IN ('Gold', 'Platinum', 'Diamond')),
    Account_Manager_ID 		    INT,
    Annual_Revenue     		    NUMBER(12,2),
    Status             		    VARCHAR2(30) DEFAULT 'Active' CHECK (Status IN ('Active', 'Inactive', 'Blacklisted')),
    
    CONSTRAINT PK_VIP_Clients PRIMARY KEY (Client_ID),
    CONSTRAINT FK_Account_Manager FOREIGN KEY (Account_Manager_ID) REFERENCES Employees(Employee_ID)
);

--Customers Table
CREATE TABLE Customers (
    Customer_ID        		    INT NOT NULL,
    Customer_Name      		    VARCHAR2(100) NOT NULL,
    Contact_Person     		    VARCHAR2(100),
    Email              		    VARCHAR2(100),
    Phone_Number       		    VARCHAR2(20),
    Address            		    VARCHAR2(200),
    City               		    VARCHAR2(50),
    Country            		    VARCHAR2(50),
    Registration_Date  		    DATE,
    Customer_Type      		    VARCHAR2(30) CHECK (Customer_Type IN ('Individual', 'Company', 'VIP')),
    Status             		    VARCHAR2(30) DEFAULT 'Active' CHECK (Status IN ('Active', 'Inactive', 'Blacklisted')),

    CONSTRAINT PK_Customers PRIMARY KEY (Customer_ID)
);

--Departments Table
CREATE TABLE Departments (
    Department_ID     		    INT NOT NULL,
    Department_Name   		    VARCHAR2(100) NOT NULL,
    Description       		    VARCHAR2(200),
    Manager_ID        		    INT,
    Location          		    VARCHAR2(100),
    Status            		    VARCHAR2(30) DEFAULT 'Active' CHECK (Status IN ('Active', 'Inactive')),
    
    CONSTRAINT PK_Departments PRIMARY KEY (Department_ID),
    CONSTRAINT FK_Manager FOREIGN KEY (Manager_ID) REFERENCES Employees(Employee_ID)
);