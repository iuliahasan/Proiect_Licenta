CREATE OR REPLACE VIEW RD_Calendar AS
SELECT 
    RD_ID AS Entry_ID,
    'General R&D' AS Team_Type,
    'Domain: ' || Domain || ', Goal: ' || Goal AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Research_Development

UNION ALL

SELECT 
    Scientific_ID,
    'Scientific Research',
    'Domain: ' || Domain || ', Collab: ' || Academic_Collaborations AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Scientific_Research

UNION ALL

SELECT 
    Technological_ID,
    'Technological Innovation',
    'Area: ' || Innovation_Area || ', Patent: ' || Patent_Pending AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Technological_Innovation

UNION ALL

SELECT 
    Hardware_ID,
    'Hardware Development',
    'Prototype: ' || Prototype_Name || ', 3D Printed: ' || Is_3D_Printed AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Hardware_Development

UNION ALL

SELECT 
    Market_ID,
    'Market Research',
    'Target: ' || Target_Market || ', Compet. Analysis: ' || Competition_Analysis AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Market_Research

UNION ALL

SELECT 
    Experimental_ID,
    'Experimental Projects',
    'Project: ' || Project_Name || ', Risk: ' || Risk_Level || ', Funded: ' || Funding AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Experimental_Projects

UNION ALL

SELECT 
    Testing_ID,
    'Testing & Validation',
    'Prototype: ' || Prototype || ', Validated: ' || Validated AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Testing_Validation;

CREATE OR REPLACE VIEW Research_Development_Teams_View AS
SELECT
    'Scientific Research' AS Team_Type,
    sr.Scientific_ID AS Team_ID,
    sr.RD_ID,
    sr.Team_Leader_ID,
    'Domain: ' || sr.Domain || ', Collaborations: ' || sr.Academic_Collaborations AS Description,
    sr.Status,
    sr.Team_Size,
    sr.Project_Start_Date,
    sr.Project_End_Date
FROM Scientific_Research sr

UNION ALL

SELECT
    'Technological Innovation',
    ti.Technological_ID,
    ti.RD_ID,
    ti.Team_Leader_ID,
    'Innovation Area: ' || ti.Innovation_Area || ', Patent Pending: ' || ti.Patent_Pending || ', Partners: ' || ti.Partner_Companies,
    ti.Status,
    ti.Team_Size,
    ti.Project_Start_Date,
    ti.Project_End_Date
FROM Technological_Innovation ti

UNION ALL

SELECT
    'Hardware Development',
    hd.Hardware_ID,
    hd.RD_ID,
    hd.Team_Leader_ID,
    'Prototype: ' || hd.Prototype_Name || ', Type: ' || hd.Hardware_Type || ', 3D Printed: ' || hd.Is_3D_Printed,
    hd.Status,
    hd.Team_Size,
    hd.Project_Start_Date,
    hd.Project_End_Date
FROM Hardware_Development hd

UNION ALL

SELECT
    'Market Research',
    mr.Market_ID,
    mr.RD_ID,
    mr.Team_Leader_ID,
    'Market: ' || mr.Target_Market || ', Methods: ' || mr.Research_Methods || ', Competitive Analysis: ' || mr.Competition_Analysis,
    mr.Status,
    mr.Team_Size,
    mr.Project_Start_Date,
    mr.Project_End_Date
FROM Market_Research mr

UNION ALL

SELECT
    'Experimental Projects',
    ep.Experimental_ID,
    ep.RD_ID,
    ep.Team_Leader_ID,
    'Project: ' || ep.Project_Name || ', Type: ' || ep.Experiment_Type || ', Risk: ' || ep.Risk_Level || ', Funding: ' || ep.Funding,
    ep.Status,
    ep.Team_Size,
    ep.Project_Start_Date,
    ep.Project_End_Date
FROM Experimental_Projects ep

UNION ALL

SELECT
    'Testing & Validation',
    tv.Testing_ID,
    tv.RD_ID,
    tv.Team_Leader_ID,
    'Prototype: ' || tv.Prototype || ', Test: ' || tv.Test_Type || ', Validated: ' || tv.Validated,
    tv.Status,
    tv.Team_Size,
    tv.Project_Start_Date,
    tv.Project_End_Date
FROM Testing_Validation tv;
