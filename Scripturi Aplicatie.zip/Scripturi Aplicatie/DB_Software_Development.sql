--Oracle APEX 23.2.4 SQL
--Schema: Aplicatie management firma IT
--ANDREEA.HASAN@STUDENT.UPT.RO

--				Software Development
--Frontend Development
--Backend Development
--Full-Stack Development
--Mobile Development
--DevOps Engineering
--Software Architecture
--Database Development / DBA
--API Development / Integration
--Game Development (dacă firma face jocuri)
--Embedded / IoT Development
--AI / Machine Learning Engineering

-- Software Development Main Table
CREATE TABLE Software_Development (
    Development_ID              INT NOT NULL,
    Description                 VARCHAR2(200),
    Team_Leader_ID              INT NOT NULL,
    Status                      VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date          DATE,
    Project_End_Date            DATE,

    CONSTRAINT PK_Software_Development PRIMARY KEY (Development_ID),
    CONSTRAINT FK_SD_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_SD_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

-- Frontend Team Table
CREATE TABLE Frontend (
    Frontend_ID            		INT NOT NULL,
    Development_ID         		INT NOT NULL,
    Team_Leader_ID         		INT NOT NULL,
    Frameworks             		VARCHAR2(100),
    Technologies           		VARCHAR2(100),
    Team_Size              		INT NOT NULL,
    Status                 		VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date     		DATE,
    Project_End_Date          	DATE,

    CONSTRAINT PK_Frontend PRIMARY KEY (Frontend_ID),
    CONSTRAINT FK_FE_Development FOREIGN KEY (Development_ID) REFERENCES Software_Development(Development_ID),
    CONSTRAINT FK_FE_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_FE_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

-- Backend Team Table
CREATE TABLE Backend (
    Backend_ID             		INT NOT NULL,
    Development_ID         		INT NOT NULL,
    Team_Leader_ID         		INT NOT NULL,
    Technologies           		VARCHAR2(100),
    Databases              		VARCHAR2(150),
    Team_Size              		INT NOT NULL,
    Status                 		VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date     		DATE,
    Project_End_Date          	DATE,

    CONSTRAINT PK_Backend PRIMARY KEY (Backend_ID),
    CONSTRAINT FK_BE_Development FOREIGN KEY (Development_ID) REFERENCES Software_Development(Development_ID),
    CONSTRAINT FK_BE_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_BE_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

-- Full-Stack Team Table
CREATE TABLE Full_Stack (
    Full_Stack_ID          		INT NOT NULL,
    Development_ID         		INT NOT NULL,
    Team_Leader_ID         		INT NOT NULL,
    Frontend_Technologies  		VARCHAR2(200),
    Backend_Technologies   		VARCHAR2(200),
    Databases              		VARCHAR2(150),
    Full_Stack_Tools       		VARCHAR2(150),
    Team_Size              		INT NOT NULL,
    Status                 		VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date     		DATE,
    Project_End_Date          	DATE,

    CONSTRAINT PK_Full_Stack PRIMARY KEY (Full_Stack_ID),
    CONSTRAINT FK_FS_Development FOREIGN KEY (Development_ID) REFERENCES Software_Development(Development_ID),
    CONSTRAINT FK_FS_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_FS_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

-- Mobile Team Table
CREATE TABLE Mobile (
    Mobile_ID           		INT NOT NULL,
    Development_ID      		INT NOT NULL,
    Team_Leader_ID      		INT NOT NULL,
    Platforms           		VARCHAR2(100),
    Languages           		VARCHAR2(100),
    Frameworks          		VARCHAR2(100),
    Mobile_Tools        		VARCHAR2(150),
    Team_Size           		INT NOT NULL,
    Status              		VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date  		DATE,
    Project_End_Date          	DATE,

    CONSTRAINT PK_Mobile PRIMARY KEY (Mobile_ID),
    CONSTRAINT FK_MB_Development FOREIGN KEY (Development_ID) REFERENCES Software_Development(Development_ID),
    CONSTRAINT FK_MB_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_MB_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

-- DevOps Engineering Team Table
CREATE TABLE DevOps (
    DevOps_ID                  			INT NOT NULL,
    Development_ID             			INT NOT NULL,
    Team_Leader_ID             			INT NOT NULL,
    CI_CD_Tools                			VARCHAR2(150),
    Infrastructure_Technologies 		VARCHAR2(200),
    Monitoring_Technologies    			VARCHAR2(200),
    Configuration_Management   			VARCHAR2(200),
    Team_Size                  			INT NOT NULL,
    Status                     			VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date         			DATE,
    Project_End_Date          			DATE,

    CONSTRAINT PK_DevOps PRIMARY KEY (DevOps_ID),
    CONSTRAINT FK_DO_Development FOREIGN KEY (Development_ID) REFERENCES Software_Development(Development_ID),
    CONSTRAINT FK_DO_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_DO_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

-- Software Architecture Team Table
CREATE TABLE Architecture (
    Architecture_ID           		INT NOT NULL,
    Development_ID            		INT NOT NULL,
    Team_Leader_ID            		INT NOT NULL,
    Architecture_Type         		VARCHAR2(100),
    Design_Patterns           		VARCHAR2(200),
    Technical_Decisions       		VARCHAR2(200),
    Documentation_Links       		VARCHAR2(200),
    Review_Cycle              		VARCHAR2(50),
    Team_Size                 		INT NOT NULL,
    Status                    		VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date        		DATE,
    Project_End_Date          		DATE,

    CONSTRAINT PK_Architecture PRIMARY KEY (Architecture_ID),
    CONSTRAINT FK_AR_Development FOREIGN KEY (Development_ID) REFERENCES Software_Development(Development_ID),
    CONSTRAINT FK_AR_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_AR_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

-- Database Development / DBA Team Table
CREATE TABLE Database_Development (
    DB_Dev_ID              		INT NOT NULL,
    Development_ID         		INT NOT NULL,
    Team_Leader_ID         		INT NOT NULL,
    DB_Type                		VARCHAR2(100),
    Responsibilities       		VARCHAR2(200),
    Tools                  		VARCHAR2(150),
    Procedure_Count        		INT NOT NULL,
    Team_Size              		INT NOT NULL,
    Status                 		VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date     		DATE,
    Project_End_Date          	DATE,

    CONSTRAINT PK_DB_Dev PRIMARY KEY (DB_Dev_ID),
    CONSTRAINT FK_DB_Development FOREIGN KEY (Development_ID) REFERENCES Software_Development(Development_ID),
    CONSTRAINT FK_DB_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_DB_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

-- API Development / Integration Team Table
CREATE TABLE API_Integration (
    API_Int_ID             		INT NOT NULL,
    Development_ID         		INT NOT NULL,
    Team_Leader_ID         		INT NOT NULL,
    API_Type               		VARCHAR2(100),
    External_Services      		VARCHAR2(200),
    Authentication_Method  		VARCHAR2(100),
    Documentation_Links    		VARCHAR2(200),
    Endpoint_Count         		INT NOT NULL,
    Team_Size              		INT NOT NULL,
    Status                 		VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date     		DATE,
    Project_End_Date          	DATE,

    CONSTRAINT PK_API_Int PRIMARY KEY (API_Int_ID),
    CONSTRAINT FK_API_Development FOREIGN KEY (Development_ID) REFERENCES Software_Development(Development_ID),
    CONSTRAINT FK_API_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_API_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

-- Game Development Team Table
CREATE TABLE Game_Development (
    Game_Dev_ID            		INT NOT NULL,
    Development_ID         		INT NOT NULL,
    Team_Leader_ID         		INT NOT NULL,
    Engine                 		VARCHAR2(100),
    Game_Type              		VARCHAR2(100),
    Platforms              		VARCHAR2(200),
    Graphics               		VARCHAR2(100),
    Scripting_Languages    		VARCHAR2(200),
    Released_Games         		INT NOT NULL,
    Team_Size              		INT NOT NULL,
    Status                 		VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date     		DATE,
    Project_End_Date          	DATE,

    CONSTRAINT PK_Game_Dev PRIMARY KEY (Game_Dev_ID),
    CONSTRAINT FK_GD_Development FOREIGN KEY (Development_ID) REFERENCES Software_Development(Development_ID),
    CONSTRAINT FK_GD_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_GD_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

-- Embedded / IoT Development Team Table
CREATE TABLE Embedded_Development (
    Embedded_ID            		INT NOT NULL,
    Development_ID         		INT NOT NULL,
    Team_Leader_ID         		INT NOT NULL,
    Devices                		VARCHAR2(200),
    Firmware_Languages     		VARCHAR2(200),
    Protocols              		VARCHAR2(200),
    Toolchains             		VARCHAR2(200),
    Cloud_Integration      		VARCHAR2(200),
    Completed_Projects     		INT NOT NULL,
    Team_Size              		INT NOT NULL,
    Status                 		VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date     		DATE,
    Project_End_Date          	DATE,

    CONSTRAINT PK_Embedded PRIMARY KEY (Embedded_ID),
    CONSTRAINT FK_EM_Development FOREIGN KEY (Development_ID) REFERENCES Software_Development(Development_ID),
    CONSTRAINT FK_EM_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_EM_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

-- AI / Machine Learning Engineering Team Table
CREATE TABLE AI_ML_Engineering (
    AI_ML_ID              		INT NOT NULL,
    Development_ID        		INT NOT NULL,
    Team_Leader_ID        		INT NOT NULL,
    Model_Types           		VARCHAR2(100),
    Frameworks            		VARCHAR2(100),
    Data_Source           		VARCHAR2(100),
    Pipeline_Technologies 		VARCHAR2(100),
    Delivery_Methods      		VARCHAR2(200),
    Completed_Projects    		INT NOT NULL,
    Team_Size             		INT NOT NULL,
    Status                		VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date    		DATE,
    Project_End_Date          	DATE,

    CONSTRAINT PK_AI_ML PRIMARY KEY (AI_ML_ID),
    CONSTRAINT FK_AI_Development FOREIGN KEY (Development_ID) REFERENCES Software_Development(Development_ID),
    CONSTRAINT FK_AI_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_AI_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);