CREATE OR REPLACE VIEW UI_UX_Calendar AS
SELECT 
    UI_UX_Design_ID AS Entry_ID,
    'General UI/UX Design' AS Team_Type,
    Description AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM UI_UX_Design

UNION ALL

SELECT 
    UX_Research_ID,
    'UX Research',
    'Methods: ' || Research_Methods || ', Users: ' || Users_Count AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM UX_Research

UNION ALL

SELECT 
    UI_Research_ID,
    'UI Research',
    'Visual Test: ' || Visual_Test_Methods || ', Users: ' || Users_Count AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM UI_Research

UNION ALL

SELECT 
    Interaction_Design_ID,
    'Interaction Design',
    'Components: ' || Components_Designed || ', Patterns: ' || Interaction_Patterns AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Interaction_Design

UNION ALL

SELECT 
    Prototyping_ID,
    'Prototyping',
    'Tool: ' || Tool || ', Screens: ' || Screen_Count || ', Tested: ' || Tested_By_Users AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Prototyping

UNION ALL

SELECT 
    IA_ID,
    'Information Architecture',
    'Structure: ' || Structure_Type || ', Tool: ' || Tool AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Information_Architecture

UNION ALL

SELECT 
    Accessibility_ID,
    'Accessibility Design',
    'Compliance: ' || Compliance_Level || ', Issues Fixed: ' || Issues_Fixed AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Accessibility_Design;

CREATE OR REPLACE VIEW UI_UX_Design_Teams_View AS
SELECT
    'UX Research' AS Team_Type,
    ux.UX_Research_ID AS Team_ID,
    ux.UI_UX_Design_ID,
    ux.Team_Leader_ID,
    'Methods: ' || ux.Research_Methods || ', Users: ' || ux.Users_Count || ', Tools: ' || ux.Research_Tools AS Method_Description,
    ux.Status,
    ux.Team_Size,
    ux.Project_Start_Date,
    ux.Project_End_Date
FROM UX_Research ux

UNION ALL

SELECT
    'UI Research',
    ui.UI_Research_ID,
    ui.UI_UX_Design_ID,
    ui.Team_Leader_ID,
    'Visual Tests: ' || ui.Visual_Test_Methods || ', Tools: ' || ui.Tools || ', Users: ' || ui.Users_Count,
    ui.Status,
    ui.Team_Size,
    ui.Project_Start_Date,
    ui.Project_End_Date
FROM UI_Research ui

UNION ALL

SELECT
    'Interaction Design',
    id.Interaction_Design_ID,
    id.UI_UX_Design_ID,
    id.Team_Leader_ID,
    'Components: ' || id.Components_Designed || ', Patterns: ' || id.Interaction_Patterns || ', Flow: ' || id.User_Flow,
    id.Status,
    id.Team_Size,
    id.Project_Start_Date,
    id.Project_End_Date
FROM Interaction_Design id

UNION ALL

SELECT
    'Prototyping',
    pt.Prototyping_ID,
    pt.UI_UX_Design_ID,
    pt.Team_Leader_ID,
    'Tool: ' || pt.Tool || ', Type: ' || pt.Prototype_Type || ', Screens: ' || pt.Screen_Count || ', Tested: ' || pt.Tested_By_Users,
    pt.Status,
    pt.Team_Size,
    pt.Project_Start_Date,
    pt.Project_End_Date
FROM Prototyping pt

UNION ALL

SELECT
    'Information Architecture',
    ia.IA_ID,
    ia.UI_UX_Design_ID,
    ia.Team_Leader_ID,
    'Structure: ' || ia.Structure_Type || ', Methods: ' || ia.Methods || ', Deliverables: ' || ia.Deliverables,
    ia.Status,
    ia.Team_Size,
    ia.Project_Start_Date,
    ia.Project_End_Date
FROM Information_Architecture ia

UNION ALL

SELECT
    'Accessibility Design',
    ad.Accessibility_ID,
    ad.UI_UX_Design_ID,
    ad.Team_Leader_ID,
    'Compliance: ' || ad.Compliance_Level || ', Issues: ' || ad.Issues_Found || '/' || ad.Issues_Fixed || ', Tools: ' || ad.Tools,
    ad.Status,
    ad.Team_Size,
    ad.Project_Start_Date,
    ad.Project_End_Date
FROM Accessibility_Design ad;
