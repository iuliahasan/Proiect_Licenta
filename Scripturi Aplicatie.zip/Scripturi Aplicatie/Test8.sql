CREATE OR REPLACE VIEW Product_Calendar AS
SELECT 
    Product_ID AS Entry_ID,
    'General Product' AS Team_Type,
    'Area: ' || Area AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Product_Management

UNION ALL

SELECT 
    PSP_ID,
    'Product Strategy & Planning',
    'Strategy: ' || Strategy || ', Goals: ' || Roadmap_Goals AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Product_Strategy_Planning

UNION ALL

SELECT 
    PO_ID,
    'Product Ownership',
    'Product: ' || Product_Name || ', Sprint: ' || Sprint_Goals AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Product_Ownership

UNION ALL

SELECT 
    TPM_ID,
    'Technical Product Management',
    'Product: ' || Product_Name || ', Tech: ' || Technology_Used AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Technical_Product_Management

UNION ALL

SELECT 
    GPM_ID,
    'Growth Product Management',
    'Product: ' || Product_Name || ', KPI: ' || KPI AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Growth_Product_Management

UNION ALL

SELECT 
    PPM_ID,
    'Platform Product Management',
    'Platform: ' || Platform_Name || ', Tools: ' || Internal_Tools AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Platform_Product_Management

UNION ALL

SELECT 
    CEF_ID,
    'Customer Experience & Feedback',
    'Feedback: ' || Feedback_Type || ', Rating: ' || Customer_Rating AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM CEF;

CREATE OR REPLACE VIEW Product_Management_Teams_View AS
SELECT
    'Strategy & Planning' AS Team_Type,
    psp.PSP_ID AS Team_ID,
    psp.Product_ID,
    psp.Team_Leader_ID,
    'Strategy: ' || psp.Strategy || ', Roadmap: ' || psp.Roadmap_Goals || ', Market: ' || psp.Market_Analysis AS Description,
    psp.Status,
    psp.Team_Size,
    psp.Project_Start_Date,
    psp.Project_End_Date
FROM Product_Strategy_Planning psp

UNION ALL

SELECT
    'Product Ownership',
    po.PO_ID,
    po.Product_ID,
    po.Team_Leader_ID,
    'Product: ' || po.Product_Name || ', Backlog: ' || po.Backlog_Items || ', Priorities: ' || po.Priorities || ', Sprint Goals: ' || po.Sprint_Goals,
    po.Status,
    po.Team_Size,
    po.Project_Start_Date,
    po.Project_End_Date
FROM Product_Ownership po

UNION ALL

SELECT
    'Technical Product Management',
    tpm.TPM_ID,
    tpm.Product_ID,
    tpm.Team_Leader_ID,
    'Product: ' || tpm.Product_Name || ', Requirements: ' || tpm.Requirements || ', Tech: ' || tpm.Technology_Used,
    tpm.Status,
    tpm.Team_Size,
    tpm.Project_Start_Date,
    tpm.Project_End_Date
FROM Technical_Product_Management tpm

UNION ALL

SELECT
    'Growth Product Management',
    gpm.GPM_ID,
    gpm.Product_ID,
    gpm.Team_Leader_ID,
    'Product: ' || gpm.Product_Name || ', KPI: ' || gpm.KPI || ', Strategy: ' || gpm.Strategy || ', Segmentation: ' || gpm.User_Segmentation,
    gpm.Status,
    gpm.Team_Size,
    gpm.Project_Start_Date,
    gpm.Project_End_Date
FROM Growth_Product_Management gpm

UNION ALL

SELECT
    'Platform Product Management',
    ppm.PPM_ID,
    ppm.Product_ID,
    ppm.Team_Leader_ID,
    'Platform: ' || ppm.Platform_Name || ', Tools: ' || ppm.Internal_Tools || ', APIs: ' || ppm.API_Documentation,
    ppm.Status,
    ppm.Team_Size,
    ppm.Project_Start_Date,
    ppm.Project_End_Date
FROM Platform_Product_Management ppm

UNION ALL

SELECT
    'Customer Experience & Feedback',
    cef.CEF_ID,
    cef.Product_ID,
    cef.Team_Leader_ID,
    'Feedback: ' || cef.Feedback_Type || ', Source: ' || cef.Feedback_Source || ', Rating: ' || TO_CHAR(cef.Customer_Rating),
    cef.Status,
    cef.Team_Size,
    cef.Project_Start_Date,
    cef.Project_End_Date
FROM CEF cef;

CREATE OR REPLACE VIEW Product_Management_Teams_View AS
SELECT
    'Strategy & Planning' AS Team_Type,
    psp.PSP_ID AS Team_ID,
    psp.Product_ID,
    psp.Team_Leader_ID,
    'Strategy: ' || psp.Strategy || ', Roadmap: ' || psp.Roadmap_Goals || ', Market: ' || psp.Market_Analysis AS Description,
    psp.Status,
    psp.Team_Size,
    psp.Project_Start_Date,
    psp.Project_End_Date
FROM Product_Strategy_Planning psp

UNION ALL

SELECT
    'Product Ownership',
    po.PO_ID,
    po.Product_ID,
    po.Team_Leader_ID,
    'Product: ' || po.Product_Name || ', Backlog: ' || po.Backlog_Items || ', Priorities: ' || po.Priorities || ', Sprint Goals: ' || po.Sprint_Goals,
    po.Status,
    po.Team_Size,
    po.Project_Start_Date,
    po.Project_End_Date
FROM Product_Ownership po

UNION ALL

SELECT
    'Technical Product Management',
    tpm.TPM_ID,
    tpm.Product_ID,
    tpm.Team_Leader_ID,
    'Product: ' || tpm.Product_Name || ', Requirements: ' || tpm.Requirements || ', Tech: ' || tpm.Technology_Used,
    tpm.Status,
    tpm.Team_Size,
    tpm.Project_Start_Date,
    tpm.Project_End_Date
FROM Technical_Product_Management tpm

UNION ALL

SELECT
    'Growth Product Management',
    gpm.GPM_ID,
    gpm.Product_ID,
    gpm.Team_Leader_ID,
    'Product: ' || gpm.Product_Name || ', KPI: ' || gpm.KPI || ', Strategy: ' || gpm.Strategy || ', Segmentation: ' || gpm.User_Segmentation,
    gpm.Status,
    gpm.Team_Size,
    gpm.Project_Start_Date,
    gpm.Project_End_Date
FROM Growth_Product_Management gpm

UNION ALL

SELECT
    'Platform Product Management',
    ppm.PPM_ID,
    ppm.Product_ID,
    ppm.Team_Leader_ID,
    'Platform: ' || ppm.Platform_Name || ', Tools: ' || ppm.Internal_Tools || ', APIs: ' || ppm.API_Documentation,
    ppm.Status,
    ppm.Team_Size,
    ppm.Project_Start_Date,
    ppm.Project_End_Date
FROM Platform_Product_Management ppm

UNION ALL

SELECT
    'Customer Experience & Feedback',
    cef.CEF_ID,
    cef.Product_ID,
    cef.Team_Leader_ID,
    'Feedback: ' || cef.Feedback_Type || ', Source: ' || cef.Feedback_Source || ', Rating: ' || TO_CHAR(cef.Customer_Rating),
    cef.Status,
    cef.Team_Size,
    cef.Project_Start_Date,
    cef.Project_End_Date
FROM CEF cef;
