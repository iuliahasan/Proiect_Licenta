--Oracle APEX 23.2.4 SQL
--Schema: Aplicatie management firma IT
--ANDREEA.HASAN@STUDENT.UPT.RO

--			Sales & Presales IT

--Presales Engineering
--Technical Account Management (TAM)
--Solution Architecture
--Bid Management / Proposal Management
--Sales Enablement & Training
--Key Account Management (KAM)
--Inside Sales
--Field Sales / Direct Sales
--Channel / Partner Sales
--Sales Operations & CRM Management
--Customer Success Management (CSM)

--Main table for the Sales & Presales IT Department
CREATE TABLE Sales_Presales_IT (
    SP_IT_ID                INT NOT NULL,
    Team_Leader_ID          INT NOT NULL,
    Region                  VARCHAR2(100),
    Status                  VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date      DATE,
    Project_End_Date        DATE,

    CONSTRAINT PK_SP_IT PRIMARY KEY (SP_IT_ID),
    CONSTRAINT FK_SP_IT_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_SP_IT_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Presales Engineering Team Table
CREATE TABLE Presales_Engineering (
    PE_ID                     	INT NOT NULL,
    SP_IT_ID                  	INT NOT NULL,
    Team_Leader_ID            	INT NOT NULL,
    Engineer_Name             	VARCHAR2(100),
    Domain_Expertise          	VARCHAR2(100),
    Certifications            	VARCHAR2(150),
    Demo_Environment_Used     	VARCHAR2(100),
    POC_Involvement_Level     	VARCHAR2(50),
    Team_Size                 	INT NOT NULL,
    Status                    	VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date        	DATE,
    Project_End_Date          	DATE,

    CONSTRAINT PK_PE PRIMARY KEY (PE_ID),
    CONSTRAINT FK_PE_SP_IT FOREIGN KEY (SP_IT_ID) REFERENCES Sales_Presales_IT(SP_IT_ID),
    CONSTRAINT FK_PE_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_PE_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Technical Account Management Team Table
CREATE TABLE Technical_Account_Management (
    TAM_ID                 	    INT NOT NULL,
    SP_IT_ID               	    INT NOT NULL,
    Team_Leader_ID         	    INT NOT NULL,
    Account_Manager_Name   	    VARCHAR2(100),
    Client_Name            	    VARCHAR2(100),
    Engagement_Level       	    VARCHAR2(50),
    Contract_Term          	    VARCHAR2(50),
    Support_Coverage       	    VARCHAR2(100),
    Team_Size              	    INT NOT NULL,
    Status                 	    VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date     	    DATE,
    Project_End_Date          	DATE,

    CONSTRAINT PK_TAM PRIMARY KEY (TAM_ID),
    CONSTRAINT FK_TAM_SP_IT FOREIGN KEY (SP_IT_ID) REFERENCES Sales_Presales_IT(SP_IT_ID),
    CONSTRAINT FK_TAM_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_TAM_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Solution Architecture Team Table
CREATE TABLE Solution_Architecture_New (
    SA_ID                   INT NOT NULL,
    SP_IT_ID                INT NOT NULL,
    Team_Leader_ID          INT NOT NULL,
    Architect_Name          VARCHAR2(100),
    Solution_Type           VARCHAR2(100),
    Technologies_Used       VARCHAR2(100),
    Client_Requirements     VARCHAR2(150),
    Design_Documentation    VARCHAR2(150),
    POC_Involvement         VARCHAR2(50),
    Team_Size               INT NOT NULL,
    Status                  VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date      DATE,
    Project_End_Date        DATE,

    CONSTRAINT PK_Solution_Architecture_New PRIMARY KEY (SA_ID),
    CONSTRAINT FK_SAN_SP_IT FOREIGN KEY (SP_IT_ID) REFERENCES Sales_Presales_IT(SP_IT_ID),
    CONSTRAINT FK_SAN_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_SAN_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Bid Management / Proposal Management Team Table
CREATE TABLE Bid_Proposal_Management (
    BM_PM_ID             	    INT NOT NULL,
    SP_IT_ID             	    INT NOT NULL,
    Team_Leader_ID       	    INT NOT NULL,
    Bid_Name             	    VARCHAR2(100),
    Client_Name          	    VARCHAR2(100),
    Deadline             	    DATE,
    Document_Link        	    VARCHAR2(150),
    Bid_Status           	    VARCHAR2(50),
    Estimated_Value      	    INT NOT NULL,
    Team_Involved        	    VARCHAR2(100),
    Team_Size            	    INT NOT NULL,
    Status               	    VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date   	    DATE,
    Project_End_Date          	DATE,

    CONSTRAINT PK_BM_PM PRIMARY KEY (BM_PM_ID),
    CONSTRAINT FK_BPM_SP_IT FOREIGN KEY (SP_IT_ID) REFERENCES Sales_Presales_IT(SP_IT_ID),
    CONSTRAINT FK_BPM_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_BPM_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Sales Enablement & Training Team Table
CREATE TABLE Sales_Training (
    SETrain_ID           	    INT NOT NULL,
    SP_IT_ID             	    INT NOT NULL,
    Team_Leader_ID       	    INT NOT NULL,
    Training_Name        	    VARCHAR2(100),
    Target_Audience      	    VARCHAR2(100),
    Training_Date        	    DATE,
    Duration_Hours       	    INT NOT NULL,
    Trainer_Name         	    VARCHAR2(100),
    Materials_Link       	    VARCHAR2(150),
    Team_Size            	    INT NOT NULL,
    Status               	    VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date   	    DATE,
    Project_End_Date          	DATE,

    CONSTRAINT PK_SETrain PRIMARY KEY (SETrain_ID),
    CONSTRAINT FK_SETrain_SP_IT FOREIGN KEY (SP_IT_ID) REFERENCES Sales_Presales_IT(SP_IT_ID),
    CONSTRAINT FK_SETrain_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_SETrain_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Key Account Management (KAM) Team Table
CREATE TABLE Key_Account_Management (
    KAM_ID                	    INT NOT NULL,
    SP_IT_ID              	    INT NOT NULL,
    Team_Leader_ID        	    INT NOT NULL,
    Client_Name           	    VARCHAR2(100),
    Account_Manager_ID    	    INT NOT NULL,
    Contract_Value        	    INT NOT NULL,
    Contract_Date         	    DATE,
    Partnership_Status    	    VARCHAR2(50),
    Notes                 	    VARCHAR2(100),
    Team_Size             	    INT NOT NULL,
    Status                	    VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date    	    DATE,
    Project_End_Date          	DATE,

    CONSTRAINT PK_KAM PRIMARY KEY (KAM_ID),
    CONSTRAINT FK_KAM_SP_IT FOREIGN KEY (SP_IT_ID) REFERENCES Sales_Presales_IT(SP_IT_ID),
    CONSTRAINT FK_KAM_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT FK_KAM_Account_Manager FOREIGN KEY (Account_Manager_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_KAM_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Inside Sales Team Table
CREATE TABLE Inside_Sales (
    Inside_Sales_ID        	    INT NOT NULL,
    SP_IT_ID               	    INT NOT NULL,
    Team_Leader_ID         	    INT NOT NULL,
    Region                 	    VARCHAR2(100),
    Sales_Target_QTR       	    NUMBER,
    Current_Performance    	    INT NOT NULL,
    Contacts_Handled       	    INT NOT NULL,
    Partnership_Status     	    VARCHAR2(50),
    Team_Size              	    INT NOT NULL,
    Status                 	    VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date     	    DATE,
    Project_End_Date          	DATE,

    CONSTRAINT PK_Inside_Sales PRIMARY KEY (Inside_Sales_ID),
    CONSTRAINT FK_Inside_Sales_SP_IT FOREIGN KEY (SP_IT_ID) REFERENCES Sales_Presales_IT(SP_IT_ID),
    CONSTRAINT FK_Inside_Sales_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Inside_Sales_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Field Sales / Direct Sales Team Table
CREATE TABLE Field_Sales_Direct_Sales (
    Field_Sales_ID        	    INT NOT NULL,
    SP_IT_ID              	    INT NOT NULL,
    Team_Leader_ID        	    INT NOT NULL,
    Territory             	    VARCHAR2(100),
    Sales_Target_QTR      	    NUMBER,
    Meetings_Held         	    INT NOT NULL,
    Deals_Closed          	    INT NOT NULL,
    Partnership_Status    	    VARCHAR2(50),
    Team_Size             	    INT NOT NULL,
    Status                	    VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date    	    DATE,
    Project_End_Date          	DATE,

    CONSTRAINT PK_Field_Sales PRIMARY KEY (Field_Sales_ID),
    CONSTRAINT FK_Field_Sales_SP_IT FOREIGN KEY (SP_IT_ID) REFERENCES Sales_Presales_IT(SP_IT_ID),
    CONSTRAINT FK_Field_Sales_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Field_Sales_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Channel / Partner Sales Team Table
CREATE TABLE Channel_Partner_Sales (
    Channel_Partner_Sales_ID   INT NOT NULL,
    SP_IT_ID                   INT NOT NULL,
    Team_Leader_ID             INT NOT NULL,
    Partner_Name               VARCHAR2(100),
    Partner_Region             VARCHAR2(100),
    Contract_Value             INT NOT NULL,
    Deals_Closed               INT NOT NULL,
    Partnership_Status         VARCHAR2(50),
    Team_Size                  INT NOT NULL,
    Status                     VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date         DATE,
    Project_End_Date           DATE,

    CONSTRAINT PK_Channel_Partner_Sales PRIMARY KEY (Channel_Partner_Sales_ID),
    CONSTRAINT FK_Channel_Partner_SP_IT FOREIGN KEY (SP_IT_ID) REFERENCES Sales_Presales_IT(SP_IT_ID),
    CONSTRAINT FK_Channel_Partner_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Channel_Partner_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Sales Operations & CRM Management Team Table
CREATE TABLE Sales_Operations_CRM_Management (
    Sales_Operations_CRM_ID      INT NOT NULL,
    SP_IT_ID                    INT NOT NULL,
    Team_Leader_ID              INT NOT NULL,
    CRM_Platform_Used           VARCHAR2(100),
    Data_Accuracy_Rate          NUMBER,
    Lead_Assignment_Strategy    VARCHAR2(100),
    Automation_Level            VARCHAR2(50),
    Team_Size                   INT NOT NULL,
    Status                     VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date          DATE,
    Project_End_Date            DATE,

    CONSTRAINT PK_Sales_Operations_CRM PRIMARY KEY (Sales_Operations_CRM_ID),
    CONSTRAINT FK_Sales_Operations_CRM_SP_IT FOREIGN KEY (SP_IT_ID) REFERENCES Sales_Presales_IT(SP_IT_ID),
    CONSTRAINT FK_Sales_Operations_CRM_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Sales_Operations_CRM_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Customer Success Management Team Table
CREATE TABLE Customer_Success_Management (
    Customer_Success_ID      INT NOT NULL,
    SP_IT_ID                 INT NOT NULL,
    Team_Leader_ID           INT NOT NULL,
    Customer_ID              INT NOT NULL,
    Success_Metric           VARCHAR2(100),
    Churn_Rate               NUMBER,
    Success_Strategy         VARCHAR2(100),
    Team_Size                INT NOT NULL,
    Status                   VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date       DATE,
    Project_End_Date         DATE,

    CONSTRAINT PK_Customer_Success PRIMARY KEY (Customer_Success_ID),
    CONSTRAINT FK_CSM_SP_IT FOREIGN KEY (SP_IT_ID) REFERENCES Sales_Presales_IT(SP_IT_ID),
    CONSTRAINT FK_CSM_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT FK_CSM_Customer FOREIGN KEY (Customer_ID) REFERENCES Customers(Customer_ID),
    CONSTRAINT CHK_CSM_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);