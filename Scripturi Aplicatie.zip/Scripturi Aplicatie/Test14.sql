CREATE OR REPLACE VIEW SalesPresalesIT_Calendar AS
SELECT
    SP_IT_ID AS Entry_ID,
    'Sales & Presales IT' AS Team_Type,
    'Region: ' || Region AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Sales_Presales_IT

UNION ALL

SELECT
    PE_ID,
    'Presales Engineering',
    'Engineer: ' || Engineer_Name || ', Domain: ' || Domain_Expertise AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Presales_Engineering

UNION ALL

SELECT
    TAM_ID,
    'Technical Account Management',
    'Account Manager: ' || Account_Manager_Name || ', Client: ' || Client_Name AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Technical_Account_Management

UNION ALL

SELECT
    BM_PM_ID,
    'Bid & Proposal Management',
    'Bid: ' || Bid_Name || ', Client: ' || Client_Name AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Bid_Proposal_Management

UNION ALL

SELECT
    SETrain_ID,
    'Sales Enablement & Training',
    'Training: ' || Training_Name || ', Trainer: ' || Trainer_Name AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Sales_Training

UNION ALL

SELECT
    KAM_ID,
    'Key Account Management',
    'Client: ' || Client_Name || ', Contract Value: ' || Contract_Value AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Key_Account_Management

UNION ALL

SELECT
    Inside_Sales_ID,
    'Inside Sales',
    'Region: ' || Region || ', Sales Target QTR: ' || Sales_Target_QTR AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Inside_Sales;

CREATE OR REPLACE VIEW Sales_Presales_IT_Teams_View AS
SELECT
    'Presales Engineering' AS Team_Type,
    pe.PE_ID AS Team_ID,
    pe.SP_IT_ID,
    pe.Team_Leader_ID,
    'Engineer: ' || pe.Engineer_Name || ', Expertise: ' || pe.Domain_Expertise || ', Demo Used: ' || pe.Demo_Environment_Used AS Description,
    pe.Status,
    pe.Team_Size,
    pe.Project_Start_Date,
    pe.Project_End_Date
FROM Presales_Engineering pe

UNION ALL

SELECT
    'Technical Account Management',
    tam.TAM_ID,
    tam.SP_IT_ID,
    tam.Team_Leader_ID,
    'Account: ' || tam.Client_Name || ', Manager: ' || tam.Account_Manager_Name || ', Contract: ' || tam.Contract_Term,
    tam.Status,
    tam.Team_Size,
    tam.Project_Start_Date,
    tam.Project_End_Date
FROM Technical_Account_Management tam

UNION ALL

SELECT
    'Bid/Proposal Management',
    bpm.BM_PM_ID,
    bpm.SP_IT_ID,
    bpm.Team_Leader_ID,
    'Bid: ' || bpm.Bid_Name || ', Client: ' || bpm.Client_Name || ', Value: ' || bpm.Estimated_Value,
    bpm.Status,
    bpm.Team_Size,
    bpm.Project_Start_Date,
    bpm.Project_End_Date
FROM Bid_Proposal_Management bpm

UNION ALL

SELECT
    'Sales Enablement & Training',
    st.SETrain_ID,
    st.SP_IT_ID,
    st.Team_Leader_ID,
    'Training: ' || st.Training_Name || ', Target: ' || st.Target_Audience || ', Trainer: ' || st.Trainer_Name,
    st.Status,
    st.Team_Size,
    st.Project_Start_Date,
    st.Project_End_Date
FROM Sales_Training st

UNION ALL

SELECT
    'Key Account Management',
    kam.KAM_ID,
    kam.SP_IT_ID,
    kam.Team_Leader_ID,
    'Client: ' || kam.Client_Name || ', Contract: ' || kam.Contract_Value || ', Status: ' || kam.Partnership_Status,
    kam.Status,
    kam.Team_Size,
    kam.Project_Start_Date,
    kam.Project_End_Date
FROM Key_Account_Management kam

UNION ALL

SELECT
    'Inside Sales',
    ins.Inside_Sales_ID,
    ins.SP_IT_ID,
    ins.Team_Leader_ID,
    'Region: ' || ins.Region || ', Target: ' || ins.Sales_Target_QTR || ', Performance: ' || ins.Current_Performance,
    ins.Status,
    ins.Team_Size,
    ins.Project_Start_Date,
    ins.Project_End_Date
FROM Inside_Sales ins;
