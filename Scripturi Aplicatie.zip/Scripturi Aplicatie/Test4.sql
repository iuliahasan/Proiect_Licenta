CREATE OR REPLACE VIEW IT_Support_Calendar AS
SELECT 
    Helpdesk_ID AS Support_ID,
    'General IT Support' AS Support_Type,
    Description AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM IT_Support

UNION ALL

SELECT 
    L1_ID,
    'Level 1 Support',
    'L1 Tickets: ' || Daily_Tickets || ', Escalated: ' || Tickets_Escalated_L2 AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM L1_Support

UNION ALL

SELECT 
    L2_ID,
    'Level 2 Support',
    'Domains: ' || Domains || ', Incidents: ' || Incidents_Handled AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM L2_Support

UNION ALL

SELECT 
    L3_ID,
    'Level 3 Support',
    'Systems: ' || Managed_Systems || ', Escalation Rate: ' || L2_Escalation_Rate AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM L3_Support

UNION ALL

SELECT 
    Incident_ID,
    'Incident Management',
    'Incidents: ' || Incidents_Handled || ', Critical: ' || Critical_Incidents AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Incident_Management

UNION ALL

SELECT 
    Request_ID,
    'Service Requests',
    'Request Type: ' || Request_Type || ', Monthly: ' || Monthly_Requests AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Service_Request_Management

UNION ALL

SELECT 
    Asset_ID,
    'IT Asset Management',
    'Equipment: ' || Equipment_Count || ', Loss %: ' || Loss_Defect_Percentage AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM IT_Asset_Management;

CREATE OR REPLACE VIEW IT_Support_Teams_View AS
SELECT
    'L1 Support' AS Team_Type,
    l1.L1_ID AS Team_ID,
    l1.Helpdesk_ID,
    l1.Team_Leader_ID,
    'Tickets: ' || l1.Daily_Tickets || ', Tools: ' || l1.Tools AS Method_Description,
    l1.Status,
    l1.Team_Size,
    l1.Project_Start_Date,
    l1.Project_End_Date
FROM L1_Support l1

UNION ALL

SELECT
    'L2 Support',
    l2.L2_ID,
    l2.Helpdesk_ID,
    l2.Team_Leader_ID,
    'Domains: ' || l2.Domains || ', Incidents: ' || l2.Incidents_Handled,
    l2.Status,
    l2.Team_Size,
    l2.Project_Start_Date,
    l2.Project_End_Date
FROM L2_Support l2

UNION ALL

SELECT
    'L3 Support',
    l3.L3_ID,
    l3.Helpdesk_ID,
    l3.Team_Leader_ID,
    'Domains: ' || l3.Domains || ', Systems: ' || l3.Managed_Systems,
    l3.Status,
    l3.Team_Size,
    l3.Project_Start_Date,
    l3.Project_End_Date
FROM L3_Support l3

UNION ALL

SELECT
    'Incident Management',
    im.Incident_ID,
    im.Helpdesk_ID,
    im.Team_Leader_ID,
    'SLA: ' || im.SLA_Compliance || '%, Critical: ' || im.Critical_Incidents,
    im.Status,
    im.Team_Size,
    im.Project_Start_Date,
    im.Project_End_Date
FROM Incident_Management im

UNION ALL

SELECT
    'Service Request',
    sr.Request_ID,
    sr.Helpdesk_ID,
    sr.Team_Leader_ID,
    'Type: ' || sr.Request_Type || ', Monthly: ' || sr.Monthly_Requests,
    sr.Status,
    sr.Team_Size,
    sr.Project_Start_Date,
    sr.Project_End_Date
FROM Service_Request_Management sr

UNION ALL

SELECT
    'IT Asset Management',
    am.Asset_ID,
    am.Helpdesk_ID,
    am.Team_Leader_ID,
    'Inventory: ' || am.Inventory_System || ', Equipment: ' || am.Equipment_Count,
    am.Status,
    am.Team_Size,
    am.Project_Start_Date,
    am.Project_End_Date
FROM IT_Asset_Management am;
