CREATE OR REPLACE VIEW HR_Calendar AS
SELECT 
    HR_ID AS Entry_ID,
    'HR Department' AS Team_Type,
    'Focus: ' || Focus_Area || ', Location: ' || Department_Location AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM HR_Department

UNION ALL

SELECT 
    TTA_ID,
    'Tech Talent Acquisition',
    'Role: ' || Role_Type || ', Open: ' || Open_Positions || ', Filled: ' || Filled_Positions AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Tech_Talent_Acquisition

UNION ALL

SELECT 
    EB_ID,
    'Employer Branding',
    'Campaign: ' || Campaign_Name || ', Channel: ' || Channels_Used AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Employer_Branding

UNION ALL

SELECT 
    HR_Analytics_ID,
    'HR Analytics',
    'Metric: ' || Metric_Name || ', Period: ' || Measured_Period AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM HR_Analytics

UNION ALL

SELECT 
    Onboarding_ID,
    'Onboarding & Orientation',
    'Employee ID: ' || New_Employee_ID || ', Orientation Done: ' || Orientation_Completed AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Onboarding_Orientation

UNION ALL

SELECT 
    LD_ID,
    'Learning & Development',
    'Training: ' || Training_Name || ', Group: ' || Target_Group AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Learning_Development

UNION ALL

SELECT 
    PM_ID,
    'Performance Management',
    'Employee ID: ' || Employee_ID || ', Reviewer ID: ' || Reviewer_ID AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Performance_Management;

CREATE OR REPLACE VIEW HR_Department_Teams_View AS
SELECT
    'Tech Talent Acquisition' AS Team_Type,
    tta.TTA_ID AS Team_ID,
    tta.HR_ID,
    tta.Team_Leader_ID,
    'Role: ' || tta.Role_Type || ', Open: ' || tta.Open_Positions || ', Filled: ' || tta.Filled_Positions AS Description,
    tta.Status,
    tta.Team_Size,
    tta.Project_Start_Date,
    tta.Project_End_Date
FROM Tech_Talent_Acquisition tta

UNION ALL

SELECT
    'Employer Branding',
    eb.EB_ID,
    eb.HR_ID,
    eb.Team_Leader_ID,
    'Campaign: ' || eb.Campaign_Name || ', Channels: ' || eb.Channels_Used || ', Target: ' || eb.Target_Audience,
    eb.Status,
    eb.Team_Size,
    eb.Project_Start_Date,
    eb.Project_End_Date
FROM Employer_Branding eb

UNION ALL

SELECT
    'HR Analytics',
    ha.HR_Analytics_ID,
    ha.HR_ID,
    ha.Team_Leader_ID,
    'Metric: ' || ha.Metric_Name || ' = ' || ha.Metric_Value || ', Period: ' || ha.Measured_Period,
    ha.Status,
    ha.Team_Size,
    ha.Project_Start_Date,
    ha.Project_End_Date
FROM HR_Analytics ha

UNION ALL

SELECT
    'Onboarding & Orientation',
    oo.Onboarding_ID,
    oo.HR_ID,
    oo.Team_Leader_ID,
    'New Employee ID: ' || oo.New_Employee_ID || ', Orientation Completed: ' || oo.Orientation_Completed,
    oo.Status,
    oo.Team_Size,
    oo.Project_Start_Date,
    oo.Project_End_Date
FROM Onboarding_Orientation oo

UNION ALL

SELECT
    'Learning & Development',
    ld.LD_ID,
    ld.HR_ID,
    ld.Team_Leader_ID,
    'Training: ' || ld.Training_Name || ', Type: ' || ld.Training_Type || ', Trainer: ' || ld.Trainer_Name,
    ld.Status,
    ld.Team_Size,
    ld.Project_Start_Date,
    ld.Project_End_Date
FROM Learning_Development ld

UNION ALL

SELECT
    'Performance Management',
    pm.PM_ID,
    pm.HR_ID,
    pm.Team_Leader_ID,
    'Employee ID: ' || pm.Employee_ID || ', Review: ' || pm.Review_Period || ', Score: ' || pm.Score,
    pm.Status,
    pm.Team_Size,
    pm.Project_Start_Date,
    pm.Project_End_Date
FROM Performance_Management pm;
