--Oracle APEX 23.2.4 SQL
--Schema: Aplicatie management firma IT
--ANDREEA.HASAN@STUDENT.UPT.RO

--			UI/UX Design
--UX Research
--UI Design
--Interaction Design (IxD)
--Prototyping
--Information Architecture (IA)
--Accessibility Design
--Visual Design
--Design Systems & UI Kits
--UX Writing / Microcopy

--Main table for the UI/UX Design Department
CREATE TABLE UI_UX_Design (
    UI_UX_Design_ID         INT NOT NULL,
    Description             VARCHAR2(200),
    Team_Leader_ID          INT NOT NULL,
    Projects_Count          INT NOT NULL,
    Toolset                 VARCHAR2(100),
    Design_System           VARCHAR2(100),
    Team_Size               INT NOT NULL,
    Status                  VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date      DATE,
    Project_End_Date        DATE,

    CONSTRAINT PK_UI_UX_Design PRIMARY KEY (UI_UX_Design_ID),
    CONSTRAINT FK_UI_UX_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_UI_UX_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

-- UX_Research Team Table
CREATE TABLE UX_Research (
    UX_Research_ID          INT NOT NULL,
    UI_UX_Design_ID         INT NOT NULL,
    Team_Leader_ID          INT NOT NULL,
    Research_Methods        VARCHAR2(100),
    Users_Count             INT NOT NULL,
    Research_Tools          VARCHAR2(100),
    Documentation_Link      VARCHAR2(200),
    Team_Size               INT NOT NULL,
    Status                  VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date      DATE,
    Project_End_Date        DATE,

    CONSTRAINT PK_UX_Research PRIMARY KEY (UX_Research_ID),
    CONSTRAINT FK_UX_Research_UI_UX FOREIGN KEY (UI_UX_Design_ID) REFERENCES UI_UX_Design(UI_UX_Design_ID),
    CONSTRAINT FK_UX_Research_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_UX_Research_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

-- UI_Research Team Table
CREATE TABLE UI_Research (
    UI_Research_ID          INT NOT NULL,
    UI_UX_Design_ID         INT NOT NULL,
    Team_Leader_ID          INT NOT NULL,
    Design_Lead_ID          INT NOT NULL,
    Visual_Test_Methods     VARCHAR2(100),
    Users_Count             INT NOT NULL,
    Tools                   VARCHAR2(100),
    Design_Document_Link    VARCHAR2(200),
    Results_Summary         VARCHAR2(200),
    Team_Size               INT NOT NULL,
    Status                  VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date      DATE,
    Project_End_Date        DATE,

    CONSTRAINT PK_UI_Research PRIMARY KEY (UI_Research_ID),
    CONSTRAINT FK_UI_Research_UI_UX FOREIGN KEY (UI_UX_Design_ID) REFERENCES UI_UX_Design(UI_UX_Design_ID),
    CONSTRAINT FK_UI_Research_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT FK_UI_Research_Design_Lead FOREIGN KEY (Design_Lead_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_UI_Research_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

-- Interaction_Design Team Table
CREATE TABLE Interaction_Design (
    Interaction_Design_ID   INT NOT NULL,
    UI_UX_Design_ID         INT NOT NULL,
    Team_Leader_ID          INT NOT NULL,
    Design_Lead_ID          INT NOT NULL,
    Components_Designed     VARCHAR2(100),
    Tools                   VARCHAR2(100),
    Interaction_Patterns    VARCHAR2(100),
    User_Flow               VARCHAR2(100),
    Team_Size               INT NOT NULL,
    Status                  VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date      DATE,
    Project_End_Date        DATE,

    CONSTRAINT PK_Interaction_Design PRIMARY KEY (Interaction_Design_ID),
    CONSTRAINT FK_Interaction_Design_UI_UX FOREIGN KEY (UI_UX_Design_ID) REFERENCES UI_UX_Design(UI_UX_Design_ID),
    CONSTRAINT FK_Interaction_Design_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT FK_Interaction_Design_Lead FOREIGN KEY (Design_Lead_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Interaction_Design_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

-- Prototyping Team Table
CREATE TABLE Prototyping (
    Prototyping_ID          INT NOT NULL,
    UI_UX_Design_ID         INT NOT NULL,
    Team_Leader_ID          INT NOT NULL,
    Design_Lead_ID          INT NOT NULL,
    Tool                    VARCHAR2(100),
    Prototype_Type          VARCHAR2(50),
    Screen_Count            INT NOT NULL,
    Prototype_Link          VARCHAR2(200),
    Tested_By_Users         VARCHAR2(3) CHECK (Tested_By_Users IN ('Yes', 'No')),
    Team_Size               INT NOT NULL,
    Status                  VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date      DATE,
    Project_End_Date        DATE,

    CONSTRAINT PK_Prototyping PRIMARY KEY (Prototyping_ID),
    CONSTRAINT FK_Prototyping_UI_UX FOREIGN KEY (UI_UX_Design_ID) REFERENCES UI_UX_Design(UI_UX_Design_ID),
    CONSTRAINT FK_Prototyping_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT FK_Prototyping_Design_Lead FOREIGN KEY (Design_Lead_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Prototyping_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

-- Information_Architecture Team Table
CREATE TABLE Information_Architecture (
    IA_ID                   INT NOT NULL,
    UI_UX_Design_ID         INT NOT NULL,
    Team_Leader_ID          INT NOT NULL,
    Structure_Type          VARCHAR2(100),
    Methods                 VARCHAR2(200),
    Deliverables            VARCHAR2(200),
    Tool                    VARCHAR2(100),
    Team_Size               INT NOT NULL,
    Status                  VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date      DATE,
    Project_End_Date        DATE,

    CONSTRAINT PK_IA PRIMARY KEY (IA_ID),
    CONSTRAINT FK_IA_UI_UX FOREIGN KEY (UI_UX_Design_ID) REFERENCES UI_UX_Design(UI_UX_Design_ID),
    CONSTRAINT FK_IA_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_IA_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

-- Accessibility_Design Team Table
CREATE TABLE Accessibility_Design (
    Accessibility_ID        INT NOT NULL,
    UI_UX_Design_ID         INT NOT NULL,
    Team_Leader_ID          INT NOT NULL,
    Compliance_Level        VARCHAR2(50),
    Tools                   VARCHAR2(100),
    Audit_Date              DATE,
    Issues_Found            INT NOT NULL,
    Issues_Fixed            INT NOT NULL,
    Team_Size               INT NOT NULL,
    Status                  VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date      DATE,
    Project_End_Date        DATE,

    CONSTRAINT PK_Accessibility PRIMARY KEY (Accessibility_ID),
    CONSTRAINT FK_Accessibility_UI_UX FOREIGN KEY (UI_UX_Design_ID) REFERENCES UI_UX_Design(UI_UX_Design_ID),
    CONSTRAINT FK_Accessibility_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Accessibility_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

-- Visual_Design Team Table
CREATE TABLE Visual_Design (
    Visual_ID               INT NOT NULL,
    UI_UX_Design_ID         INT NOT NULL,
    Team_Leader_ID          INT NOT NULL,
    Design_Style            VARCHAR2(100),
    Color_Palette           VARCHAR2(100),
    Typography              VARCHAR2(100),
    Brand_Guidelines        VARCHAR2(200),
    Deliverables            VARCHAR2(200),
    Team_Size               INT NOT NULL,
    Status                  VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date      DATE,
    Project_End_Date        DATE,

    CONSTRAINT PK_Visual_Design PRIMARY KEY (Visual_ID),
    CONSTRAINT FK_Visual_Design_UI_UX FOREIGN KEY (UI_UX_Design_ID) REFERENCES UI_UX_Design(UI_UX_Design_ID),
    CONSTRAINT FK_Visual_Design_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Visual_Design_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

-- UI_Kits Team Table
CREATE TABLE UI_Kits (
    UI_Kits_ID              INT NOT NULL,
    UI_UX_Design_ID         INT NOT NULL,
    Team_Leader_ID          INT NOT NULL,
    System_Name             VARCHAR2(100),
    Components_Included     VARCHAR2(200),
    Tool                    VARCHAR2(100),
    System_Version          VARCHAR2(50),
    Guidelines_Link         VARCHAR2(200),
    Team_Size               INT NOT NULL,
    Status                  VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date      DATE,
    Project_End_Date        DATE,

    CONSTRAINT PK_UI_Kits PRIMARY KEY (UI_Kits_ID),
    CONSTRAINT FK_UI_Kits_UI_UX FOREIGN KEY (UI_UX_Design_ID) REFERENCES UI_UX_Design(UI_UX_Design_ID),
    CONSTRAINT FK_UI_Kits_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_UI_Kits_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

-- Microcopy Team Table
CREATE TABLE Microcopy (
    Microcopy_ID            INT NOT NULL,
    UI_UX_Design_ID         INT NOT NULL,
    Team_Leader_ID          INT NOT NULL,
    Copy_Type               VARCHAR2(50),
    Content_Copy            VARCHAR2(100),
    Language_Used           VARCHAR2(100),
    Team_Size               INT NOT NULL,
    Status                  VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date      DATE,
    Project_End_Date        DATE,

    CONSTRAINT PK_Microcopy PRIMARY KEY (Microcopy_ID),
    CONSTRAINT FK_Microcopy_UI_UX FOREIGN KEY (UI_UX_Design_ID) REFERENCES UI_UX_Design(UI_UX_Design_ID),
    CONSTRAINT FK_Microcopy_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Microcopy_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);