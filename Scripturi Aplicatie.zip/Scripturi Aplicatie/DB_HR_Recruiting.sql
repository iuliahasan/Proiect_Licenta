--Oracle APEX 23.2.4 SQL
--Schema: Aplicatie management firma IT
--ANDREEA.HASAN@STUDENT.UPT.RO

--			HR / Recrutare Tech

--Tech Talent Acquisition
--Employer Branding
--HR Analytics
--Onboarding & Orientation
--Learning & Development (L&D)
--Performance Management
--Employee Engagement
--Compensation & Benefits
--Workforce Planning
--Diversity, Equity & Inclusion (DEI)
--HR Operations & Compliance

--Main table for the HR / Tech Recruitment Department
CREATE TABLE HR_Department (
    HR_ID                  	    INT NOT NULL,
    Team_Leader_ID         	    INT NOT NULL,
    Department_Location    	    VARCHAR2(100),
    Focus_Area             	    VARCHAR2(100),
    Status                 	    VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date     	    DATE,
    Project_End_Date          	DATE,

    CONSTRAINT PK_HR_Department PRIMARY KEY (HR_ID),
    CONSTRAINT FK_Team_Leader_HR FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Status_HR CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Tech Talent Acquisition Team Table
CREATE TABLE Tech_Talent_Acquisition (
    TTA_ID                    NUMBER NOT NULL,
    HR_ID                     NUMBER NOT NULL,
    Team_Leader_ID            NUMBER NOT NULL,
    Role_Type                 VARCHAR2(100),
    Open_Positions            NUMBER NOT NULL,
    Filled_Positions          NUMBER DEFAULT 0 NOT NULL,
    Recruitment_Stage         VARCHAR2(50),
    Team_Size                 NUMBER NOT NULL,
    Status                    VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date        DATE,
    Project_End_Date          DATE,

    CONSTRAINT PK_TTA PRIMARY KEY (TTA_ID),
    CONSTRAINT FK_HR_Department_TTA FOREIGN KEY (HR_ID) REFERENCES HR_Department(HR_ID),
    CONSTRAINT FK_Team_Leader_TTA FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Status_TTA CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Employer Branding Team Table
CREATE TABLE Employer_Branding (
    EB_ID                 	    INT NOT NULL,
    HR_ID                 	    INT NOT NULL,
    Team_Leader_ID        	    INT NOT NULL,
    Campaign_Name         	    VARCHAR2(100),
    Channels_Used         	    VARCHAR2(100),
    Target_Audience       	    VARCHAR2(100),
    Campaign_Start_Date   	    DATE,
    Campaign_End_Date     	    DATE,
    Budget                	    NUMBER,
    Team_Size             	    INT NOT NULL,
    Status                	    VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date    	    DATE,
    Project_End_Date          	DATE,

    CONSTRAINT PK_Employer_Branding PRIMARY KEY (EB_ID),
    CONSTRAINT FK_HR_Department_EB FOREIGN KEY (HR_ID) REFERENCES HR_Department(HR_ID),
    CONSTRAINT FK_Team_Leader_EB FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Status_EB CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--HR Analytics Team Table
CREATE TABLE HR_Analytics (
    HR_Analytics_ID        	    INT NOT NULL,
    HR_ID                  	    INT NOT NULL,
    Team_Leader_ID         	    INT NOT NULL,
    Metric_Name            	    VARCHAR2(100),
    Metric_Value            	INT NOT NULL,
    Measured_Period        	    VARCHAR2(50),
    Last_Updated           	    DATE,
    Team_Size              	    INT NOT NULL,
    Status                 	    VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date      	DATE,
    Project_End_Date          	DATE,

    CONSTRAINT PK_HR_Analytics PRIMARY KEY (HR_Analytics_ID),
    CONSTRAINT FK_HR_Department_HA FOREIGN KEY (HR_ID) REFERENCES HR_Department(HR_ID),
    CONSTRAINT FK_Team_Leader_HA FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Status_HA CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Onboarding & Orientation Team Table
CREATE TABLE Onboarding_Orientation (
    Onboarding_ID           	INT NOT NULL,
    HR_ID                   	INT NOT NULL,
    Team_Leader_ID          	INT NOT NULL,
    New_Employee_ID         	INT NOT NULL,
    Orientation_Completed   	VARCHAR2(3) CHECK (Orientation_Completed IN ('Yes', 'No')),
    Mentor_Assigned         	VARCHAR2(100),
    Feedback_Received       	VARCHAR2(100),
    Team_Size               	INT NOT NULL,
    Status                  	VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date      	DATE,
    Project_End_Date          	DATE,

    CONSTRAINT PK_Onboarding_Orientation PRIMARY KEY (Onboarding_ID),
    CONSTRAINT FK_Onboard_HR_Department FOREIGN KEY (HR_ID) REFERENCES HR_Department(HR_ID),
    CONSTRAINT FK_Onboard_New_Employee FOREIGN KEY (New_Employee_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT FK_Onboard_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Status_Onboarding CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Learning & Development (L&D) Team Table
CREATE TABLE Learning_Development (
    LD_ID              		    INT NOT NULL,
    HR_ID              		    INT NOT NULL,
    Team_Leader_ID     		    INT NOT NULL,
    Training_Name      		    VARCHAR2(100),
    Target_Group       		    VARCHAR2(100),
    Trainer_Name       		    VARCHAR2(100),
    Training_End_Date  		    DATE,
    Training_Type      		    VARCHAR2(50),
    Participants       		    INT NOT NULL,
    Team_Size          		    INT NOT NULL,
    Status             		    VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date 		    DATE,
    Project_End_Date          	DATE,

    CONSTRAINT PK_Learning_Development PRIMARY KEY (LD_ID),
    CONSTRAINT FK_LD_HR_Department FOREIGN KEY (HR_ID) REFERENCES HR_Department(HR_ID),
    CONSTRAINT FK_LD_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Status_LD CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Performance Management Team Table
CREATE TABLE Performance_Management_New (
    PM_ID                    NUMBER NOT NULL,
    HR_ID                    NUMBER NOT NULL,
    Team_Leader_ID           NUMBER NOT NULL,
    Employee_ID              NUMBER NOT NULL,
    Review_Period            VARCHAR2(100),
    Score                    NUMBER,
    Reviewer_ID              NUMBER NOT NULL,
    Feedback_Summary         VARCHAR2(150),
    Next_Steps               VARCHAR2(100),
    Team_Size                NUMBER NOT NULL,
    Status                   VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date       DATE,
    Project_End_Date         DATE,

    CONSTRAINT PM_NEW_PK PRIMARY KEY (PM_ID),
    CONSTRAINT PM_NEW_FK_HR_ID FOREIGN KEY (HR_ID) REFERENCES HR_Department(HR_ID),
    CONSTRAINT PM_NEW_FK_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT PM_NEW_FK_Reviewer FOREIGN KEY (Reviewer_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT PM_NEW_FK_Employee FOREIGN KEY (Employee_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT PM_NEW_CHK_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Employee Engagement Team Table
CREATE TABLE Employee_Engagement (
    EE_ID                   INT NOT NULL,
    HR_ID                   INT NOT NULL,
    Team_Leader_ID          INT NOT NULL,
    Initiative_Name         VARCHAR2(100),
    Initiative_Description  VARCHAR2(150),
    Initiative_Date         DATE,
    Participants            INT NOT NULL,
    Feedback_Score          NUMBER,
    Team_Size               INT NOT NULL,
    Status                  VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date      DATE,
    Project_End_Date        DATE,

    CONSTRAINT PK_Employee_Engagement PRIMARY KEY (EE_ID),
    CONSTRAINT FK_EE_HR_Department FOREIGN KEY (HR_ID) REFERENCES HR_Department(HR_ID),
    CONSTRAINT FK_EE_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Status_EE CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Compensation & Benefits Team Table
CREATE TABLE Compensation_Benefits (
    CB_ID                   INT NOT NULL,
    HR_ID                   INT NOT NULL,
    Team_Leader_ID          INT NOT NULL,
    Employee_ID             INT NOT NULL,
    Base_Salary             INT NOT NULL,
    Bonus_Amount            INT,
    Benefit_Package         VARCHAR2(100),
    Last_Updated            DATE,
    Team_Size               INT NOT NULL,
    Status                  VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date      DATE,
    Project_End_Date        DATE,

    CONSTRAINT PK_Compensation_Benefits PRIMARY KEY (CB_ID),
    CONSTRAINT FK_CB_HR_Department FOREIGN KEY (HR_ID) REFERENCES HR_Department(HR_ID),
    CONSTRAINT FK_CB_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT FK_CB_Employee FOREIGN KEY (Employee_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Status_CB CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Workforce Planning Team Table
CREATE TABLE Workforce_Planning (
    WP_ID                   INT NOT NULL,
    HR_ID                   INT NOT NULL,
    Team_Leader_ID          INT NOT NULL,
    Department_ID           INT NOT NULL,
    Planned_Employees       INT NOT NULL,
    Current_Employees       INT NOT NULL,
    Gap_Analysis            VARCHAR2(100),
    Review_Date             DATE,
    Team_Size               INT NOT NULL,
    Status                  VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date      DATE,
    Project_End_Date        DATE,

    CONSTRAINT PK_Workforce_Planning PRIMARY KEY (WP_ID),
    CONSTRAINT FK_WP_HR_Department FOREIGN KEY (HR_ID) REFERENCES HR_Department(HR_ID),
    CONSTRAINT FK_WP_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT FK_WP_Department FOREIGN KEY (Department_ID) REFERENCES Departments(Department_ID),
    CONSTRAINT CHK_Status_WP CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Diversity, Equity & Inclusion (DEI) Team Table
CREATE TABLE DEI_Team (
    DEI_ID                INT NOT NULL,
    HR_ID                 INT NOT NULL,
    Team_Leader_ID        INT NOT NULL,
    Initiative_Name       VARCHAR2(100),
    Initiative_Type       VARCHAR2(100),
    Target_Group          VARCHAR2(100),
    Impact_Metric         VARCHAR2(100),
    Team_Size             INT NOT NULL,
    Status                VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date    DATE,
    Project_End_Date      DATE,

    CONSTRAINT PK_DEI_Team PRIMARY KEY (DEI_ID),
    CONSTRAINT FK_DEI_HR_Department FOREIGN KEY (HR_ID) REFERENCES HR_Department(HR_ID),
    CONSTRAINT FK_DEI_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_DEI_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--HR Operations & Compliance Team Table
CREATE TABLE HR_Operations_Compliance (
    HR_OC_ID               INT NOT NULL,
    HR_ID                  INT NOT NULL,
    Team_Leader_ID         INT NOT NULL,
    Operation_Type         VARCHAR2(100),
    Operation_Description  VARCHAR2(150),
    Document_Link          VARCHAR2(200),
    Effective_Date         DATE,
    Review_Date            DATE,
    Team_Size              INT NOT NULL,
    Status                 VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date     DATE,
    Project_End_Date       DATE,

    CONSTRAINT PK_HR_Operations_Compliance PRIMARY KEY (HR_OC_ID),
    CONSTRAINT FK_HROC_HR_Department FOREIGN KEY (HR_ID) REFERENCES HR_Department(HR_ID),
    CONSTRAINT FK_HROC_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_HROC_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);