CREATE OR REPLACE VIEW MarketingTechDigitalCalendar AS
SELECT
    MTDM_ID AS Entry_ID,
    'Marketing & Tech - Digital Marketing' AS Team_Type,
    'Team Leader ID: ' || Team_Leader_ID AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Marketing_Tech_Digital_Marketing

UNION ALL

SELECT
    DA_ID,
    'Digital Advertising',
    'Platform: ' || Platform || ', Ad Type: ' || Ad_Type || ', Budget: ' || Budget_Allocated AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Digital_Advertising

UNION ALL

SELECT
    SEO_ID,
    'SEO / Content Marketing',
    'Keywords: ' || Target_Keywords || ', Domain Authority: ' || Domain_Authority AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM SEO

UNION ALL

SELECT
    Social_Media_Marketing_ID,
    'Social Media Marketing',
    'Platform: ' || Platform || ', Campaign: ' || Campaign_Name AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Social_Media_Marketing

UNION ALL

SELECT
    Email_Marketing_ID,
    'Email Marketing',
    'Campaign: ' || Campaign_Name || ', Subject: ' || Email_Subject AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Email_Marketing

UNION ALL

SELECT
    AM_ID,
    'Affiliate Marketing',
    'Affiliate: ' || Affiliate_Name || ', Platform: ' || Platform_Used AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Affiliate_Marketing

UNION ALL

SELECT
    MA_ID,
    'Marketing Automation',
    'Platform: ' || Platform_Used || ', Automated Campaigns: ' || Automated_Campaigns AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Marketing_Automation;

CREATE OR REPLACE VIEW Marketing_Tech_Teams_View AS
SELECT
    'Digital Advertising' AS Team_Type,
    da.DA_ID AS Team_ID,
    da.MTDM_ID,
    da.Team_Leader_ID,
    'Platform: ' || da.Platform || ', Ad Type: ' || da.Ad_Type || ', Budget: ' || da.Budget_Allocated AS Description,
    da.Status,
    da.Team_Size,
    da.Project_Start_Date,
    da.Project_End_Date
FROM Digital_Advertising da

UNION ALL

SELECT
    'SEO',
    seo.SEO_ID,
    seo.MTDM_ID,
    seo.Team_Leader_ID,
    'Keywords: ' || seo.Target_Keywords || ', Traffic: ' || seo.Organic_Traffic || ', Backlinks: ' || seo.Backlinks,
    seo.Status,
    seo.Team_Size,
    seo.Project_Start_Date,
    seo.Project_End_Date
FROM SEO seo

UNION ALL

SELECT
    'Social Media Marketing',
    smm.Social_Media_Marketing_ID,
    smm.MTDM_ID,
    smm.Team_Leader_ID,
    'Platform: ' || smm.Platform || ', Campaign: ' || smm.Campaign_Name || ', Engagement: ' || smm.Engagement_Rate,
    smm.Status,
    smm.Team_Size,
    smm.Project_Start_Date,
    smm.Project_End_Date
FROM Social_Media_Marketing smm

UNION ALL

SELECT
    'Email Marketing',
    em.Email_Marketing_ID,
    em.MTDM_ID,
    em.Team_Leader_ID,
    'Campaign: ' || em.Campaign_Name || ', Subject: ' || em.Email_Subject || ', Recipients: ' || em.Number_of_Recipients,
    em.Status,
    em.Team_Size,
    em.Project_Start_Date,
    em.Project_End_Date
FROM Email_Marketing em

UNION ALL

SELECT
    'Affiliate Marketing',
    am.AM_ID,
    am.MTDM_ID,
    am.Team_Leader_ID,
    'Affiliate: ' || am.Affiliate_Name || ', Platform: ' || am.Platform_Used || ', Conversions: ' || am.Total_Conversions,
    am.Status,
    am.Team_Size,
    am.Project_Start_Date,
    am.Project_End_Date
FROM Affiliate_Marketing am

UNION ALL

SELECT
    'Marketing Automation',
    ma.MA_ID,
    ma.MTDM_ID,
    ma.Team_Leader_ID,
    'Platform: ' || ma.Platform_Used || ', Campaigns: ' || ma.Automated_Campaigns || ', Leads: ' || ma.Leads_Generated,
    ma.Status,
    ma.Team_Size,
    ma.Project_Start_Date,
    ma.Project_End_Date
FROM Marketing_Automation ma;
