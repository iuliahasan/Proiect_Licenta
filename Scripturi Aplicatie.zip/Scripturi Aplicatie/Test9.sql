CREATE OR REPLACE VIEW Data_BI_Calendar AS
SELECT 
    DAB_ID AS Entry_ID,
    'General Data & BI' AS Team_Type,
    'Project: ' || Description AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Data_BI_Analytics

UNION ALL

SELECT 
    DE_ID,
    'Data Engineering',
    'Pipelines: ' || Pipeline_Technologies || ', Realtime: ' || Realtime_Capable AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Data_Engineering

UNION ALL

SELECT 
    BI_ID,
    'BI Development',
    'Tools: ' || BI_Tools || ', Dashboards: ' || Dashboards AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM BI_Development

UNION ALL

SELECT 
    DA_ID,
    'Data Analysis',
    'Analysis: ' || Analysis_Type || ', Insights: ' || Insight_Reports AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Data_Analysis

UNION ALL

SELECT 
    DS_ID,
    'Data Science',
    'ML: ' || ML_Frameworks || ', Models: ' || Models_In_Production AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Data_Science

UNION ALL

SELECT 
    MLOps_ID,
    'MLOps',
    'Deployment: ' || Deployment_Tools || ', CI/CD Pipelines: ' || CI_CD_Pipelines AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM MLOps

UNION ALL

SELECT 
    DGDQ_ID,
    'Data Governance & Quality',
    'Policies: ' || Data_Policies_Defined || ', Audit: ' || Audit_Frequency AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM DGDQ;

CREATE OR REPLACE VIEW Data_BI_Analytics_Teams_View AS
SELECT
    'Data Engineering' AS Team_Type,
    de.DE_ID AS Team_ID,
    de.DAB_ID,
    de.Team_Leader_ID,
    'Pipeline: ' || de.Pipeline_Technologies || ', Warehouse: ' || de.Warehouse_Platform || ', Formats: ' || de.Data_Formats || ', Realtime: ' || de.Realtime_Capable AS Description,
    de.Status,
    de.Team_Size,
    de.Project_Start_Date,
    de.Project_End_Date
FROM Data_Engineering de

UNION ALL

SELECT
    'BI Development',
    bi.BI_ID,
    bi.DAB_ID,
    bi.Team_Leader_ID,
    'Tools: ' || bi.BI_Tools || ', Dashboards: ' || bi.Dashboards || ', Reporting: ' || bi.Reporting_Frequency || ', Sources: ' || bi.Data_Sources_Integrated,
    bi.Status,
    bi.Team_Size,
    bi.Project_Start_Date,
    bi.Project_End_Date
FROM BI_Development bi

UNION ALL

SELECT
    'Data Analysis',
    da.DA_ID,
    da.DAB_ID,
    da.Team_Leader_ID,
    'Tools: ' || da.Analysis_Tools || ', Type: ' || da.Analysis_Type || ', Business Areas: ' || da.Business_Areas_Covered || ', Reports: ' || da.Insight_Reports,
    da.Status,
    da.Team_Size,
    da.Project_Start_Date,
    da.Project_End_Date
FROM Data_Analysis da

UNION ALL

SELECT
    'Data Science',
    ds.DS_ID,
    ds.DAB_ID,
    ds.Team_Leader_ID,
    'Frameworks: ' || ds.ML_Frameworks || ', Models: ' || ds.Models_In_Production || ', Types: ' || ds.Model_Types,
    ds.Status,
    ds.Team_Size,
    ds.Project_Start_Date,
    ds.Project_End_Date
FROM Data_Science ds

UNION ALL

SELECT
    'MLOps',
    ml.MLOps_ID,
    ml.DAB_ID,
    ml.Team_Leader_ID,
    'Deployment: ' || ml.Deployment_Tools || ', Monitoring: ' || ml.Monitoring_Enabled || ', Models: ' || ml.Models_Deployed || ', CI/CD: ' || ml.CI_CD_Pipelines,
    ml.Status,
    ml.Team_Size,
    ml.Project_Start_Date,
    ml.Project_End_Date
FROM MLOps ml

UNION ALL

SELECT
    'Data Governance & Quality',
    dg.DGDQ_ID,
    dg.DAB_ID,
    dg.Team_Leader_ID,
    'Policies: ' || dg.Data_Policies_Defined || ', Framework: ' || dg.Data_Quality_Framework || ', Compliance: ' || dg.Compliance_Regulations || ', Audit: ' || dg.Audit_Frequency,
    dg.Status,
    dg.Team_Size,
    dg.Project_Start_Date,
    dg.Project_End_Date
FROM DGDQ dg;
