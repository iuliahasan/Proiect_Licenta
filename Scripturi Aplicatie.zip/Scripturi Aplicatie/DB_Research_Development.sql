--Oracle APEX 23.2.4 SQL
--Schema: Aplicatie management firma IT
--ANDREEA.HASAN@STUDENT.UPT.RO

--			Research & Development (R&D)

--Scientific Research
--Technological Innovation
--Software Development
--Hardware Development
--Market Research
--Experimental Projects
--Testing and Validation

--Main table for the Research & Development (R&D) Department
CREATE TABLE Research_Development (
    RD_ID                 	INT NOT NULL,
    Description             VARCHAR2(200),
    Team_Leader_ID        	INT NOT NULL,
    Domain                	VARCHAR2(100),
    Goal                  	VARCHAR2(100),
    Team_Size             	INT NOT NULL,
    Status                	VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date    	DATE,
    Project_End_Date        DATE,

    CONSTRAINT PK_Research_Development PRIMARY KEY (RD_ID),
    CONSTRAINT FK_RD_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_RD_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Scientific Research Team Table
CREATE TABLE Scientific_Research (
    Scientific_ID           		INT NOT NULL,
    RD_ID                   		INT NOT NULL,
    Team_Leader_ID          		INT NOT NULL,
    Domain                  		VARCHAR2(100),
    Academic_Collaborations 		VARCHAR2(200),
    Team_Size               		INT NOT NULL,
    Status                  		VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date      		DATE,
    Project_End_Date          		DATE,

    CONSTRAINT PK_Scientific_Research PRIMARY KEY (Scientific_ID),
    CONSTRAINT FK_Sci_RD FOREIGN KEY (RD_ID) REFERENCES Research_Development(RD_ID),
    CONSTRAINT FK_Sci_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Sci_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Technological Innovation Team Table
CREATE TABLE Technological_Innovation (
    Technological_ID     	INT NOT NULL,
    RD_ID                	INT NOT NULL,
    Team_Leader_ID       	INT NOT NULL,
    Innovation_Area      	VARCHAR2(100),
    Patent_Pending       	VARCHAR2(3) CHECK (Patent_Pending IN ('Yes', 'No')),
    Partner_Companies    	VARCHAR2(200),
    Team_Size            	INT NOT NULL,
    Status               	VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date   	DATE,
    Project_End_Date        DATE,

    CONSTRAINT PK_Tech_Innovation PRIMARY KEY (Technological_ID),
    CONSTRAINT FK_Tech_RD FOREIGN KEY (RD_ID) REFERENCES Research_Development(RD_ID),
    CONSTRAINT FK_Tech_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Tech_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Software Development Team Table
CREATE TABLE Software_Development_New (
    Software_ID          	INT NOT NULL,
    RD_ID                	INT NOT NULL,
    Team_Leader_ID       	INT NOT NULL,
    Technology_Explored  	VARCHAR2(100),
    Prototype_Name       	VARCHAR2(100),
    Development_Stage    	VARCHAR2(100),
    Team_Size            	INT NOT NULL,
    Status               	VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date   	DATE,
    Project_End_Date     	DATE,

    CONSTRAINT PK_Software_Development_New PRIMARY KEY (Software_ID),
    CONSTRAINT FK_Soft_RD FOREIGN KEY (RD_ID) REFERENCES Research_Development(RD_ID),
    CONSTRAINT FK_Soft_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Soft_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Hardware Development Team Table
CREATE TABLE Hardware_Development (
    Hardware_ID         	INT NOT NULL,
    RD_ID               	INT NOT NULL,
    Team_Leader_ID      	INT NOT NULL,
    Prototype_Name      	VARCHAR2(100),
    Hardware_Type       	VARCHAR2(100),
    Is_3D_Printed       	VARCHAR2(3) CHECK (Is_3D_Printed IN ('Yes', 'No')),
    Team_Size           	INT NOT NULL,
    Status              	VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date  	DATE,
    Project_End_Date        DATE,

    CONSTRAINT PK_Hardware_Development PRIMARY KEY (Hardware_ID),
    CONSTRAINT FK_Hard_RD FOREIGN KEY (RD_ID) REFERENCES Research_Development(RD_ID),
    CONSTRAINT FK_Hard_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Hard_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Market Research Team Table
CREATE TABLE Market_Research (
    Market_ID             	INT NOT NULL,
    RD_ID                 	INT NOT NULL,
    Team_Leader_ID        	INT NOT NULL,
    Target_Market         	VARCHAR2(100),
    Research_Methods      	VARCHAR2(100),
    Competition_Analysis  	VARCHAR2(3) CHECK (Competition_Analysis IN ('Yes', 'No')),
    Team_Size             	INT NOT NULL,
    Status                	VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date    	DATE,
    Project_End_Date        DATE,

    CONSTRAINT PK_Market_Research PRIMARY KEY (Market_ID),
    CONSTRAINT FK_Market_RD FOREIGN KEY (RD_ID) REFERENCES Research_Development(RD_ID),
    CONSTRAINT FK_Market_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Market_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Experimental Projects Team Table
CREATE TABLE Experimental_Projects (
    Experimental_ID     	INT NOT NULL,
    RD_ID               	INT NOT NULL,
    Team_Leader_ID      	INT NOT NULL,
    Project_Name        	VARCHAR2(100),
    Experiment_Type     	VARCHAR2(100),
    Risk_Level          	VARCHAR2(50),
    Funding             	VARCHAR2(3) CHECK (Funding IN ('Yes', 'No')),
    Team_Size           	INT NOT NULL,
    Status              	VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date  	DATE,
    Project_End_Date        DATE,

    CONSTRAINT PK_Experimental_Projects PRIMARY KEY (Experimental_ID),
    CONSTRAINT FK_Exp_RD FOREIGN KEY (RD_ID) REFERENCES Research_Development(RD_ID),
    CONSTRAINT FK_Exp_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Exp_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Testing and Validation Team Table
CREATE TABLE Testing_Validation (
    Testing_ID          	INT NOT NULL,
    RD_ID               	INT NOT NULL,
    Team_Leader_ID      	INT NOT NULL,
    Prototype           	VARCHAR2(100),
    Test_Type           	VARCHAR2(100),
    Validated           	VARCHAR2(3) CHECK (Validated IN ('Yes', 'No')),
    Team_Size           	INT NOT NULL,
    Status              	VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date  	DATE,
    Project_End_Date        DATE,

    CONSTRAINT PK_Testing_Validation PRIMARY KEY (Testing_ID),
    CONSTRAINT FK_Test_RD FOREIGN KEY (RD_ID) REFERENCES Research_Development(RD_ID),
    CONSTRAINT FK_Test_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Test_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);