--Oracle APEX 23.2.4 SQL
--Schema: Aplicatie management firma IT
--ANDREEA.HASAN@STUDENT.UPT.RO

--			QA & Testing (Quality Assurance)

--Manual Testing
--Automated Testing
--Performance Testing
--Security Testing
--Mobile Testing
--UI/UX Testing
--TestOps / QA DevOps
--QA Automation Frameworks
--Compliance & Regulatory QA

--Main table for the QA & Testing Department
CREATE TABLE QA_Testing (
    QA_ID               		NUMBER NOT NULL,
    Description            		VARCHAR2(200),
    Team_Leader_ID      		NUMBER NOT NULL,
    Focus_Area          		VARCHAR2(200),
    Tested_Projects     		NUMBER NOT NULL,
    Team_Size           		NUMBER NOT NULL,
    Status              		VARCHAR2(10) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date  		DATE,
    Project_End_Date          	DATE,

    CONSTRAINT PK_QA_Testing PRIMARY KEY(QA_ID),
    CONSTRAINT FK_QA_Testing_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_QA_Testing_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Manual Testing Team Table
CREATE TABLE Manual_Testing (
    Manual_Testing_ID       		NUMBER NOT NULL,
    QA_ID                   		NUMBER NOT NULL,
    Team_Leader_ID          		NUMBER NOT NULL,
    Test_Types              		VARCHAR2(100),
    Test_Cases_Documented   		NUMBER NOT NULL,
    Reported_Defects        		NUMBER NOT NULL,
    Documentation_Tools     		VARCHAR2(200),
    Used_Environments       		VARCHAR2(200),
    Client_Interaction      		VARCHAR2(3),
    Team_Size               		NUMBER NOT NULL,
    Status                  		VARCHAR2(10) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date      		DATE,
    Project_End_Date          		DATE,

    CONSTRAINT PK_Manual_Testing PRIMARY KEY(Manual_Testing_ID),
    CONSTRAINT FK_Manual_Testing_QA FOREIGN KEY(QA_ID) REFERENCES QA_Testing(QA_ID),
    CONSTRAINT FK_Manual_Testing_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Manual_Testing_Status CHECK (Status IN ('Inactive', 'Active', 'Pending')),
    CONSTRAINT CHK_Manual_Client_Interaction CHECK (Client_Interaction IN ('Yes', 'No'))
);

--Automated Testing Team Table
CREATE TABLE Automated_Testing (
    Automated_Testing_ID     		NUMBER NOT NULL,
    QA_ID                    		NUMBER NOT NULL,
    Team_Leader_ID           		NUMBER NOT NULL,
    Frameworks               		VARCHAR2(100),
    Languages                		VARCHAR2(200),
    Coverage_Percentage      		NUMBER NOT NULL,
    Test_Cases_Documented    		NUMBER NOT NULL,
    Tools                    		VARCHAR2(150),
    CI_CD_Integration        		VARCHAR2(3),
    Team_Size                		NUMBER NOT NULL,
    Status                   		VARCHAR2(10) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date       		DATE,
    Project_End_Date          		DATE,

    CONSTRAINT PK_Automated_Testing PRIMARY KEY(Automated_Testing_ID),
    CONSTRAINT FK_Automated_Testing_QA FOREIGN KEY(QA_ID) REFERENCES QA_Testing(QA_ID),
    CONSTRAINT FK_Automated_Testing_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Automated_Testing_Status CHECK (Status IN ('Inactive', 'Active', 'Pending')),
    CONSTRAINT CHK_Automated_CI_CD CHECK (CI_CD_Integration IN ('Yes', 'No'))
);

--Performance Testing Team Table
CREATE TABLE Performance_Testing (
    Performance_Testing_ID    		NUMBER NOT NULL,
    QA_ID                     		NUMBER NOT NULL,
    Team_Leader_ID            		NUMBER NOT NULL,
    Test_Types                		VARCHAR2(100),
    Tools                     		VARCHAR2(150),
    Monitored_Metrics         		VARCHAR2(100),
    Concurrent_Users          		NUMBER NOT NULL,
    Duration_Seconds          		NUMBER NOT NULL,
    Infrastructure            		VARCHAR2(200),
    Team_Size                 		NUMBER NOT NULL,
    Status                    		VARCHAR2(10) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date        		DATE,
    Project_End_Date          		DATE,

    CONSTRAINT PK_Performance_Testing PRIMARY KEY(Performance_Testing_ID),
    CONSTRAINT FK_Performance_Testing_QA FOREIGN KEY(QA_ID) REFERENCES QA_Testing(QA_ID),
    CONSTRAINT FK_Performance_Testing_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Performance_Testing_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Security Testing Team Table
CREATE TABLE Security_Testing (
    Security_Testing_ID       		NUMBER NOT NULL,
    QA_ID                     		NUMBER NOT NULL,
    Team_Leader_ID            		NUMBER NOT NULL,
    Methods                   		VARCHAR2(100),
    Tools                     		VARCHAR2(150),
    Vulnerabilities_Found     		NUMBER NOT NULL,
    Applied_Standards         		VARCHAR2(100),
    Incidents_Reported        		NUMBER NOT NULL,
    Client_Data_Access        		VARCHAR2(3),
    Team_Size                 		NUMBER NOT NULL,
    Status                    		VARCHAR2(10) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date        		DATE,
    Project_End_Date          		DATE,

    CONSTRAINT PK_Security_Testing PRIMARY KEY(Security_Testing_ID),
    CONSTRAINT FK_Security_Testing_QA FOREIGN KEY(QA_ID) REFERENCES QA_Testing(QA_ID),
    CONSTRAINT FK_Security_Testing_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Security_Testing_Status CHECK (Status IN ('Inactive', 'Active', 'Pending')),
    CONSTRAINT CHK_Security_Client_Data_Access CHECK (Client_Data_Access IN ('Yes', 'No'))
);

--Mobile Testing Team Table
CREATE TABLE Mobile_Testing (
    Mobile_Testing_ID           	NUMBER NOT NULL,
    QA_ID                       	NUMBER NOT NULL,
    Team_Leader_ID              	NUMBER NOT NULL,
    Tested_Platforms            	VARCHAR2(200),
    Devices                     	VARCHAR2(200),
    Automation                  	VARCHAR2(3),
    Automation_Tools            	VARCHAR2(200),
    Manual_Testing_Percent      	NUMBER NOT NULL,
    Defects_Reported            	NUMBER NOT NULL,
    Network_Conditions          	VARCHAR2(100),
    Team_Size                   	NUMBER NOT NULL,
    Status                      	VARCHAR2(10) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date          	DATE,
    Project_End_Date          		DATE,

    CONSTRAINT PK_Mobile_Testing PRIMARY KEY(Mobile_Testing_ID),
    CONSTRAINT FK_Mobile_Testing_QA FOREIGN KEY(QA_ID) REFERENCES QA_Testing(QA_ID),
    CONSTRAINT FK_Mobile_Testing_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Mobile_Testing_Status CHECK (Status IN ('Inactive', 'Active', 'Pending')),
    CONSTRAINT CHK_Mobile_Automation CHECK (Automation IN ('Yes', 'No'))
);

--UI/UX Testing Team Table
CREATE TABLE UI_UX_Testing (
    UI_UX_Testing_ID         		NUMBER NOT NULL,
    QA_ID                    		NUMBER NOT NULL,
    Team_Leader_ID           		NUMBER NOT NULL,
    Devices_Resolutions      		VARCHAR2(200),
    Design_Guidelines        		VARCHAR2(200),
    Tools                    		VARCHAR2(150),
    Issues_Reported          		NUMBER NOT NULL,
    A_B_Testing              		VARCHAR2(3),
    Accessibility            		VARCHAR2(3),
    Team_Size                		NUMBER NOT NULL,
    Status                   		VARCHAR2(10) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date       		DATE,
    Project_End_Date          		DATE,

    CONSTRAINT PK_UI_UX_Testing PRIMARY KEY(UI_UX_Testing_ID),
    CONSTRAINT FK_UI_UX_Testing_QA FOREIGN KEY(QA_ID) REFERENCES QA_Testing(QA_ID),
    CONSTRAINT FK_UI_UX_Testing_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_UI_UX_Testing_Status CHECK (Status IN ('Inactive', 'Active', 'Pending')),
    CONSTRAINT CHK_UI_UX_AB_Testing CHECK (A_B_Testing IN ('Yes', 'No')),
    CONSTRAINT CHK_UI_UX_Accessibility CHECK (Accessibility IN ('Yes', 'No'))
);

--TestOps / QA DevOps Team Table
CREATE TABLE TestOps (
    TestOps_ID                		NUMBER NOT NULL,
    QA_ID                     		NUMBER NOT NULL,
    Team_Leader_ID            		NUMBER NOT NULL,
    CI_CD_Integration_Level   		VARCHAR2(50),
    Tools                     		VARCHAR2(150),
    Env_Test_Management       		VARCHAR2(3),
    Containerization          		VARCHAR2(3),
    Environment_Stack         		VARCHAR2(100),
    Parallel_Execution        		VARCHAR2(3),
    Team_Size                 		NUMBER NOT NULL,
    Status                    		VARCHAR2(10) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date        		DATE,
    Project_End_Date          		DATE,

    CONSTRAINT PK_TestOps PRIMARY KEY(TestOps_ID),
    CONSTRAINT FK_TestOps_QA FOREIGN KEY(QA_ID) REFERENCES QA_Testing(QA_ID),
    CONSTRAINT FK_TestOps_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_TestOps_Status CHECK (Status IN ('Inactive', 'Active', 'Pending')),
    CONSTRAINT CHK_TestOps_Env_Management CHECK (Env_Test_Management IN ('Yes', 'No')),
    CONSTRAINT CHK_TestOps_Containerization CHECK (Containerization IN ('Yes', 'No')),
    CONSTRAINT CHK_TestOps_Parallel_Execution CHECK (Parallel_Execution IN ('Yes', 'No'))
);

--QA Automation Frameworks Team Table
CREATE TABLE Automation_Frameworks (
    Automation_Frameworks_ID   		NUMBER NOT NULL,
    QA_ID                      		NUMBER NOT NULL,
    Team_Leader_ID             		NUMBER NOT NULL,
    Framework                  		VARCHAR2(100),
    Languages                  		VARCHAR2(200),
    Test_Type                  		VARCHAR2(100),
    CI_CD_Integration          		VARCHAR2(3),
    Parallel_Execution         		VARCHAR2(3),
    Reporting_Tools            		VARCHAR2(150),
    Maintenance_Frequency      		VARCHAR2(50),
    Team_Size                  		NUMBER NOT NULL,
    Status                     		VARCHAR2(10) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date         		DATE,
    Project_End_Date          		DATE,

    CONSTRAINT PK_Automation_Frameworks PRIMARY KEY (Automation_Frameworks_ID),
    CONSTRAINT FK_Automation_Frameworks_QA FOREIGN KEY (QA_ID) REFERENCES QA_Testing(QA_ID),
    CONSTRAINT FK_Automation_Frameworks_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Automation_Frameworks_Status CHECK (Status IN ('Inactive', 'Active', 'Pending')),
    CONSTRAINT CHK_Frameworks_CI_CD CHECK (CI_CD_Integration IN ('Yes', 'No')),
    CONSTRAINT CHK_Frameworks_Parallel_Execution CHECK (Parallel_Execution IN ('Yes', 'No'))
);

--Compliance & Regulatory QA Team Table
CREATE TABLE Compliance_Regulatory (
    Compliance_Regulatory_ID    	NUMBER NOT NULL,
    QA_ID                       	NUMBER NOT NULL,
    Team_Leader_ID              	NUMBER NOT NULL,
    Standards                   	VARCHAR2(100),
    Targeted_Areas              	VARCHAR2(200),
    Audits_Conducted            	NUMBER NOT NULL,
    Tools                       	VARCHAR2(150),
    Issues_Identified           	NUMBER NOT NULL,
    Remediation_Cycles          	NUMBER NOT NULL,
    Complete_Documentation      	VARCHAR2(3),
    Team_Size                   	NUMBER NOT NULL,
    Status                      	VARCHAR2(10) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date          	DATE,
    Project_End_Date          		DATE,

    CONSTRAINT PK_Compliance_Regulatory PRIMARY KEY (Compliance_Regulatory_ID),
    CONSTRAINT FK_Compliance_Regulatory_QA FOREIGN KEY (QA_ID) REFERENCES QA_Testing(QA_ID),
    CONSTRAINT FK_Compliance_Regulatory_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Compliance_Regulatory_Status CHECK (Status IN ('Inactive', 'Active', 'Pending')),
    CONSTRAINT CHK_Compliance_Docs CHECK (Complete_Documentation IN ('Yes', 'No'))
);