--Oracle APEX 23.2.4 SQL
--Schema: Aplicatie management firma IT
--ANDREEA.HASAN@STUDENT.UPT.RO

--			Data / BI / Analytics

--Data Engineering
--Business Intelligence (BI) Development
--Data Analysis / Business Analysis
--Data Science
--MLOps (Machine Learning Operations)
--Data Governance & Data Quality
--Data Visualization / Dashboard Design
--Big Data Management
--ETL Development
--Reporting & Insights

--Main table for the Data / BI / Analytics Department
CREATE TABLE Data_BI_Analytics (
    DAB_ID                 INT NOT NULL,
    Description            VARCHAR2(200),
    Team_Leader_ID         INT NOT NULL,
    Status                 VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date     DATE,
    Project_End_Date       DATE,

    CONSTRAINT PK_DAB PRIMARY KEY (DAB_ID),
    CONSTRAINT FK_Team_Leader_DAB FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Status_DAB CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Data Engineering Team Table
CREATE TABLE Data_Engineering (
    DE_ID                 INT NOT NULL,
    DAB_ID                INT NOT NULL,
    Team_Leader_ID        INT NOT NULL,
    Pipeline_Technologies VARCHAR2(100),
    Warehouse_Platform    VARCHAR2(100),
    Data_Formats          VARCHAR2(100),
    Realtime_Capable      VARCHAR2(3) CHECK (Realtime_Capable IN ('Yes', 'No')),
    Engineers             INT NOT NULL,
    Team_Size             INT NOT NULL,
    Status                VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date    DATE,
    Project_End_Date      DATE,

    CONSTRAINT PK_DE PRIMARY KEY (DE_ID),
    CONSTRAINT FK_DAB_DE FOREIGN KEY (DAB_ID) REFERENCES Data_BI_Analytics(DAB_ID),
    CONSTRAINT FK_Team_Leader_DE FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Status_DE CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Business Intelligence (BI) Development Team Table
CREATE TABLE BI_Development (
    BI_ID                      INT NOT NULL,
    DAB_ID                     INT NOT NULL,
    Team_Leader_ID             INT NOT NULL,
    BI_Tools                   VARCHAR2(100),
    Dashboards                 INT NOT NULL,
    Reporting_Frequency        VARCHAR2(50),
    Data_Sources_Integrated    VARCHAR2(100),
    Team_Size                  INT NOT NULL,
    Status                     VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date         DATE,
    Project_End_Date           DATE,

    CONSTRAINT PK_BI PRIMARY KEY (BI_ID),
    CONSTRAINT FK_DAB_BI FOREIGN KEY (DAB_ID) REFERENCES Data_BI_Analytics(DAB_ID),
    CONSTRAINT FK_Team_Leader_BI FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Status_BI CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Data Analysis / Business Analysis Team Table
CREATE TABLE Data_Analysis (
    DA_ID                      INT NOT NULL,
    DAB_ID                     INT NOT NULL,
    Team_Leader_ID             INT NOT NULL,
    Analysis_Tools             VARCHAR2(100),
    Analysis_Type              VARCHAR2(100),
    Business_Areas_Covered     VARCHAR2(100),
    Insight_Reports            INT NOT NULL,
    Team_Size                  INT NOT NULL,
    Status                     VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date         DATE,
    Project_End_Date           DATE,

    CONSTRAINT PK_DA PRIMARY KEY (DA_ID),
    CONSTRAINT FK_DAB_DA FOREIGN KEY (DAB_ID) REFERENCES Data_BI_Analytics(DAB_ID),
    CONSTRAINT FK_Team_Leader_DA FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Status_DA CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Data Science Team Table
CREATE TABLE Data_Science (
    DS_ID                 INT NOT NULL,
    DAB_ID                INT NOT NULL,
    Team_Leader_ID        INT NOT NULL,
    ML_Frameworks         VARCHAR2(100),

    Models_In_Production  INT NOT NULL,
    Model_Types           VARCHAR2(100),
    Data_Scientists       INT NOT NULL,
    Team_Size             INT NOT NULL,
    Status                VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date    DATE,
    Project_End_Date      DATE,

    CONSTRAINT PK_DS PRIMARY KEY (DS_ID),
    CONSTRAINT FK_DAB_DS FOREIGN KEY (DAB_ID) REFERENCES Data_BI_Analytics(DAB_ID),
    CONSTRAINT FK_Team_Leader_DS FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Status_DS CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--MLOps (Machine Learning Operations) Team Table
CREATE TABLE MLOps (
    MLOps_ID               INT NOT NULL,
    DAB_ID                 INT NOT NULL,
    Team_Leader_ID         INT NOT NULL,
    Deployment_Tools       VARCHAR2(100),
    Monitoring_Enabled     VARCHAR2(3) CHECK (Monitoring_Enabled IN ('Yes', 'No')),
    Models_Deployed        INT NOT NULL,
    CI_CD_Pipelines        INT NOT NULL,
    Team_Size              INT NOT NULL,
    Status                 VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date     DATE,
    Project_End_Date       DATE,

    CONSTRAINT PK_MLOps PRIMARY KEY (MLOps_ID),
    CONSTRAINT FK_DAB_MLOps FOREIGN KEY (DAB_ID) REFERENCES Data_BI_Analytics(DAB_ID),
    CONSTRAINT FK_Team_Leader_MLOps FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Status_MLOps CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Data Governance & Data Quality Team Table
CREATE TABLE DGDQ (
    DGDQ_ID                   INT NOT NULL,
    DAB_ID                    INT NOT NULL,
    Team_Leader_ID            INT NOT NULL,
    Data_Policies_Defined     INT NOT NULL,
    Data_Quality_Framework    VARCHAR2(100),
    Compliance_Regulations    VARCHAR2(100),
    Audit_Frequency           VARCHAR2(50),
    Team_Size                 INT NOT NULL,
    Status                    VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date        DATE,
    Project_End_Date          DATE,

    CONSTRAINT PK_DGDQ PRIMARY KEY (DGDQ_ID),
    CONSTRAINT FK_DAB_DGDQ FOREIGN KEY (DAB_ID) REFERENCES Data_BI_Analytics(DAB_ID),
    CONSTRAINT FK_Team_Leader_DGDQ FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Status_DGDQ CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Data Visualization / Dashboard Design Team Table
CREATE TABLE DVDD (
    DVDD_ID                INT NOT NULL,
    DAB_ID                 INT NOT NULL,
    Team_Leader_ID         INT NOT NULL,
    Tools                  VARCHAR2(100),
    Dashboard_Types        VARCHAR2(100),
    Interactivity_Level    VARCHAR2(50),
    End_Users_Targeted     VARCHAR2(100),
    Team_Size              INT NOT NULL,
    Status                 VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date     DATE,
    Project_End_Date       DATE,

    CONSTRAINT PK_DVDD PRIMARY KEY (DVDD_ID),
    CONSTRAINT FK_DAB_DVDD FOREIGN KEY (DAB_ID) REFERENCES Data_BI_Analytics(DAB_ID),
    CONSTRAINT FK_Team_Leader_DVDD FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Status_DVDD CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Big Data Management Team Table
CREATE TABLE BDM (
    BDM_ID                INT NOT NULL,
    DAB_ID                INT NOT NULL,
    Team_Leader_ID        INT NOT NULL,
    Big_Data_Technology   VARCHAR2(100),
    Data_Lake_Used        VARCHAR2(3) CHECK (Data_Lake_Used IN ('Yes', 'No')),
    Daily_Data_Volume     INT NOT NULL,
    Streaming_Capabilities VARCHAR2(100),
    Team_Size             INT NOT NULL,
    Status                VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date    DATE,
    Project_End_Date      DATE,

    CONSTRAINT PK_BDM PRIMARY KEY (BDM_ID),
    CONSTRAINT FK_DAB_BDM FOREIGN KEY (DAB_ID) REFERENCES Data_BI_Analytics(DAB_ID),
    CONSTRAINT FK_Team_Leader_BDM FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Status_BDM CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--ETL Development Team Table
CREATE TABLE ETL (
    ETL_ID                    INT NOT NULL,
    DAB_ID                    INT NOT NULL,
    Team_Leader_ID            INT NOT NULL,
    ETL_Tools                 VARCHAR2(100),
    Processes                 INT NOT NULL,
    Data_Sources_Integrated   VARCHAR2(100),
    Schedule_Type             VARCHAR2(50),
    Team_Size                 INT NOT NULL,
    Status                    VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date        DATE,
    Project_End_Date          DATE,

    CONSTRAINT PK_ETL PRIMARY KEY (ETL_ID),
    CONSTRAINT FK_DAB_ETL FOREIGN KEY (DAB_ID) REFERENCES Data_BI_Analytics(DAB_ID),
    CONSTRAINT FK_Team_Leader_ETL FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Status_ETL CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

--Reporting & Insights Team Table
CREATE TABLE Reporting_Insights (
    RI_ID                 INT NOT NULL,
    DAB_ID                INT NOT NULL,
    Team_Leader_ID        INT NOT NULL,
    Report_Types          VARCHAR2(100),
    KPIs_Tracked          INT NOT NULL,
    Delivery_Methods      VARCHAR2(100),
    Insight_Generation    VARCHAR2(3) CHECK (Insight_Generation IN ('Yes', 'No')),
    Team_Size             INT NOT NULL,
    Status                VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date    DATE,
    Project_End_Date      DATE,

    CONSTRAINT PK_RI PRIMARY KEY (RI_ID),
    CONSTRAINT FK_DAB_RI FOREIGN KEY (DAB_ID) REFERENCES Data_BI_Analytics(DAB_ID),
    CONSTRAINT FK_Team_Leader_RI FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Status_RI CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);