CREATE OR REPLACE VIEW DevOpsSRE_Calendar AS
SELECT 
    DS_ID AS Entry_ID,
    'DevOps Core' AS Team_Type,
    'Mission: ' || Mission AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM DevOps_SRE

UNION ALL

SELECT 
    CPipeM_ID,
    'CI/CD Pipeline',
    'Pipeline: ' || Pipeline_Name || ', Tool: ' || Tool || ', Stages: ' || Stages AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM CICD_Pipeline_Management

UNION ALL

SELECT 
    IaC_ID,
    'Infrastructure as Code',
    'Tool: ' || Tool || ', Env: ' || Environment_Target || ', Repo: ' || Code_Repository AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Infrastructure_as_Code

UNION ALL

SELECT 
    ObsMon_ID,
    'Observability & Monitoring',
    'Tool: ' || Tool || ', Scope: ' || Monitoring_Scope AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Observability_Monitoring

UNION ALL

SELECT 
    IRRE_ID,
    'Incident & Reliability',
    'Process: ' || Incident_Process_Name || ', On-Call: ' || On_Call_Rotation_Model AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Incident_Response_Reliability

UNION ALL

SELECT 
    PE_ID,
    'Platform Engineering',
    'Platform: ' || Platform_Name || ', Tech: ' || Technologies_Used AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Platform_Engineering

UNION ALL

SELECT 
    CA_ID,
    'Cloud Automation',
    'Cloud: ' || Cloud_Provider || ', Tool: ' || Automation_Tool || ', Type: ' || Resource_Type AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Cloud_Automation;

CREATE OR REPLACE VIEW DevOps_SRE_Teams_View AS
SELECT
    'CI/CD Pipeline Management' AS Team_Type,
    cpm.CPipeM_ID AS Team_ID,
    cpm.DS_ID,
    cpm.Team_Leader_ID,
    'Pipeline: ' || cpm.Pipeline_Name || ', Tool: ' || cpm.Tool || ', Stages: ' || cpm.Stages || ', Rollback: ' || cpm.Auto_Rollback_Enabled || ', Notifications: ' || cpm.Notification_Channels AS Description,
    cpm.Status,
    cpm.Team_Size,
    cpm.Project_Start_Date,
    cpm.Project_End_Date
FROM CICD_Pipeline_Management cpm

UNION ALL

SELECT
    'Infrastructure as Code',
    iac.IaC_ID,
    iac.DS_ID,
    iac.Team_Leader_ID,
    'Tool: ' || iac.Tool || ', Repo: ' || iac.Code_Repository || ', Env: ' || iac.Environment_Target || ', Versioning: ' || iac.Version_Control || ', Auto-Approve: ' || iac.Auto_Approve_Changes,
    iac.Status,
    iac.Team_Size,
    iac.Project_Start_Date,
    iac.Project_End_Date
FROM Infrastructure_as_Code iac

UNION ALL

SELECT
    'Observability & Monitoring',
    om.ObsMon_ID,
    om.DS_ID,
    om.Team_Leader_ID,
    'Tool: ' || om.Tool || ', Scope: ' || om.Monitoring_Scope || ', Alerts: ' || om.Alerting_Enabled || ', Dashboard: ' || om.Dashboard_URL,
    om.Status,
    om.Team_Size,
    om.Project_Start_Date,
    om.Project_End_Date
FROM Observability_Monitoring om

UNION ALL

SELECT
    'Incident Response & Reliability',
    irr.IRRE_ID,
    irr.DS_ID,
    irr.Team_Leader_ID,
    'Process: ' || irr.Incident_Process_Name || ', On-Call: ' || irr.On_Call_Rotation_Model || ', Tool: ' || irr.Incident_Tracking_Tool || ', Postmortem: ' || irr.PostMortem_Required,
    irr.Status,
    irr.Team_Size,
    irr.Project_Start_Date,
    irr.Project_End_Date
FROM Incident_Response_Reliability irr

UNION ALL

SELECT
    'Platform Engineering',
    pe.PE_ID,
    pe.DS_ID,
    pe.Team_Leader_ID,
    'Platform: ' || pe.Platform_Name || ', Tech: ' || pe.Technologies_Used || ', Self-Service: ' || pe.Self_Service_Portal || ', Docs: ' || pe.Documentation_URL || ', Onboarding: ' || pe.Onboarding_Required,
    pe.Status,
    pe.Team_Size,
    pe.Project_Start_Date,
    pe.Project_End_Date
FROM Platform_Engineering pe

UNION ALL

SELECT
    'Cloud Automation',
    ca.CA_ID,
    ca.DS_ID,
    ca.Team_Leader_ID,
    'Provider: ' || ca.Cloud_Provider || ', Tool: ' || ca.Automation_Tool || ', Resource: ' || ca.Resource_Type || ', Scaling: ' || ca.Auto_Scaling_Enabled || ', Schedule: ' || ca.Scheduled_Automation,
    ca.Status,
    ca.Team_Size,
    ca.Project_Start_Date,
    ca.Project_End_Date
FROM Cloud_Automation ca;
