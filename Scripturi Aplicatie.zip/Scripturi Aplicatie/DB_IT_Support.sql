--Oracle APEX 23.2.4 SQL
--Schema: Aplicatie management firma IT
--ANDREEA.HASAN@STUDENT.UPT.RO

--			IT Support / Helpdesk

--L1 Support (Level 1 / Frontline Support)
--L2 Support (Technical Support)
--L3 Support (Expert Support)
--Incident Management
--Service Request Management
--IT Asset Management
--Desktop Support
--Remote Support
--Knowledge Management
--VIP / Executive Support
--Service Desk Coordination

--Main table for the IT Support / Helpdesk Department
CREATE TABLE IT_Support (
    Helpdesk_ID          INT NOT NULL,
    Description          VARCHAR2(200),
    Team_Leader_ID       INT NOT NULL,
    Purpose              VARCHAR2(50),
    Work_Hours           VARCHAR2(50),
    Location             VARCHAR2(20) CHECK (Location IN ('On-Site', 'Remote', 'Hybrid')),
    Team_Size            INT NOT NULL,
    Status               VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date   DATE,
    Project_End_Date     DATE,

    CONSTRAINT PK_IT_Support PRIMARY KEY (Helpdesk_ID),
    CONSTRAINT FK_IT_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_IT_Status CHECK (Status IN ('Inactive', 'Active', 'Pending')),
    CONSTRAINT CHK_IT_Dates CHECK (Project_End_Date IS NULL OR Project_End_Date >= Project_Start_Date)
);

--L1 Support (Level 1 / Frontline Support) Team Table
CREATE TABLE L1_Support (
    L1_ID               INT NOT NULL,
    Helpdesk_ID         INT NOT NULL,
    Team_Leader_ID      INT NOT NULL,
    Daily_Tickets       INT NOT NULL,
    Response_Time       INT NOT NULL,
    Common_Issues       VARCHAR2(100),
    Tickets_Escalated_L2 INT NOT NULL,
    Tools               VARCHAR2(100),
    Team_Size           INT NOT NULL,
    Status              VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date  DATE,
    Project_End_Date    DATE,

    CONSTRAINT PK_L1_Support PRIMARY KEY (L1_ID),
    CONSTRAINT FK_L1_Helpdesk FOREIGN KEY (Helpdesk_ID) REFERENCES IT_Support(Helpdesk_ID),
    CONSTRAINT FK_L1_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_L1_Status CHECK (Status IN ('Inactive', 'Active', 'Pending')),
    CONSTRAINT CHK_L1_Dates CHECK (Project_End_Date IS NULL OR Project_End_Date >= Project_Start_Date)
);

--L2 Support (Technical Support) Team Table
CREATE TABLE L2_Support (
    L2_ID               INT NOT NULL,
    Helpdesk_ID         INT NOT NULL,
    Team_Leader_ID      INT NOT NULL,
    Domains             VARCHAR2(100),
    Resolution_Time     INT NOT NULL,
    Ticket_Destination  VARCHAR2(100),
    Incidents_Handled   VARCHAR2(100),
    Team_Size           INT NOT NULL,
    Status              VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date  DATE,
    Project_End_Date    DATE,

    CONSTRAINT PK_L2_Support PRIMARY KEY (L2_ID),
    CONSTRAINT FK_L2_Helpdesk FOREIGN KEY (Helpdesk_ID) REFERENCES IT_Support(Helpdesk_ID),
    CONSTRAINT FK_L2_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_L2_Status CHECK (Status IN ('Inactive', 'Active', 'Pending')),
    CONSTRAINT CHK_L2_Dates CHECK (Project_End_Date IS NULL OR Project_End_Date >= Project_Start_Date)
);

--L3 Support (Expert Support) Team Table
CREATE TABLE L3_Support (
    L3_ID               INT NOT NULL,
    Helpdesk_ID         INT NOT NULL,
    Team_Leader_ID      INT NOT NULL,
    Domains             VARCHAR2(100),
    Managed_Systems     VARCHAR2(100),
    Bug_Fixing          VARCHAR2(3) CHECK (Bug_Fixing IN ('Yes', 'No')),
    Vendor_Interaction  VARCHAR2(3) CHECK (Vendor_Interaction IN ('Yes', 'No')),
    L2_Escalation_Rate  INT NOT NULL,
    Team_Size           INT NOT NULL,
    Status              VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date  DATE,
    Project_End_Date    DATE,

    CONSTRAINT PK_L3_Support PRIMARY KEY (L3_ID),
    CONSTRAINT FK_L3_Helpdesk FOREIGN KEY (Helpdesk_ID) REFERENCES IT_Support(Helpdesk_ID),
    CONSTRAINT FK_L3_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_L3_Status CHECK (Status IN ('Inactive', 'Active', 'Pending')),
    CONSTRAINT CHK_L3_Dates CHECK (Project_End_Date IS NULL OR Project_End_Date >= Project_Start_Date)
);

--Incident Management Team Table
CREATE TABLE Incident_Management (
    Incident_ID         INT NOT NULL,
    Helpdesk_ID         INT NOT NULL,
    Team_Leader_ID      INT NOT NULL,
    Incidents_Handled   VARCHAR2(100),
    SLA_Compliance      INT NOT NULL,
    Critical_Incidents  INT NOT NULL,
    Escalation_Policy   VARCHAR2(100),
    Team_Size           INT NOT NULL,
    Status              VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date  DATE,
    Project_End_Date    DATE,

    CONSTRAINT PK_Incident_Management PRIMARY KEY (Incident_ID),
    CONSTRAINT FK_Incident_Helpdesk FOREIGN KEY (Helpdesk_ID) REFERENCES IT_Support(Helpdesk_ID),
    CONSTRAINT FK_Incident_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Incident_Status CHECK (Status IN ('Inactive', 'Active', 'Pending')),
    CONSTRAINT CHK_Incident_Dates CHECK (Project_End_Date IS NULL OR Project_End_Date >= Project_Start_Date)
);

--Service Request Management Team Table
CREATE TABLE Service_Request_Management (
    Request_ID          INT NOT NULL,
    Helpdesk_ID         INT NOT NULL,
    Team_Leader_ID      INT NOT NULL,
    Request_Type        VARCHAR2(100),
    Resolution_Time     INT NOT NULL,
    Monthly_Requests    INT NOT NULL,
    Automation_Level    INT NOT NULL,
    Approval            VARCHAR2(3) CHECK (Approval IN ('Yes', 'No')),
    Team_Size           INT NOT NULL,
    Status              VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date  DATE,
    Project_End_Date    DATE,

    CONSTRAINT PK_Service_Request PRIMARY KEY (Request_ID),
    CONSTRAINT FK_Request_Helpdesk FOREIGN KEY (Helpdesk_ID) REFERENCES IT_Support(Helpdesk_ID),
    CONSTRAINT FK_Request_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Request_Status CHECK (Status IN ('Inactive', 'Active', 'Pending')),
    CONSTRAINT CHK_Request_Dates CHECK (Project_End_Date IS NULL OR Project_End_Date >= Project_Start_Date)
);

--IT Asset Management Team Table
CREATE TABLE IT_Asset_Management (
    Asset_ID            INT NOT NULL,
    Helpdesk_ID         INT NOT NULL,
    Team_Leader_ID      INT NOT NULL,
    Equipment_Count     INT NOT NULL,
    Categories          VARCHAR2(100),
    Inventory_System    VARCHAR2(100),
    Audit_Frequency     VARCHAR2(50),
    Loss_Defect_Percentage INT NOT NULL,
    Team_Size           INT NOT NULL,
    Status              VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date  DATE,
    Project_End_Date    DATE,

    CONSTRAINT PK_IT_Asset PRIMARY KEY (Asset_ID),
    CONSTRAINT FK_Asset_Helpdesk FOREIGN KEY (Helpdesk_ID) REFERENCES IT_Support(Helpdesk_ID),
    CONSTRAINT FK_Asset_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Asset_Status CHECK (Status IN ('Inactive', 'Active', 'Pending')),
    CONSTRAINT CHK_Asset_Dates CHECK (Project_End_Date IS NULL OR Project_End_Date >= Project_Start_Date)
);

--Desktop Support Team Table
CREATE TABLE Desktop_Support (
    Desktop_ID          INT NOT NULL,
    Helpdesk_ID         INT NOT NULL,
    Team_Leader_ID      INT NOT NULL,
    Operating_Systems   VARCHAR2(100),
    Daily_Requests_Count INT NOT NULL,
    On_Site             VARCHAR2(3) CHECK (On_Site IN ('Yes', 'No')),
    Resolved_Issues     VARCHAR2(100),
    Tools               VARCHAR2(100),
    Team_Size           INT NOT NULL,
    Status              VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date  DATE,
    Project_End_Date    DATE,

    CONSTRAINT PK_Desktop_Support PRIMARY KEY (Desktop_ID),
    CONSTRAINT FK_Desktop_Helpdesk FOREIGN KEY (Helpdesk_ID) REFERENCES IT_Support(Helpdesk_ID),
    CONSTRAINT FK_Desktop_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Desktop_Status CHECK (Status IN ('Inactive', 'Active', 'Pending')),
    CONSTRAINT CHK_Desktop_Dates CHECK (Project_End_Date IS NULL OR Project_End_Date >= Project_Start_Date)
);

--Remote Support Team Table
CREATE TABLE Remote_Support (
    Remote_ID           INT NOT NULL,
    Helpdesk_ID         INT NOT NULL,
    Team_Leader_ID      INT NOT NULL,
    Tools               VARCHAR2(100),
    Daily_Requests_Count INT NOT NULL,
    Resolution_Time     INT NOT NULL,
    Channels            VARCHAR2(100),
    Team_Size           INT NOT NULL,
    Status              VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date  DATE,
    Project_End_Date    DATE,

    CONSTRAINT PK_Remote_Support PRIMARY KEY (Remote_ID),
    CONSTRAINT FK_Remote_Helpdesk FOREIGN KEY (Helpdesk_ID) REFERENCES IT_Support(Helpdesk_ID),
    CONSTRAINT FK_Remote_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Remote_Status CHECK (Status IN ('Inactive', 'Active', 'Pending')),
    CONSTRAINT CHK_Remote_Dates CHECK (Project_End_Date IS NULL OR Project_End_Date >= Project_Start_Date)
);

--Knowledge Management Team Table
CREATE TABLE Knowledge_Management (
    Knowledge_ID          INT NOT NULL,
    Helpdesk_ID           INT NOT NULL,
    Team_Leader_ID        INT NOT NULL,
    Knowledge_Base        VARCHAR2(100),
    Number_Articles_Created INT NOT NULL,
    Monthly_Article_Views INT NOT NULL,
    Documentation_Processes INT NOT NULL,
    Contribution          INT NOT NULL,
    Team_Size             INT NOT NULL,
    Status                VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date    DATE,
    Project_End_Date      DATE,

    CONSTRAINT PK_Knowledge PRIMARY KEY (Knowledge_ID),
    CONSTRAINT FK_Knowledge_Helpdesk FOREIGN KEY (Helpdesk_ID) REFERENCES IT_Support(Helpdesk_ID),
    CONSTRAINT FK_Knowledge_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Knowledge_Status CHECK (Status IN ('Inactive', 'Active', 'Pending')),
    CONSTRAINT CHK_Knowledge_Dates CHECK (Project_End_Date IS NULL OR Project_End_Date >= Project_Start_Date)
);