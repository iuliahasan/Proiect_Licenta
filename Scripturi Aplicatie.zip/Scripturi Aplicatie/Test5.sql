CREATE OR REPLACE VIEW Infrastructure_Calendar AS
SELECT 
    Infrastructure_ID AS Infra_ID,
    'General Infrastructure' AS Team_Type,
    Description AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Infrastructure

UNION ALL

SELECT 
    Administration_ID,
    'System Administration',
    'OS: ' || Operating_Systems || ', Servers: ' || Server_Count AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM System_Administration

UNION ALL

SELECT 
    Network_ID,
    'Network Engineering',
    'Devices: ' || Network_Devices || ', VPNs: ' || Active_VPN_Connections AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Network_Engineering

UNION ALL

SELECT 
    Cloud_ID,
    'Cloud Infrastructure',
    'Providers: ' || Cloud_Providers || ', Spend: $' || Monthly_Cloud_Spend AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Cloud_Infrastructure

UNION ALL

SELECT 
    VS_ID,
    'Virtualization & Storage',
    'VMs: ' || Virtual_Machines || ', Capacity: ' || Storage_Capacity_GB || 'GB' AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Virtualization_Storage

UNION ALL

SELECT 
    Data_Center_ID,
    'Data Center Operations',
    'Servers: ' || Physical_Servers || ', Power: ' || Power_Usage_KW || 'KW' AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Data_Center_Operations

UNION ALL

SELECT 
    Infrastructure_Security_ID,
    'Infrastructure Security',
    'Firewalls: ' || Firewalls || ', Audits: ' || Annual_Audits AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Infrastructure_Security;

CREATE OR REPLACE VIEW Infrastructure_Teams_View AS
SELECT
    'System Administration' AS Team_Type,
    sa.Administration_ID AS Team_ID,
    sa.Infrastructure_ID,
    sa.Team_Leader_ID,
    'OS: ' || sa.Operating_Systems || ', Tools: ' || sa.Tools || ', Issues/Month: ' || sa.Monthly_Issues_Resolved AS Method_Description,
    sa.Status,
    sa.Team_Size,
    sa.Project_Start_Date,
    sa.Project_End_Date
FROM System_Administration sa

UNION ALL

SELECT
    'Network Engineering',
    ne.Network_ID,
    ne.Infrastructure_ID,
    ne.Team_Leader_ID,
    'Devices: ' || ne.Network_Devices || ', VPNs: ' || ne.Active_VPN_Connections || ', Topology: ' || ne.Topology,
    ne.Status,
    ne.Team_Size,
    ne.Project_Start_Date,
    ne.Project_End_Date
FROM Network_Engineering ne

UNION ALL

SELECT
    'Cloud Infrastructure',
    ci.Cloud_ID,
    ci.Infrastructure_ID,
    ci.Team_Leader_ID,
    'Provider: ' || ci.Cloud_Providers || ', Containers: ' || ci.Container_Technologies || ', Spend: ' || TO_CHAR(ci.Monthly_Cloud_Spend),
    ci.Status,
    ci.Team_Size,
    ci.Project_Start_Date,
    ci.Project_End_Date
FROM Cloud_Infrastructure ci

UNION ALL

SELECT
    'Virtualization & Storage',
    vs.VS_ID,
    vs.Infrastructure_ID,
    vs.Team_Leader_ID,
    'Virtualization: ' || vs.Virtualization_Tech || ', Storage: ' || vs.Storage_Tech || ', Capacity: ' || vs.Storage_Capacity_GB || ' GB',
    vs.Status,
    vs.Team_Size,
    vs.Project_Start_Date,
    vs.Project_End_Date
FROM Virtualization_Storage vs

UNION ALL

SELECT
    'Data Center Operations',
    dco.Data_Center_ID,
    dco.Infrastructure_ID,
    dco.Team_Leader_ID,
    'Servers: ' || dco.Physical_Servers || ', Power: ' || TO_CHAR(dco.Power_Usage_KW) || ' KW, Location: ' || dco.Locations,
    dco.Status,
    dco.Team_Size,
    dco.Project_Start_Date,
    dco.Project_End_Date
FROM Data_Center_Operations dco

UNION ALL

SELECT
    'Infrastructure Security',
    isec.Infrastructure_Security_ID,
    isec.Infrastructure_ID,
    isec.Team_Leader_ID,
    'Firewalls: ' || isec.Firewalls || ', Patch Mgmt: ' || isec.Patch_Management || ', Audits/Year: ' || isec.Annual_Audits,
    isec.Status,
    isec.Team_Size,
    isec.Project_Start_Date,
    isec.Project_End_Date
FROM Infrastructure_Security isec;
