--Oracle APEX 23.2.4 SQL
--Schema: Aplicatie management firma IT
--ANDREEA.HASAN@STUDENT.UPT.RO

--			Project Management
--Agile Project Management
--Waterfall / Traditional PM
--Hybrid Project Management
--Program Management
--Project Coordination / PMO (Project Management Office)

--Main table for the Project Management Department
CREATE TABLE Project_Management (
    PJ_ID                   NUMBER NOT NULL,
    Description             VARCHAR2(200),
    Team_Leader_ID          NUMBER NOT NULL,
    Methodology             VARCHAR2(50),
    Team_Size               NUMBER NOT NULL,
    Status                  VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date      DATE,
    Project_End_Date        DATE,

    CONSTRAINT PK_Project_Management PRIMARY KEY (PJ_ID),
    CONSTRAINT FK_PM_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_PM_Status CHECK (Status IN ('Inactive', 'Active', 'Pending'))
);

-- Agile Project Management Team Table
CREATE TABLE Agile (
    Agile_ID                NUMBER NOT NULL,
    PJ_ID                   NUMBER NOT NULL,
    Team_Leader_ID          NUMBER NOT NULL,
    Scrum_Teams             NUMBER NOT NULL,
    Sprint_Length           NUMBER NOT NULL,
    Framework               VARCHAR2(50),
    Tools                   VARCHAR2(100),
    Daily_Meetings          VARCHAR2(3),
    Retrospectives          VARCHAR2(3),
    Has_Product_Owner       VARCHAR2(3),
    Team_Size               NUMBER NOT NULL,
    Status                  VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date      DATE,
    Project_End_Date        DATE,

    CONSTRAINT PK_Agile PRIMARY KEY (Agile_ID),
    CONSTRAINT FK_Agile_PJ FOREIGN KEY (PJ_ID) REFERENCES Project_Management(PJ_ID),
    CONSTRAINT FK_Agile_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Agile_Status CHECK (Status IN ('Inactive', 'Active', 'Pending')),
    CONSTRAINT CHK_Agile_Daily_Meetings CHECK (Daily_Meetings IN ('Yes', 'No')),
    CONSTRAINT CHK_Agile_Retrospectives CHECK (Retrospectives IN ('Yes', 'No')),
    CONSTRAINT CHK_Agile_Has_Product_Owner CHECK (Has_Product_Owner IN ('Yes', 'No'))
);

-- Waterfall / Traditional Project Management Team Table
CREATE TABLE Waterfall (
    Waterfall_ID            NUMBER NOT NULL,
    PJ_ID                   NUMBER NOT NULL,
    Team_Leader_ID          NUMBER NOT NULL,
    Active_Projects         NUMBER NOT NULL,
    Number_Of_Phases        NUMBER NOT NULL,
    Current_Phase           VARCHAR2(50),
    Full_Documentation      VARCHAR2(3),
    Has_Gantt_Chart         VARCHAR2(3),
    Tools                   VARCHAR2(100),
    Delay_Estimate_Days     NUMBER NOT NULL,
    Team_Size               NUMBER NOT NULL,
    Status                  VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date      DATE,
    Project_End_Date        DATE,

    CONSTRAINT PK_Waterfall PRIMARY KEY (Waterfall_ID),
    CONSTRAINT FK_Waterfall_PJ FOREIGN KEY (PJ_ID) REFERENCES Project_Management(PJ_ID),
    CONSTRAINT FK_Waterfall_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Waterfall_Status CHECK (Status IN ('Inactive', 'Active', 'Pending')),
    CONSTRAINT CHK_Waterfall_Documentation CHECK (Full_Documentation IN ('Yes', 'No')),
    CONSTRAINT CHK_Waterfall_Gantt_Chart CHECK (Has_Gantt_Chart IN ('Yes', 'No'))
);

-- Hybrid Project Management Team Table
CREATE TABLE Hybrid_PM (
    Hybrid_ID                   NUMBER NOT NULL,
    PJ_ID                       NUMBER NOT NULL,
    Team_Leader_ID              NUMBER NOT NULL,
    Agile_Phase_Included        VARCHAR2(3),
    Waterfall_Phase_Included    VARCHAR2(3),
    Main_Methodology            VARCHAR2(50),
    Agile_Tools                 VARCHAR2(100),
    Waterfall_Tools             VARCHAR2(100),
    Methodology_Integration     VARCHAR2(200),
    Team_Size                   NUMBER NOT NULL,
    Status                      VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date          DATE,
    Project_End_Date            DATE,

    CONSTRAINT PK_Hybrid_PM PRIMARY KEY (Hybrid_ID),
    CONSTRAINT FK_Hybrid_PM_PJ FOREIGN KEY (PJ_ID) REFERENCES Project_Management(PJ_ID),
    CONSTRAINT FK_Hybrid_PM_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Hybrid_PM_Status CHECK (Status IN ('Inactive', 'Active', 'Pending')),
    CONSTRAINT CHK_Hybrid_Agile_Phase CHECK (Agile_Phase_Included IN ('Yes', 'No')),
    CONSTRAINT CHK_Hybrid_Waterfall_Phase CHECK (Waterfall_Phase_Included IN ('Yes', 'No'))
);

-- Program Management Team Table
CREATE TABLE Program_Management (
    Program_ID              NUMBER NOT NULL,
    PJ_ID                   NUMBER NOT NULL,
    Team_Leader_ID          NUMBER NOT NULL,
    Program_Name            VARCHAR2(100) NOT NULL,
    Manager_ID              NUMBER NOT NULL,
    Total_Projects          NUMBER NOT NULL,
    Active_Projects         NUMBER NOT NULL,
    Budget                  NUMBER(12,2) NOT NULL,
    Program_Objective       VARCHAR2(200),
    Key_Risks               VARCHAR2(3),
    Team_Size               NUMBER NOT NULL,
    Status                  VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date      DATE,
    Project_End_Date        DATE,

    CONSTRAINT PK_Program_Management PRIMARY KEY (Program_ID),
    CONSTRAINT FK_Program_PJ FOREIGN KEY (PJ_ID) REFERENCES Project_Management(PJ_ID),
    CONSTRAINT FK_Program_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT FK_Program_Manager FOREIGN KEY (Manager_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Program_Status CHECK (Status IN ('Inactive', 'Active', 'Pending')),
    CONSTRAINT CHK_Program_Key_Risks CHECK (Key_Risks IN ('Yes', 'No'))
);

-- Project Coordination / PMO (Project Management Office) Team Table
CREATE TABLE Project_Coordination (
    Coordination_ID         NUMBER NOT NULL,
    PJ_ID                   NUMBER NOT NULL,
    Team_Leader_ID          NUMBER NOT NULL,
    Manager_ID              NUMBER NOT NULL,
    Training_Programs       VARCHAR2(3),
    Standardized_Templates  NUMBER NOT NULL,
    KPI_Monitoring          VARCHAR2(3),
    Admin_Tools             VARCHAR2(100),
    Audit_Allowed           VARCHAR2(3),
    Team_Size               NUMBER NOT NULL,
    Status                  VARCHAR2(30) DEFAULT 'Inactive' NOT NULL,
    Project_Start_Date      DATE,
    Project_End_Date        DATE,

    CONSTRAINT PK_Project_Coordination PRIMARY KEY (Coordination_ID),
    CONSTRAINT FK_Coordination_PJ FOREIGN KEY (PJ_ID) REFERENCES Project_Management(PJ_ID),
    CONSTRAINT FK_Coordination_Team_Leader FOREIGN KEY (Team_Leader_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT FK_Coordination_Manager FOREIGN KEY (Manager_ID) REFERENCES Employees(Employee_ID),
    CONSTRAINT CHK_Coordination_Status CHECK (Status IN ('Inactive', 'Active', 'Pending')),
    CONSTRAINT CHK_Coordination_Training CHECK (Training_Programs IN ('Yes', 'No')),
    CONSTRAINT CHK_Coordination_KPI CHECK (KPI_Monitoring IN ('Yes', 'No')),
    CONSTRAINT CHK_Coordination_Audit CHECK (Audit_Allowed IN ('Yes', 'No'))
);