CREATE OR REPLACE VIEW Software_Development_Calendar AS
SELECT 
    Development_ID AS Project_ID,
    'Software Development' AS Project_Type,
    Description AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Software_Development

UNION ALL

SELECT 
    Frontend_ID,
    'Frontend',
    Frameworks AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Frontend

UNION ALL

SELECT 
    Backend_ID,
    'Backend',
    Technologies AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Backend

UNION ALL

SELECT 
    Full_Stack_ID,
    'Full Stack',
    Frontend_Technologies || ' / ' || Backend_Technologies AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Full_Stack

UNION ALL

SELECT 
    Mobile_ID,
    'Mobile',
    Platforms || ' / ' || Languages AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Mobile

UNION ALL

SELECT 
    DevOps_ID,
    'DevOps',
    CI_CD_Tools AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM DevOps

UNION ALL

SELECT 
    Architecture_ID,
    'Architecture',
    Architecture_Type AS Title,
    Project_Start_Date,
    Project_End_Date,
    Status
FROM Architecture;

CREATE OR REPLACE VIEW Software_Teams_View AS
SELECT
    'Frontend' AS Team_Type,
    f.Frontend_ID AS Team_ID,
    f.Development_ID,
    f.Team_Leader_ID,
    f.Frameworks AS Main_Technologies,
    f.Status,
    f.Team_Size,
    f.Project_Start_Date,
    f.Project_End_Date
FROM Frontend f

UNION ALL

SELECT
    'Backend',
    b.Backend_ID,
    b.Development_ID,
    b.Team_Leader_ID,
    b.Technologies,
    b.Status,
    b.Team_Size,
    b.Project_Start_Date,
    b.Project_End_Date
FROM Backend b

UNION ALL

SELECT
    'Full-Stack',
    fs.Full_Stack_ID,
    fs.Development_ID,
    fs.Team_Leader_ID,
    fs.Frontend_Technologies || ', ' || fs.Backend_Technologies,
    fs.Status,
    fs.Team_Size,
    fs.Project_Start_Date,
    fs.Project_End_Date
FROM Full_Stack fs

UNION ALL

SELECT
    'Mobile',
    m.Mobile_ID,
    m.Development_ID,
    m.Team_Leader_ID,
    m.Languages || ', ' || m.Platforms || ', ' || m.Frameworks,
    m.Status,
    m.Team_Size,
    m.Project_Start_Date,
    m.Project_End_Date
FROM Mobile m

UNION ALL

SELECT
    'DevOps',
    d.DevOps_ID,
    d.Development_ID,
    d.Team_Leader_ID,
    d.CI_CD_Tools || ', ' || d.Infrastructure_Technologies,
    d.Status,
    d.Team_Size,
    d.Project_Start_Date,
    d.Project_End_Date
FROM DevOps d

UNION ALL

SELECT
    'Architecture',
    a.Architecture_ID,
    a.Development_ID,
    a.Team_Leader_ID,
    a.Architecture_Type || ', ' || a.Design_Patterns,
    a.Status,
    a.Team_Size,
    a.Project_Start_Date,
    a.Project_End_Date
FROM Architecture a;
